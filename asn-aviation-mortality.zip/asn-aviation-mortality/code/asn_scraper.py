#!/usr/bin/env python3
"""
asn_scraper.py — Llena la matriz ASN_Accidentes_Matriz a partir de aviation-safety.net

Uso (en tu computador, no en el chat):
    pip install curl_cffi beautifulsoup4 lxml pandas openpyxl
    python asn_scraper.py --years 1919-1930                     # rango
    python asn_scraper.py --years 1984 --matrix ASN_Accidentes_Matriz_Esteban_c.xlsx
    python asn_scraper.py --years 1919-2026 --delay 2.5         # todo (varias horas)

Qué hace:
  1. Para cada año abre https://aviation-safety.net/database/year/<AÑO> (y páginas /2, /3...)
     — la base principal (airliners/militar transporte/jets corporativos, ~23.000 registros).
     Con --path asndb/year se lee en cambio la WikiBase completa (>258.000 registros).
     y recoge el enlace de cada registro.
  2. Abre cada registro, lee la tabla campo/valor, la narrativa, la causa probable y las fuentes.
  3. Guarda todo crudo en asn_raw/<AÑO>.jsonl (reanudable: si se corta, vuelve a correr y sigue).
  4. Mapea a las 42 columnas de la matriz y escribe asn_matriz_<años>.xlsx.
     Si pasas --matrix, añade las filas nuevas al final de la hoja Matriz_Accidentes
     (sin tocar las que ya llenaron los alumnos; evita duplicados por URL de registro).

Notas:
  - ASN bloquea clientes automáticos genéricos; por eso se usa curl_cffi imitando Chrome.
    Si igual devuelve 403, sube --delay o prueba --host cdn.aviation-safety.net.
  - Las columnas Crew_*/Passengers_* sólo aparecen para usuarios registrados en ASN; se dejan
    en blanco cuando la página no las muestra (igual que en la matriz actual).
  - Leased_from, Follow_up_safety_actions y Notes requieren lectura humana: quedan en blanco.
  - Respeta el sitio: 1 petición cada --delay segundos, un solo hilo.
"""

import argparse, json, os, re, sys, time
from datetime import datetime
from pathlib import Path

import pandas as pd
from bs4 import BeautifulSoup

try:
    from curl_cffi import requests as creq
    def get(url):
        return creq.get(url, impersonate="chrome", timeout=40)
except ImportError:
    import requests as creq
    HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                             "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
               "Accept-Language": "en-US,en;q=0.9"}
    def get(url):
        return creq.get(url, headers=HEADERS, timeout=40)

COLUMNS = ["ID","Status","Date","Time","Type","Operator","Leased_from","Registration","MSN_Cn",
           "Year_built","Engines","Total_airframe_hrs","Cycles","Crew_on_board","Crew_fatalities",
           "Passengers_on_board","Passengers_fatalities","Total_on_board","Total_fatalities",
           "Ground_casualties","Collision_casualties","Airplane_damage","Airplane_fate","Location",
           "Country_Region","Ocean","Phase","Nature","Departure_airport","Destination_airport",
           "Flightnumber","Narrative","Probable_cause","Follow_up_safety_actions","Source",
           "ASN_Category","Hull_loss","Fatal","Age_aircraft","Fatality_rate","Confidence_Rating","Notes"]

# ---------- red ----------

BLOCKED = {"n": 0}   # 403 consecutivos

def fetch(url, delay, retries=4):
    for i in range(retries):
        try:
            r = get(url)
            if r.status_code == 200:
                BLOCKED["n"] = 0
                time.sleep(delay)
                return r.text
            if r.status_code == 404:
                return None
            if r.status_code == 429:          # demasiado rápido: pausa larga
                print(f"  HTTP 429 en {url}; esperando 90 s", file=sys.stderr)
                time.sleep(90)
                continue
            if r.status_code == 403:          # bloqueo: no insistir
                BLOCKED["n"] += 1
                print(f"  HTTP 403 (bloqueado) en {url}", file=sys.stderr)
                if BLOCKED["n"] >= 3:
                    print("\nEl sitio ha bloqueado esta IP. Deteniendo; lo bajado queda guardado.\n"
                          "Espera 24 h (o cambia de red) y vuelve a correr el mismo comando con --delay 3.",
                          file=sys.stderr)
                    sys.exit(2)
                time.sleep(60)
                return None
            print(f"  HTTP {r.status_code} en {url}; reintento {i+1}", file=sys.stderr)
        except Exception as e:
            print(f"  error {e} en {url}; reintento {i+1}", file=sys.stderr)
        time.sleep(delay * (2 + i))
    return None

# ---------- listado anual ----------

def year_record_links(host, path, year, delay):
    """Devuelve URLs absolutas de todos los registros de un año (todas las páginas)."""
    links, page = [], 1
    while True:
        url = f"https://{host}/{path}/{year}" + (f"/{page}" if page > 1 else "")
        html = fetch(url, delay)
        if not html:
            break
        soup = BeautifulSoup(html, "lxml")
        found = 0
        for a in soup.select("table a[href]"):
            href = a["href"]
            if re.search(r"/(asndb|wikibase|database)/(record\.php\?id=)?\d", href):
                full = href if href.startswith("http") else f"https://{host}{href}"
                if full not in links:
                    links.append(full); found += 1
        print(f"  {year} pág. {page}: {found} registros")
        # ¿hay página siguiente?
        if not soup.find("a", href=re.compile(rf"/{path}/{year}/{page+1}\b")):
            break
        page += 1
    return links

# ---------- ficha ----------

def clean(s):
    return re.sub(r"\s+", " ", s or "").strip()

def parse_record(html, url):
    soup = BeautifulSoup(html, "lxml")
    rec = {"url": url}
    # tabla campo : valor
    for tr in soup.select("table tr"):
        cells = tr.find_all(["td", "th"])
        if len(cells) >= 2:
            k = clean(cells[0].get_text()).rstrip(":")
            v = clean(cells[1].get_text(" "))
            if k and k not in rec:
                rec[k] = v
    # narrativa, causa probable, fuentes (bloques de texto fuera de la tabla)
    text = soup.get_text("\n")
    def block(label, stops):
        m = re.search(rf"{label}\s*:?\s*\n(.*?)(?=\n(?:{'|'.join(stops)})\s*:?\s*\n|\Z)",
                      text, re.S | re.I)
        return clean(m.group(1)) if m else ""
    rec["Narrative"] = block("Narrative", ["Probable Cause", "Sources", "Classification",
                                            "Revision History", "Contribute", "Follow-up"])
    rec["Probable Cause"] = block("Probable Cause", ["Sources", "Classification",
                                                     "Revision History", "Contribute", "Follow-up"])
    rec["Follow-up"] = block("Follow-up / safety actions", ["Sources", "Classification",
                                                            "Revision History", "Contribute"])
    rec["Sources"] = block("Sources", ["Classification", "Revision History", "Contribute", "Follow-up"])
    return rec

# ---------- mapeo a la matriz ----------

MONTHS = {m: i for i, m in enumerate(["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"], 1)}

def asn_date(s):
    """'Monday 2 January 1984' -> '02 JAN 1984'; conserva XX si hay incógnitas."""
    m = re.search(r"(\d{1,2}|xx)\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})", s or "", re.I)
    if not m:
        return clean(s)
    d, mo, y = m.groups()
    d = "XX" if d.lower() == "xx" else f"{int(d):02d}"
    return f"{d} {mo.upper()} {y}"

def num(s):
    m = re.search(r"-?\d+", s or "")
    return int(m.group()) if m else None

def fat_occ(s):
    """'Fatalities: 0 / Occupants: 11' -> (0, 11)"""
    f = re.search(r"Fatalities:\s*(\d+)", s or ""); o = re.search(r"Occupants:\s*(\d+)", s or "")
    return (int(f.group(1)) if f else None, int(o.group(1)) if o else None)

def status_from_confidence(c):
    c = (c or "").lower()
    if "investigation report completed" in c or "final" in c:
        return "Final"
    if "verified through data from accident investigation" in c or "preliminary" in c:
        return "Preliminary-Official"
    return "Preliminary"

def hull_loss(damage):
    return "Yes" if re.search(r"destroyed|written off|beyond repair|missing", damage or "", re.I) else "No"

def asn_category(category, hl):
    c = (category or "").lower()
    code = ("A" if "accident" in c else "I" if "incident" in c else "H" if "hijack" in c
            else "C" if "criminal" in c or "unlawful" in c else "O" if "other" in c else "U")
    return f"{code}{'1' if hl == 'Yes' else '2'}"

def split_location(loc):
    """'Galesburg, IL - United States of America' -> (loc, country, ocean)"""
    parts = [p.strip() for p in (loc or "").split(" - ")]
    country = parts[-1] if len(parts) > 1 else ""
    ocean = country if re.search(r"ocean|sea|gulf", country, re.I) else ""
    return loc, country, ocean

def to_row(rec, idx):
    g = lambda *keys: next((rec[k] for k in keys if rec.get(k)), "")
    fat, occ = fat_occ(g("Fatalities", "Total occupants"))
    year = num(re.search(r"\d{4}", g("Date")).group()) if re.search(r"\d{4}", g("Date")) else None
    built = num(g("Year of manufacture", "Year of manufature"))
    damage = g("Aircraft damage")
    hl = hull_loss(damage)
    loc, country, ocean = split_location(g("Location"))
    conf = g("Confidence Rating", "Status")
    return {
        "ID": idx, "Status": status_from_confidence(conf), "Date": asn_date(g("Date")),
        "Time": g("Time").replace(" LT", ""), "Type": g("Type"),
        "Operator": g("Owner/operator", "Operator"), "Leased_from": "",
        "Registration": g("Registration"), "MSN_Cn": g("MSN"), "Year_built": built,
        "Engines": g("Engine model", "Engines"), "Total_airframe_hrs": num(g("Total airframe hrs")),
        "Cycles": num(g("Cycles")),
        "Crew_on_board": "", "Crew_fatalities": "", "Passengers_on_board": "", "Passengers_fatalities": "",
        "Total_on_board": occ, "Total_fatalities": fat,
        "Ground_casualties": num(g("Other fatalities")) if g("Other fatalities") else 0,
        "Collision_casualties": num(g("Collision casualties")) if g("Collision casualties") else 0,
        "Airplane_damage": damage, "Airplane_fate": "Written off" if hl == "Yes" else damage,
        "Location": loc, "Country_Region": country, "Ocean": ocean,
        "Phase": g("Phase"), "Nature": g("Nature"),
        "Departure_airport": g("Departure airport", "Departure Airport"),
        "Destination_airport": g("Destination airport", "Destination Airport"),
        "Flightnumber": g("Flightnumber", "Flight number"),
        "Narrative": rec.get("Narrative", ""), "Probable_cause": rec.get("Probable Cause", ""),
        "Follow_up_safety_actions": rec.get("Follow-up", ""),
        "Source": (rec.get("Sources", "") + "; ASN " + rec["url"]).strip("; "),
        "ASN_Category": asn_category(g("Category"), hl), "Hull_loss": hl,
        "Fatal": "Unknown" if fat is None else ("Yes" if fat > 0 else "No"),
        "Age_aircraft": (year - built) if (year and built) else "",
        "Fatality_rate": round(fat / occ, 4) if (fat is not None and occ) else "",
        "Confidence_Rating": conf, "Notes": "",
    }

# ---------- principal ----------

def parse_years(s):
    out = []
    for part in s.split(","):
        if "-" in part:
            a, b = part.split("-"); out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--years", required=True, help="ej. 1984 | 1919-1930 | 1984,1990-1992")
    ap.add_argument("--delay", type=float, default=2.0, help="segundos entre peticiones")
    ap.add_argument("--host", default="aviation-safety.net")
    ap.add_argument("--path", default="database/year",
                    help="ruta del listado anual: database/year (base principal, airliners) "
                         "o asndb/year (WikiBase completa)")
    ap.add_argument("--matrix", help="xlsx existente al que añadir filas (opcional)")
    ap.add_argument("--rawdir", default="asn_raw")
    ap.add_argument("--offline", action="store_true",
                    help="no descarga nada: arma el Excel sólo con lo ya guardado en asn_raw")
    a = ap.parse_args()

    Path(a.rawdir).mkdir(exist_ok=True)
    years = parse_years(a.years)
    all_recs = []

    for y in years:
        rawfile = Path(a.rawdir) / f"{y}.jsonl"
        done = {}
        if rawfile.exists():
            for line in rawfile.open(encoding="utf-8"):
                r = json.loads(line); done[r["url"]] = r
        if a.offline:
            print(f"Año {y}: {len(done)} registros en asn_raw (offline)")
            all_recs += done.values()
            continue
        print(f"Año {y}: listando registros…")
        links = year_record_links(a.host, a.path, y, a.delay)
        print(f"Año {y}: {len(links)} registros ({len(done)} ya descargados)")
        with rawfile.open("a", encoding="utf-8") as fh:
            for i, url in enumerate(links, 1):
                if url in done:
                    continue
                html = fetch(url, a.delay)
                if not html:
                    continue
                rec = parse_record(html, url)
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n"); fh.flush()
                done[url] = rec
                if i % 25 == 0:
                    print(f"  {y}: {i}/{len(links)}")
        all_recs += done.values()

    # ordenar por fecha y construir la matriz
    def sortkey(r):
        m = re.search(r"(\d{1,2}|xx)\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})", r.get("Date", ""), re.I)
        if not m: return (9999, 0, 0)
        d, mo, yy = m.groups()
        return (int(yy), MONTHS.get(mo[:3].upper(), 0), 0 if d.lower() == "xx" else int(d))
    all_recs.sort(key=sortkey)

    if a.matrix:
        base = pd.read_excel(a.matrix, sheet_name="Matriz_Accidentes")
        existing_urls = set(base["Source"].astype(str).str.extract(r"(https?://\S+)")[0].dropna())
        start = int(pd.to_numeric(base["ID"], errors="coerce").max() or 0) + 1
        rows = [to_row(r, start + i) for i, r in
                enumerate([r for r in all_recs if r["url"] not in existing_urls])]
        new = pd.concat([base, pd.DataFrame(rows, columns=COLUMNS)], ignore_index=True)
        out = a.matrix.replace(".xlsx", "_llenada.xlsx")
        with pd.ExcelWriter(out, engine="openpyxl") as w:
            new.to_excel(w, sheet_name="Matriz_Accidentes", index=False)
            for sh in ["Diccionario_Campos", "Definiciones", "Cobertura_y_Notas"]:
                try:
                    pd.read_excel(a.matrix, sheet_name=sh, header=None).to_excel(w, sheet_name=sh, index=False, header=False)
                except Exception:
                    pass
    else:
        rows = [to_row(r, i + 1) for i, r in enumerate(all_recs)]
        out = f"asn_matriz_{a.years.replace(',', '_')}.xlsx"
        pd.DataFrame(rows, columns=COLUMNS).to_excel(out, index=False)

    print(f"Listo: {len(rows)} filas nuevas -> {out}")

if __name__ == "__main__":
    main()
