#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
asn_analysis.py — Global mortality from aviation accidents, ASN database 1919-2025
===================================================================================
Single reproducible script. Phases are run with --phase (1, 2, 3); every phase
re-runs the previous ones so that outputs are always consistent.

    python asn_analysis.py --phase 1 --data ASN_base_limpia_1919-2025.xlsx

Inputs  (same folder, or pass paths):
    ASN_base_limpia_1919-2025.xlsx            cleaned ASN matrix (27,846 rows x 46 cols)
    denominators/IS.AIR.PSGR.csv  (optional)  World Bank bulk CSV, passengers carried
    denominators/IS.AIR.DPRT.csv  (optional)  World Bank bulk CSV, registered carrier departures (ICAO source)
    denominators/icao_departures.csv (optional) long file: year, iso3 (or 'WLD'), departures
    type_mapping_approved.csv     (optional)  edited copy of the type-mapping table; overrides built-in rules
    corrections_approved.csv      (optional)  not required; built-in corrections are listed in CORRECTIONS

Outputs (./outputs):
    Phase 1: P1_flow_STROBE.png/.pdf, P1_tables.xlsx, P1_type_mapping_for_approval.xlsx,
             P1_data_dictionary.xlsx, asn_analytic.parquet/.csv, denominators_template.csv

Dependencies: pandas, numpy, matplotlib, openpyxl, statsmodels (phases 2-3).
"""
import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------------
# 0. CONFIGURATION
# ----------------------------------------------------------------------------------
MAIN_START, MAIN_END = 1970, 2025          # main analysis window
HIST_START, HIST_END = 1919, 2025          # historical window
SEATS_COMMUTER_MAX = 19                    # commuter: <=19 seats
SEATS_REGIONAL_MAX = 100                   # regional: 20-100 seats; narrow-body: >100 seats (single-aisle)
SEAT_THRESHOLD_REGIONAL = SEATS_REGIONAL_MAX  # kept for backward compatibility
INDONESIA_WHO_REGION = "SEAR"              # "SEAR" (membership until 23 May 2025) or "WPR" (current). See notes.
OUT = Path("outputs")
CAT_NATURES = ["Passenger - Scheduled", "Passenger - Non-Scheduled/charter/Air Taxi", "Cargo"]

# ----------------------------------------------------------------------------------
# 1. DOCUMENTED CORRECTIONS (applied by ID; each one is logged in P1_tables.xlsx)
# ----------------------------------------------------------------------------------
# action: 'drop' removes the row; 'set' assigns value to a column.
CORRECTIONS = [
    dict(ID=3, action="drop", column=None, value=None,
         reason="Manual 1919-1923 row mis-dated: Mitsubishi MU-300 N368PU, NTSB CHI90LA088, is the "
                "23 FEB 1990 event already present as scraper row ID 17906 (duplicate + wrong year)."),
    dict(ID=14015, action="set", column="Total_fatalities", value=5,
         reason="Mid-air collision of two An-2 (25 MAR 1977). ASN reports the combined toll (10) on both "
                "records with 5 occupants each; on-board deaths cannot exceed occupants. Both aircraft "
                "were destroyed with no survivors -> 5 per aircraft (sum preserved = 10)."),
    dict(ID=14102, action="set", column="Total_fatalities", value=5,
         reason="Same collision as ID 14015 (counterpart aircraft)."),
    dict(ID=8840, action="set", column="Total_fatalities", value=0,
         reason="An-2 hangar fire 28 AUG 1959: 0 occupants, the single death was a ground worker. "
                "Moved from on-board to ground fatalities."),
    dict(ID=8840, action="set", column="Ground_casualties", value=1,
         reason="See previous line."),
    dict(ID=16876, action="set", column="Year_built", value=np.nan,
         reason="Year built (2014) later than event year (1987): implausible, set to missing."),
]

# ----------------------------------------------------------------------------------
# 2. AIRCRAFT TYPE MAPPING RULES
# ----------------------------------------------------------------------------------
# (regex, family, manufacturer_group, propulsion, typical_max_seats, role, wide_body)
# propulsion: Jet | Turboprop | Piston | Rotorcraft
# role: PAX (airliner / general transport)  BIZ (business jet)  FRT (purpose-built freighter or
#       military airlifter)  SPC (special mission: maritime patrol, tanker, bomber-derived, flying boat,
#       firefighting amphibian)  HEL (helicopter)
# Seats = typical maximum single-class seating of the family (approximate; reference values to be
# verified against type-certificate data sheets before submission). First matching rule wins.
J, T, P, R = "Jet", "Turboprop", "Piston", "Rotorcraft"
TYPE_RULES = [
    # ---- Airbus
    (r"Airbus A220|Bombardier CS[13]00|BD-500", "Airbus A220", "Airbus", J, 135, "PAX", 0),
    (r"Airbus A300|Airbus A310|A310-", "Airbus A300/A310", "Airbus", J, 260, "PAX", 1),
    (r"Airbus A31[89]|Airbus A32[01]", "Airbus A320 family", "Airbus", J, 180, "PAX", 0),
    (r"Airbus A330|Airbus A340", "Airbus A330/A340", "Airbus", J, 300, "PAX", 1),
    (r"Airbus A350", "Airbus A350", "Airbus", J, 325, "PAX", 1),
    (r"Airbus A380", "Airbus A380", "Airbus", J, 550, "PAX", 1),
    (r"Airbus (Military )?A400|C-?295", "Airbus/CASA C-295/A400M", "Airbus", T, None, "FRT", 0),
    # ---- Boeing
    (r"Boeing 707|Boeing 720|Boeing [A-Z]{0,2}C-137|Boeing E-3|Boeing E-6|Boeing E-8", "Boeing 707/720", "Boeing", J, 180, "PAX", 0),
    (r"Boeing 717", "Boeing 717", "Boeing", J, 110, "PAX", 0),
    (r"Boeing 727", "Boeing 727", "Boeing", J, 150, "PAX", 0),
    (r"Boeing 737|Boeing T-43|Boeing C-40|Boeing P-8", "Boeing 737", "Boeing", J, 160, "PAX", 0),
    (r"Boeing 747|Boeing VC-25|Boeing E-4", "Boeing 747", "Boeing", J, 450, "PAX", 1),
    (r"Boeing 757|Boeing C-32", "Boeing 757", "Boeing", J, 200, "PAX", 0),
    (r"Boeing 767|Boeing KC-46|Boeing KC-767", "Boeing 767", "Boeing", J, 250, "PAX", 1),
    (r"Boeing 777", "Boeing 777", "Boeing", J, 350, "PAX", 1),
    (r"Boeing 787", "Boeing 787", "Boeing", J, 290, "PAX", 1),
    (r"Boeing [A-Z]{0,3}C-135|Boeing C-18", "Boeing C-135/KC-135", "Boeing", J, None, "SPC", 0),
    (r"Aero Spacelines", "Aero Spacelines Guppy (turbine)", "Boeing", T, None, "FRT", 0),
    (r"Boeing 377|Boeing [A-Z]{0,2}C-97", "Boeing 377/C-97", "Boeing", P, 100, "PAX", 0),
    (r"Boeing S\.?307", "Boeing 307 Stratoliner", "Boeing", P, 33, "PAX", 0),
    (r"Boeing 247", "Boeing 247", "Boeing", P, 10, "PAX", 0),
    (r"Boeing 314", "Boeing 314 Clipper", "Boeing", P, 74, "SPC", 0),
    (r"Boeing B-17|Boeing B-29|Boeing SB-|Boeing (40|80|221)", "Boeing (other piston)", "Boeing", P, None, "SPC", 0),
    (r"Globemaster III|(Boeing|McDonnell Douglas) C-17", "Boeing C-17", "Boeing", J, None, "FRT", 0),
    # ---- Douglas / McDonnell Douglas
    (r"DC[- ]10|MD-10|KC-10|KDC-10", "McDonnell Douglas DC-10/MD-10", "Douglas/McDonnell Douglas", J, 300, "PAX", 1),
    (r"MD-11", "McDonnell Douglas MD-11", "Douglas/McDonnell Douglas", J, 320, "PAX", 1),
    (r"MD-8\d|MD-90|DC-9-8\d", "McDonnell Douglas MD-80/90", "Douglas/McDonnell Douglas", J, 160, "PAX", 0),
    (r"DC-9|Douglas C-9|McDonnell Douglas C-9", "Douglas DC-9", "Douglas/McDonnell Douglas", J, 110, "PAX", 0),
    (r"DC-8", "Douglas DC-8", "Douglas/McDonnell Douglas", J, 200, "PAX", 0),
    (r"DC-3.*(TP|Turbo)|C-47TP|DC-3T|Basler BT-67|BSAS C-47|Conroy Tri-Turbo|Super DC-3.*Turb", "DC-3 turbine conversions", "Douglas/McDonnell Douglas", T, 28, "PAX", 0),
    (r"DC-3|C-47|C-117|Douglas C-(48|49|50|52|53|68|84)|Douglas R4D|Douglas Dakota|Douglas TS-62|Douglas DST|Lisunov|PS-84|Nakajima/Douglas|Showa",
     "Douglas DC-3/C-47 family (incl. Li-2)", "Douglas/McDonnell Douglas", P, 28, "PAX", 0),
    (r"Douglas DC-[125][A-Z]?\b|Douglas DC-[125][A-Z]?-|DC-2\)|DC-5\)|Douglas [XY]?C-3[2-9]|Douglas C-4[12]|Douglas R[23]D", "Douglas DC-1/DC-2/DC-5", "Douglas/McDonnell Douglas", P, 14, "PAX", 0),
    (r"DC-4|Douglas C-54|Douglas R5D|Canadair C-4|Canadair C-54|Canadair North Star|Douglas (V|S|E|R)C-54", "Douglas DC-4/C-54 (incl. Canadair North Star)", "Douglas/McDonnell Douglas", P, 70, "PAX", 0),
    (r"DC-6|Douglas C-118|Douglas R6D|Douglas VC-118", "Douglas DC-6/C-118", "Douglas/McDonnell Douglas", P, 90, "PAX", 0),
    (r"DC-7", "Douglas DC-7", "Douglas/McDonnell Douglas", P, 100, "PAX", 0),
    (r"Douglas C-124|Douglas C-74", "Douglas C-124 Globemaster II", "Douglas/McDonnell Douglas", P, None, "FRT", 0),
    (r"Douglas C-133", "Douglas C-133 Cargomaster", "Douglas/McDonnell Douglas", T, None, "FRT", 0),
    (r"Aviation Traders ATL-98", "ATL-98 Carvair", "Douglas/McDonnell Douglas", P, None, "FRT", 0),
    # ---- Lockheed
    (r"L-1011|Lockheed Tristar", "Lockheed L-1011 TriStar", "Lockheed", J, 300, "PAX", 1),
    (r"Lockheed( Martin)? [A-Z]{0,3}C-130|Lockheed L-100|Lockheed L-382|Lockheed Hercules", "Lockheed C-130/L-100 Hercules", "Lockheed", T, None, "FRT", 0),
    (r"Lockheed C-141|Lockheed C-5", "Lockheed C-141/C-5", "Lockheed", J, None, "FRT", 0),
    (r"Lockheed L-188|Lockheed Electra \(L-188", "Lockheed L-188 Electra", "Lockheed", T, 98, "PAX", 0),
    (r"(Lockheed|Kawasaki) [A-Z]{0,2}P-3|Lockheed CP-140|Lockheed Orion", "Lockheed P-3 Orion", "Lockheed", T, None, "SPC", 0),
    (r"Lockheed L-1329|JetStar|Lockheed C-140", "Lockheed JetStar", "Lockheed", J, 10, "BIZ", 0),
    (r"Lockheed L-0?49|Lockheed L-149|Lockheed L-[67]49|Lockheed L-1049|Lockheed L-1649|Lockheed (E|R|V|W)?C-121|Lockheed C-69|Lockheed WV-|Lockheed R7V|Constellation", "Lockheed Constellation family", "Lockheed", P, 95, "PAX", 0),
    (r"Lockheed [A-Z]{0,2}P-2|Lockheed [XY]?P2V|Lockheed Neptune|Lockheed RB-69|Lockheed P-15|Lockheed SP-2|Kawasaki P-2", "Lockheed P-2 Neptune", "Lockheed", P, None, "SPC", 0),
    (r"Lockheed 414|Hudson|Hudstar|Ventura|Harpoon|Lockheed PV-|Lockheed B-34|^Howard|Learstar", "Lockheed Hudson/Ventura (incl. Howard conv.)", "Lockheed", P, None, "SPC", 0),
    (r"Lockheed 18|Lockheed C-5[6-9]|Lockheed C-60|Lockheed R5O|Lodestar|Lockheed C-66", "Lockheed 18 Lodestar", "Lockheed", P, 18, "PAX", 0),
    (r"Lockheed 1[024]\b|Lockheed 1[024][- A-Z]|Lockheed 10|Lockheed 12|Lockheed 14|Lockheed (Vega|Orion 9|5 Vega|9)|Super Electra", "Lockheed 10/12/14 Electra", "Lockheed", P, 12, "PAX", 0),
    # ---- Antonov / Soviet-Russian / Chinese derivatives
    (r"An-3T?\b|TVS-2", "Antonov An-3 / turbine An-2 conversions", "Antonov", T, 12, "PAX", 0),
    (r"An-2(?!\d)|An-6\b|TR-301|Shijiazhuang Y-5|Nanchang Y-5", "Antonov An-2 (incl. Y-5)", "Antonov", P, 12, "PAX", 0),
    (r"An-124|An-225", "Antonov An-124/225", "Antonov", J, None, "FRT", 0),
    (r"An-22(?!\d)|An-70|Il-112", "Antonov An-22 / An-70 / Il-112 (turboprop airlifters)", "Antonov", T, None, "FRT", 0),
    (r"An-12|Shaanxi Y-8|Shaanxi Y-9", "Antonov An-12 (incl. Y-8)", "Antonov", T, None, "FRT", 0),
    (r"An-8(?!\d)", "Antonov An-8", "Antonov", T, None, "FRT", 0),
    (r"An-10", "Antonov An-10", "Antonov", T, 100, "PAX", 0),
    (r"An-24|Xian Y-?7|Yunshuji Y-7|Xian MA-?60|Xian MA-?600", "Antonov An-24 (incl. Y-7/MA60)", "Antonov", T, 50, "PAX", 0),
    (r"An-26|An-32|An-30", "Antonov An-26/30/32", "Antonov", T, None, "FRT", 0),
    (r"An-7[24]", "Antonov An-72/74", "Antonov", J, None, "FRT", 0),
    (r"An-28|PZL-Mielec|M-?28|An-38", "Antonov An-28/M28/An-38", "Antonov", T, 18, "PAX", 0),
    (r"An-140", "Antonov An-140", "Antonov", T, 52, "PAX", 0),
    (r"An-14[8]|An-158", "Antonov An-148/158", "Antonov", J, 85, "PAX", 0),
    (r"Il-76|Il-78", "Ilyushin Il-76", "Ilyushin", J, None, "FRT", 0),
    (r"Il-86|Il-96", "Ilyushin Il-86/96", "Ilyushin", J, 330, "PAX", 1),
    (r"Il-62", "Ilyushin Il-62", "Ilyushin", J, 180, "PAX", 0),
    (r"Il-18|Il-20|Il-22|Il-38", "Ilyushin Il-18", "Ilyushin", T, 100, "PAX", 0),
    (r"Il-114", "Ilyushin Il-114", "Ilyushin", T, 64, "PAX", 0),
    (r"Il-12|Il-14|Avia 14|VEB 14|Avia Av-14", "Ilyushin Il-12/14 (incl. Avia 14)", "Ilyushin", P, 32, "PAX", 0),
    (r"Tu-104|Tu-124", "Tupolev Tu-104/124", "Tupolev", J, 70, "PAX", 0),
    (r"Tu-134", "Tupolev Tu-134", "Tupolev", J, 80, "PAX", 0),
    (r"Tu-154", "Tupolev Tu-154", "Tupolev", J, 170, "PAX", 0),
    (r"Tu-204|Tu-214", "Tupolev Tu-204/214", "Tupolev", J, 200, "PAX", 0),
    (r"Tu-144", "Tupolev Tu-144", "Tupolev", J, 140, "PAX", 0),
    (r"Tu-114", "Tupolev Tu-114", "Tupolev", T, 170, "PAX", 0),
    (r"Tupolev (ANT|G-|PS-|TB-)", "Tupolev (pre-war piston)", "Tupolev", P, None, "SPC", 0),
    (r"Yak-40", "Yakovlev Yak-40", "Yakovlev", J, 32, "PAX", 0),
    (r"Yak-42", "Yakovlev Yak-42", "Yakovlev", J, 120, "PAX", 0),
    (r"Yak-12|Yak-6", "Yakovlev Yak-12", "Yakovlev", P, 4, "PAX", 0),
    (r"Superjet|SSJ", "Sukhoi Superjet 100", "Sukhoi", J, 98, "PAX", 0),
    (r"Let L-?4[12]0|Let 410", "Let L-410", "Let", T, 19, "PAX", 0),
    (r"Harbin Y-?12", "Harbin Y-12", "Harbin", T, 17, "PAX", 0),
    (r"COMAC|ARJ21", "COMAC ARJ21/C919", "COMAC", J, 90, "PAX", 0),
    (r"^Mil |^Kamov|Sikorsky S-(5|6|7|9)\d|Sikorsky (H|CH|UH|SH)|^Bell |Eurocopter|Aérospatiale (SA|AS)|Boeing(-| )Vertol|Westland", "Helicopters", "Helicopter (various)", R, None, "HEL", 0),
    # ---- de Havilland Canada / Bombardier / Canadair
    (r"DHC-8-4|Dash 8.*(Q?400)", "DHC-8-400 (Q400)", "de Havilland Canada/Bombardier", T, 78, "PAX", 0),
    (r"DHC-8-3", "DHC-8-300", "de Havilland Canada/Bombardier", T, 50, "PAX", 0),
    (r"DHC-8|Dash 8", "DHC-8-100/200", "de Havilland Canada/Bombardier", T, 39, "PAX", 0),
    (r"DHC-7", "DHC-7 Dash 7", "de Havilland Canada/Bombardier", T, 50, "PAX", 0),
    (r"DHC-6|Twin Otter", "DHC-6 Twin Otter", "de Havilland Canada/Bombardier", T, 19, "PAX", 0),
    (r"DHC-5|de Havilland Canada C-115|de Havilland Canada C-8", "DHC-5 Buffalo", "de Havilland Canada/Bombardier", T, None, "FRT", 0),
    (r"DHC-4T", "DHC-4T Turbo Caribou", "de Havilland Canada/Bombardier", T, None, "FRT", 0),
    (r"DHC-4|de Havilland Canada C-7|de Havilland Canada CV-2|Caribou", "DHC-4 Caribou", "de Havilland Canada/Bombardier", P, None, "FRT", 0),
    (r"DHC-3.*(Turb|T\b|Vazar)|DHC-3T", "DHC-3 Turbine Otter", "de Havilland Canada/Bombardier", T, 10, "PAX", 0),
    (r"DHC-3|de Havilland Canada U-1|de Havilland Canada UC-1|CSR-123", "DHC-3 Otter", "de Havilland Canada/Bombardier", P, 10, "PAX", 0),
    (r"DHC-2", "DHC-2 Beaver", "de Havilland Canada/Bombardier", P, 7, "PAX", 0),
    (r"CRJ-?(7|9|10)|CL-600-2(C|D|E)", "Bombardier CRJ-700/900/1000", "de Havilland Canada/Bombardier", J, 90, "PAX", 0),
    (r"CRJ|CL-600-2B19|Regional Jet", "Canadair CRJ-100/200", "de Havilland Canada/Bombardier", J, 50, "PAX", 0),
    (r"CL-60[0-5]|Challenger|BD-100|BD-700|Global (5|6|7|Express)|Canadair CC-144", "Bombardier Challenger/Global", "de Havilland Canada/Bombardier", J, 12, "BIZ", 0),
    (r"CL-215T|CL-415", "Canadair CL-215T/415", "de Havilland Canada/Bombardier", T, None, "SPC", 0),
    (r"CL-215", "Canadair CL-215", "de Havilland Canada/Bombardier", P, None, "SPC", 0),
    (r"CL-44|CC-106", "Canadair CL-44", "de Havilland Canada/Bombardier", T, None, "FRT", 0),
    # ---- de Havilland (UK) / BAe / Hawker Siddeley / Avro / Vickers / Bristol / HP / Short
    (r"DH-?106|Comet", "de Havilland Comet", "British (BAe/HS/DH/Avro/Vickers)", J, 80, "PAX", 0),
    (r"[DB]H[-. ]?125|HS[-. ]?125|BAe[- ]?125|Hawker \d{3,4}|Raytheon Hawker|Hawker Beechcraft (Hawker|[4789]\d\d)", "HS/BAe 125 - Hawker", "British (BAe/HS/DH/Avro/Vickers)", J, 8, "BIZ", 0),
    (r"Carstedt|Saunders ST-27", "Turbine Dove/Heron conversions", "British (BAe/HS/DH/Avro/Vickers)", T, 18, "PAX", 0),
    (r"DH-?114|DH-?104", "de Havilland Dove/Heron", "British (BAe/HS/DH/Avro/Vickers)", P, 15, "PAX", 0),
    (r"de Havilland DH", "de Havilland (pre-war piston)", "British (BAe/HS/DH/Avro/Vickers)", P, 10, "PAX", 0),
    (r"BAe[- ]?146|Avro RJ|British Aerospace Avro", "BAe 146/Avro RJ", "British (BAe/HS/DH/Avro/Vickers)", J, 95, "PAX", 0),
    (r"ATP", "BAe ATP", "British (BAe/HS/DH/Avro/Vickers)", T, 64, "PAX", 0),
    (r"British Aerospace (31|32)\d\d|Jetstream 3[12]|HP-?137|Handley Page Jetstream|Scottish Aviation Jetstream", "BAe Jetstream 31/32", "British (BAe/HS/DH/Avro/Vickers)", T, 19, "PAX", 0),
    (r"British Aerospace 41\d\d|Jetstream 41", "BAe Jetstream 41", "British (BAe/HS/DH/Avro/Vickers)", T, 29, "PAX", 0),
    (r"748|HS-?780|Andover", "HS 748/Andover", "British (BAe/HS/DH/Avro/Vickers)", T, 48, "PAX", 0),
    (r"HS-?121|Trident", "HS-121 Trident", "British (BAe/HS/DH/Avro/Vickers)", J, 115, "PAX", 0),
    (r"One-Eleven|BAC 1-11|ROMBAC", "BAC One-Eleven", "British (BAe/HS/DH/Avro/Vickers)", J, 89, "PAX", 0),
    (r"Concorde", "Concorde", "Aérospatiale/Sud/Nord (France)", J, 100, "PAX", 0),
    (r"VC-?10", "Vickers VC10", "British (BAe/HS/DH/Avro/Vickers)", J, 150, "PAX", 0),
    (r"Nimrod", "HS Nimrod", "British (BAe/HS/DH/Avro/Vickers)", J, None, "SPC", 0),
    (r"Shackleton|Canadair CP-107|Lancaster|Lancastrian|Halifax|Halton|Wellington|Warwick|Varsity|Varisty|Blenheim|Valentia|Boulton", "British maritime patrol/bomber-derived", "British (BAe/HS/DH/Avro/Vickers)", P, None, "SPC", 0),
    (r"Vickers 95\d|Vanguard|Merchantman", "Vickers Vanguard", "British (BAe/HS/DH/Avro/Vickers)", T, 139, "PAX", 0),
    (r"Vickers 8\d\d", "Vickers Viscount 800", "British (BAe/HS/DH/Avro/Vickers)", T, 65, "PAX", 0),
    (r"Vickers 7\d\d|Viscount", "Vickers Viscount 700", "British (BAe/HS/DH/Avro/Vickers)", T, 48, "PAX", 0),
    (r"Vickers [46]\d\d|Viking|Valetta", "Vickers Viking/Valetta", "British (BAe/HS/DH/Avro/Vickers)", P, 36, "PAX", 0),
    (r"Avro 685|York", "Avro York", "British (BAe/HS/DH/Avro/Vickers)", P, 56, "PAX", 0),
    (r"Avro 68[89]|Tudor", "Avro Tudor", "British (BAe/HS/DH/Avro/Vickers)", P, 60, "PAX", 0),
    (r"Avro (652|Anson|XIX|19)", "Avro Anson", "British (BAe/HS/DH/Avro/Vickers)", P, 9, "PAX", 0),
    (r"Bristol 170|Bristol Freighter", "Bristol 170 Freighter", "British (BAe/HS/DH/Avro/Vickers)", P, None, "FRT", 0),
    (r"Bristol 175|Britannia", "Bristol Britannia", "British (BAe/HS/DH/Avro/Vickers)", T, 139, "PAX", 0),
    (r"AW-?6[56]0|Argosy", "AW Argosy", "British (BAe/HS/DH/Avro/Vickers)", T, None, "FRT", 0),
    (r"Beverley|Belfast", "Blackburn Beverley / Short Belfast", "British (BAe/HS/DH/Avro/Vickers)", P, None, "FRT", 0),
    (r"Armstrong Whitworth", "Armstrong Whitworth (pre-war piston)", "British (BAe/HS/DH/Avro/Vickers)", P, 20, "PAX", 0),
    (r"HPR-?7|Herald", "Handley Page Herald", "British (BAe/HS/DH/Avro/Vickers)", T, 50, "PAX", 0),
    (r"Hastings|HP\.?81|Hermes", "Handley Page Hastings/Hermes", "British (BAe/HS/DH/Avro/Vickers)", P, 60, "PAX", 0),
    (r"Handley Page|Airspeed|Scottish Aviation|Twin Pioneer|Miles|Avro 642|Short L\.17", "British piston transports (other)", "British (BAe/HS/DH/Avro/Vickers)", P, 20, "PAX", 0),
    (r"Sunderland|Sandringham|Solent|Short S\.|Shorts S\.", "Short flying boats", "Short", P, None, "SPC", 0),
    (r"SC\.?7|Skyvan", "Short SC.7 Skyvan", "Short", T, 19, "PAX", 0),
    (r"Shorts? 3[36]0|Shorts? [A-Z]?C-23|Shorts SD3", "Short 330/360", "Short", T, 36, "PAX", 0),
    (r"BN-?2.*Trislander|Mk III", "Britten-Norman Trislander", "Britten-Norman", P, 17, "PAX", 0),
    (r"BN-?2T|Turbine Islander", "Britten-Norman BN-2T", "Britten-Norman", T, 9, "PAX", 0),
    (r"BN-?2|Islander|Britten", "Britten-Norman BN-2 Islander", "Britten-Norman", P, 9, "PAX", 0),
    # ---- Fokker / Fairchild / Swearingen / Dornier
    (r"Fokker 100|Fokker 70|Fokker F-?28|F-28", "Fokker F28/70/100", "Fokker", J, 85, "PAX", 0),
    (r"Fokker 50|Fokker 60", "Fokker 50", "Fokker", T, 56, "PAX", 0),
    (r"FH-227", "Fairchild FH-227", "Fokker", T, 52, "PAX", 0),
    (r"F-?27", "Fokker/Fairchild F-27", "Fokker", T, 48, "PAX", 0),
    (r"Fokker (F\.|C-2|Universal|Super)", "Fokker (pre-war piston)", "Fokker", P, 12, "PAX", 0),
    (r"C-119|C-82|R4Q|C-123|YC-122|Budd RB", "Fairchild C-82/C-119/C-123", "Fairchild", P, None, "FRT", 0),
    (r"SA-?22[67]|Metro|Merlin", "Swearingen/Fairchild Metro-Merlin", "Fairchild", T, 19, "PAX", 0),
    (r"328JET|328-3\d\d", "Dornier 328JET", "Dornier", J, 32, "PAX", 0),
    (r"Dornier 328|Do-?328", "Dornier 328", "Dornier", T, 32, "PAX", 0),
    (r"Dornier 228|Do-?228|HAL/Dornier", "Dornier 228", "Dornier", T, 19, "PAX", 0),
    (r"Do 128-6|Do-128-6|Turbo.?Skyservant|G92|Seastar", "Dornier 128-6", "Dornier", T, 10, "PAX", 0),
    (r"Do ?28|Do 128|Dornier Do", "Dornier Do 28/128", "Dornier", P, 12, "PAX", 0),
    # ---- ATR / Saab / Embraer / CASA
    (r"ATR 42|ATR-42", "ATR 42", "ATR", T, 48, "PAX", 0),
    (r"ATR 72|ATR-72", "ATR 72", "ATR", T, 70, "PAX", 0),
    (r"Saab 340|SF-?340", "Saab 340", "Saab", T, 34, "PAX", 0),
    (r"Saab 2000", "Saab 2000", "Saab", T, 50, "PAX", 0),
    (r"Scandia", "Saab Scandia", "Saab", P, 32, "PAX", 0),
    (r"EMB-110|Bandeirante|Embraer (C|P|R|E)C?-95|EMB-111|EMB-121", "Embraer EMB-110 Bandeirante", "Embraer", T, 18, "PAX", 0),
    (r"EMB-120|Brasilia", "Embraer EMB-120 Brasilia", "Embraer", T, 30, "PAX", 0),
    (r"EMB-135BJ|Legacy|EMB-50[05]|EMB-5[45]\d|Phenom|Praetor", "Embraer Legacy/Phenom", "Embraer", J, 10, "BIZ", 0),
    (r"EMB-135|ERJ-?135|ERJ-?140|EMB-140", "Embraer ERJ-135/140", "Embraer", J, 40, "PAX", 0),
    (r"EMB[- ]145|ERJ-?145", "Embraer ERJ-145", "Embraer", J, 50, "PAX", 0),
    (r"ERJ[- ]?1[79]\d|EMB-1[79]\d|Embraer E?1[79]\d|E19[05]-E2", "Embraer E-Jets (170-195)", "Embraer", J, 100, "PAX", 0),
    (r"C-?212|NC-212", "CASA C-212 Aviocar", "CASA/IPTN", T, 26, "PAX", 0),
    (r"CN-?235", "CASA/IPTN CN-235", "CASA/IPTN", T, 44, "PAX", 0),
    (r"CASA 352|Amiot AAC|Ju[- ]?52", "Junkers Ju 52 (incl. CASA 352/AAC.1)", "Junkers", P, 17, "PAX", 0),
    (r"Junkers", "Junkers (other piston)", "Junkers", P, 12, "PAX", 0),
    # ---- Convair / Martin / Curtiss / Consolidated / Ford / Grumman
    (r"CV-?880|CV-?990", "Convair 880/990", "Convair/Consolidated", J, 110, "PAX", 0),
    (r"CV-?(540|580|600|640|5800)|Cosmopolitan", "Convair 580/600/640 (turboprop)", "Convair/Consolidated", T, 52, "PAX", 0),
    (r"CV-?(240|300|340|440)|Convair (C-131|T-29|VT-29|R4Y|C-131|VC-131)", "Convair 240/340/440", "Convair/Consolidated", P, 44, "PAX", 0),
    (r"Catalina|PBY|Canso|OA-10|PBV-1|PB2B|Consolidated 28", "Consolidated PBY Catalina", "Convair/Consolidated", P, None, "SPC", 0),
    (r"Consolidated", "Consolidated (Liberator transports, other)", "Convair/Consolidated", P, None, "SPC", 0),
    (r"Martin (2|4)-?0-?[24]", "Martin 2-0-2/4-0-4", "Martin", P, 40, "PAX", 0),
    (r"^Martin", "Martin flying boats", "Martin", P, None, "SPC", 0),
    (r"C-46|R5C|Curtiss CW-20", "Curtiss C-46 Commando", "Curtiss", P, 40, "PAX", 0),
    (r"Curtiss", "Curtiss Condor (other)", "Curtiss", P, 15, "PAX", 0),
    (r"^Ford", "Ford Trimotor", "Ford", P, 12, "PAX", 0),
    (r"G-?159|Gulfstream I\b", "Grumman Gulfstream I", "Grumman/Gulfstream", T, 19, "PAX", 0),
    (r"G-?1159|Gulfstream|G-IV|G-V|G150|G200|G280|G450|G550|G650|Grumman (American )?G-1159|C-20", "Gulfstream jets", "Grumman/Gulfstream", J, 14, "BIZ", 0),
    (r"Grumman C-2|Grumman C-1", "Grumman C-1/C-2", "Grumman/Gulfstream", T, None, "FRT", 0),
    (r"G-73T|Turbo Mallard|Turbo Goose", "Grumman turbine amphibians", "Grumman/Gulfstream", T, None, "SPC", 0),
    (r"^Grumman", "Grumman amphibians (Goose/Mallard/Albatross)", "Grumman/Gulfstream", P, None, "SPC", 0),
    # ---- General-aviation-size commercial types
    (r"Cessna 208|Cessna C-98|Cessna U-27", "Cessna 208 Caravan", "Cessna", T, 13, "PAX", 0),
    (r"F406|Cessna 4[24]1|Cessna 425", "Cessna/Reims twin turboprops", "Cessna", T, 12, "PAX", 0),
    (r"Cessna (S?5\d\d|6[58]0|7[05]0|T-47|UC-35|Citation)", "Cessna Citation", "Cessna", J, 9, "BIZ", 0),
    (r"^Cessna", "Cessna piston", "Cessna", P, 8, "PAX", 0),
    (r"Beechcraft 1900|Beech 1900|C-12J", "Beechcraft 1900", "Beechcraft/Raytheon", T, 19, "PAX", 0),
    (r"Beechcraft (B|C)?-?99", "Beechcraft 99", "Beechcraft/Raytheon", T, 15, "PAX", 0),
    (r"King Air|Beechcraft (A|B)?(100|200|300|350)|Beechcraft (R|U)?C-12|Beechcraft A200|Beechcraft B300", "Beechcraft King Air", "Beechcraft/Raytheon", T, 11, "PAX", 0),
    (r"Beechjet|Beechcraft 400|Raytheon 400|390|Premier|Mitsubishi MU-300|Mitsubishi Mu-300|T-1A", "Beechjet 400 / Premier / MU-300", "Beechcraft/Raytheon", J, 8, "BIZ", 0),
    (r"Volpar", "Volpar Turboliner", "Beechcraft/Raytheon", T, 15, "PAX", 0),
    (r"^Beech", "Beechcraft piston (18 etc.)", "Beechcraft/Raytheon", P, 9, "PAX", 0),
    (r"Learjet|Lear Jet|Gates", "Learjet", "Learjet", J, 8, "BIZ", 0),
    (r"Falcon|Mystère|Dassault HU-25", "Dassault Falcon", "Dassault", J, 10, "BIZ", 0),
    (r"Mercure", "Dassault Mercure", "Dassault", J, 150, "PAX", 0),
    (r"ATECO|Potez 84", "Small turboprops (other)", "Other", T, 15, "PAX", 0),
    (r"IAI 112\d|Westwind|Astra|Jet Commander|Rockwell 1121|Galaxy", "IAI Westwind/Astra (incl. Jet Commander)", "IAI", J, 8, "BIZ", 0),
    (r"Arava", "IAI Arava", "IAI", T, 20, "PAX", 0),
    (r"Sabreliner|T-39|CT-39", "Sabreliner", "North American/Rockwell", J, 8, "BIZ", 0),
    (r"Corvette|MS[-.]?760|HFB-?320|Honda|Eclipse|Cirrus SF50|PC-24|Piaggio PD|SJ30|Spectrum|Sport-Jet|Grob G|Jetpod", "Light business jets (other)", "Other business jets", J, 7, "BIZ", 0),
    (r"PC-12|PC-6", "Pilatus PC-12/PC-6", "Pilatus", T, 9, "PAX", 0),
    (r"Nomad", "GAF Nomad", "GAF", T, 14, "PAX", 0),
    (r"YS-11", "NAMC YS-11", "NAMC", T, 60, "PAX", 0),
    (r"MU-2", "Mitsubishi MU-2", "Mitsubishi", T, 8, "PAX", 0),
    (r"IA 50|Guaran", "FMA IA 50 Guarani", "FMA", T, 15, "PAX", 0),
    # ---- France / Italy / Germany / other historical
    (r"SE-?210|Caravelle", "Sud Aviation Caravelle", "Aérospatiale/Sud/Nord (France)", J, 90, "PAX", 0),
    (r"Nord 262|Mohawk 298|Frégate", "Nord 262", "Aérospatiale/Sud/Nord (France)", T, 29, "PAX", 0),
    (r"Noratlas|Nord 250\d", "Nord Noratlas", "Aérospatiale/Sud/Nord (France)", P, None, "FRT", 0),
    (r"Kawasaki C-[12]", "Kawasaki C-1/C-2", "Other", J, None, "FRT", 0),
    (r"Transall|C-160|G-?222|C-27", "Transall C-160 / Alenia G-222", "European military airlifters", T, None, "FRT", 0),
    (r"Beriev (A-50|Be-200)|VFW", "Other jets (Be-200, A-50, VFW 614)", "Other", J, None, "SPC", 0),
    (r"Breguet 1150|Atlantic|Shin ?Meiwa|ShinMaywa", "Maritime patrol (Atlantic, PS-1)", "Other", T, None, "SPC", 0),
    (r"SNCA|Hurel|Languedoc|Bretagne|Breguet|Dewoitine|Bloch|Farman|Latécoère|Potez|Lioré|Blériot|Caudron|Wibault",
     "French piston transports", "Aérospatiale/Sud/Nord (France)", P, 30, "PAX", 0),
    (r"Savoia|Fiat G|CANT|Macchi|Caproni|Sabca", "Italian piston transports", "Italian (SM/Fiat/CANT)", P, 20, "PAX", 0),
    (r"Focke-Wulf|Rohrbach", "German piston transports (other)", "Other", P, 20, "PAX", 0),
    (r"Sikorsky S-4[0-4]|Sikorsky VS-44", "Sikorsky flying boats", "Sikorsky", P, None, "SPC", 0),
    (r"Aeromarine|Felixstowe|Kalinin|Polikarpov|Stinson|Northrop|Vultee|Waco|Travel Air|Fairchild (FC|71|Pilgrim)|Bellanca|Noorduyn|Piper|Aero Commander|Super Aero|Partenavia|Rockwell (Turbo )?Commander",
     "Small piston aircraft (other)", "Other", P, 8, "PAX", 0),
]
_COMPILED = [(re.compile(rx, re.I),) + tuple(rest) for rx, *rest in TYPE_RULES]

MANUFACTURER_PREFIXES = [
    "de Havilland Canada", "de Havilland", "McDonnell Douglas", "British Aerospace", "Hawker Siddeley",
    "Hawker Beechcraft", "Handley Page", "Armstrong Whitworth", "Sud Aviation", "North American",
    "Scottish Aviation", "Canadian Car & Foundry", "Canadian Vickers", "Morane Saulnier", "General Dynamics",
    "Aviation Traders", "Aero Commander", "Aero Modifications", "Aero Spacelines", "Shin Meiwa",
    "Boulton Paul", "Super Aero", "Hindustan Aeronautics Ltd.", "Britten Norman", "Lockheed Martin",
]
MANUFACTURER_ALIASES = {
    "Mcdonnell Douglas": "McDonnell Douglas", "Mcdonnell": "McDonnell Douglas", "Sud-Aviation": "Sud Aviation",
    "SAAB": "Saab", "Shorts": "Short", "IRMA/Britten-Norman": "Britten-Norman", "IRMA/Pilatus": "Britten-Norman",
    "PADC/Pilatus": "Britten-Norman", "PADC/Britten-Norman": "Britten-Norman", "Pilatus Britten-Norman": "Britten-Norman",
    "Britten Norman": "Britten-Norman", "CASA/Nurtanio": "CASA", "CASA/IPTN": "CASA", "IPTN/CASA": "CASA",
    "BAe": "British Aerospace", "Kaiser-Frazer": "Fairchild", "Kaiser-Fraser": "Fairchild",
    "Boeing-Canada": "Boeing-Canada", "Gates": "Learjet", "HAL/Dornier": "Dornier", "De": "de Havilland",
    "unknown": "Unknown",
}


def asn_manufacturer(t):
    """Manufacturer exactly as named by ASN (first token/s of Type), lightly harmonised."""
    if not isinstance(t, str) or not t.strip():
        return "Unknown"
    for p in MANUFACTURER_PREFIXES:
        if t.lower().startswith(p.lower() + " "):
            return MANUFACTURER_ALIASES.get(p, p)
    if t.startswith("Pilatus Britten-Norman"):
        return "Britten-Norman"
    tok = t.split()[0]
    return MANUFACTURER_ALIASES.get(tok, tok)


def map_type(t):
    if not isinstance(t, str) or re.match(r"^\s*unknown", t, re.I):
        return ("Unknown", "Unknown", "Unknown", np.nan, "UNK", 0)
    for rx, fam, mg, prop, seats, role, wide in _COMPILED:
        if rx.search(t):
            return (fam, mg, prop, seats if seats is not None else np.nan, role, wide)
    return ("Unmapped", asn_manufacturer(t), "Unknown", np.nan, "UNK", 0)


CLASS_ORDER = ["Commuter (<=19 seats)", "Regional (20-100 seats)", "Narrow-body (>100 seats)", "Wide-body",
               "Dedicated freighter/airlifter", "Business jet", "Other", "Unknown"]


def aircraft_class(role, seats, wide, regional_max=None):
    """Approved scheme (Phase 1 review): airframe-based classes. Seat counts are REFERENCE VALUES
    (typical maximum single-class seating) to be verified against type-certificate data sheets before
    submission. 'Other' = special-mission aircraft (maritime patrol, tankers, bomber-derived, flying
    boats, firefighting amphibians) and rotorcraft."""
    if role in ("HEL", "SPC"):
        return "Other"
    if role == "FRT":
        return "Dedicated freighter/airlifter"
    if role == "BIZ":
        return "Business jet"
    if role == "UNK" or pd.isna(seats):
        return "Unknown"
    if wide:
        return "Wide-body"
    if seats <= SEATS_COMMUTER_MAX:
        return "Commuter (<=19 seats)"
    cut = SEATS_REGIONAL_MAX if regional_max is None else regional_max
    return "Regional (20-100 seats)" if seats <= cut else "Narrow-body (>100 seats)"


# engine-string based propulsion, used ONLY to validate the type-based mapping
ENGINE_RULES = [
    (r"PT6|TPE|PW1[0-5]\d(?!\d)|PW12\d(?!\d)|Dart|AI-2[04]|AI-20|TVD|Walter M-?601|M601|Allison (T56|501|250)|T56|T64|Tyne|CT7|AE ?2100|Proteus|NK-12|GE H80|T53|Astazou|Bastan|TV[37]-", "Turboprop"),
    (r"JT\d|CFM|CF6|CF34|V25|RB\.?211|Trent|Spey|Tay|Conway|Avon|D-30|D-36|NK-8|NK-86|PS-90|TFE|FJ44|JT15|PW[2-9]\d\d|PW[1246]\d\d\d|GE90|GEnx|LEAP|CJ610|CJ-610|J\d\d|TF3\d|ALF|LF ?507|BR ?7|AE ?3007|SaM146|AM-3|RD-3|AI-25|Viper|Marbor|Olympus|PW3\d\d|PW5\d\d|PW6\d\d|HTF|Larzac|M45", "Jet"),
    (r"R-\d{3,4}|ASh-|ASz-|Wright|Hercules|Merlin|Griffon|Centaurus|Pegasus|Leonides|Lycoming (I|T|G)?[OV]|Continental|BMW|Gipsy|Jupiter|Cheetah|Cyclone|Wasp|Hornet|M-62|Jacobs|Gnome|Hispano|Alfa Romeo|Piaggio P|Lorraine|Liberty|Ranger", "Piston"),
]


def engine_propulsion(e):
    if not isinstance(e, str):
        return np.nan
    for rx, p in ENGINE_RULES:
        if re.search(rx, e, re.I):
            return p
    return np.nan


# ----------------------------------------------------------------------------------
# 3. COUNTRY -> ISO3, WHO REGION, UN M49 SUB-REGION
# ----------------------------------------------------------------------------------
# WHO region of non-member territories follows the WHO region of the geographic area
# (marked terr=1). Oceans -> "At sea"; Antarctica kept separate; unknown -> "Unknown".
def _c(iso, who, sub, terr=0):
    return dict(ISO3=iso, WHO_region=who, UN_subregion=sub, Territory=terr)


COUNTRY_MAP = {
    # ---------- AMR
    "United States of America": _c("USA", "AMR", "Northern America"), "Canada": _c("CAN", "AMR", "Northern America"),
    "Greenland": _c("GRL", "EUR", "Northern America", 1), "Bermuda": _c("BMU", "AMR", "Northern America", 1),
    "St. Pierre and Miquelon": _c("SPM", "AMR", "Northern America", 1),
    "Mexico": _c("MEX", "AMR", "Central America"), "Guatemala": _c("GTM", "AMR", "Central America"),
    "Belize": _c("BLZ", "AMR", "Central America"), "Honduras": _c("HND", "AMR", "Central America"),
    "El Salvador": _c("SLV", "AMR", "Central America"), "Nicaragua": _c("NIC", "AMR", "Central America"),
    "Costa Rica": _c("CRI", "AMR", "Central America"), "Panama": _c("PAN", "AMR", "Central America"),
    "Colombia": _c("COL", "AMR", "South America"), "Venezuela": _c("VEN", "AMR", "South America"),
    "Ecuador": _c("ECU", "AMR", "South America"), "Peru": _c("PER", "AMR", "South America"),
    "Bolivia": _c("BOL", "AMR", "South America"), "Brazil": _c("BRA", "AMR", "South America"),
    "Chile": _c("CHL", "AMR", "South America"), "Argentina": _c("ARG", "AMR", "South America"),
    "Uruguay": _c("URY", "AMR", "South America"), "Paraguay": _c("PRY", "AMR", "South America"),
    "Guyana": _c("GUY", "AMR", "South America"), "Suriname": _c("SUR", "AMR", "South America"),
    "French Guiana": _c("GUF", "AMR", "South America", 1), "Falkland Islands": _c("FLK", "AMR", "South America", 1),
    "Cuba": _c("CUB", "AMR", "Caribbean"), "Dominican Republic": _c("DOM", "AMR", "Caribbean"),
    "Haiti": _c("HTI", "AMR", "Caribbean"), "Jamaica": _c("JAM", "AMR", "Caribbean"),
    "Bahamas": _c("BHS", "AMR", "Caribbean"), "Trinidad and Tobago": _c("TTO", "AMR", "Caribbean"),
    "Barbados": _c("BRB", "AMR", "Caribbean"), "Saint Lucia": _c("LCA", "AMR", "Caribbean"),
    "Antigua and Barbuda": _c("ATG", "AMR", "Caribbean"), "Dominica": _c("DMA", "AMR", "Caribbean"),
    "Saint Vincent and the Grenadines": _c("VCT", "AMR", "Caribbean"), "St. Kitts and Nevis": _c("KNA", "AMR", "Caribbean"),
    "Grenada": _c("GRD", "AMR", "Caribbean"),
    "Puerto Rico": _c("PRI", "AMR", "Caribbean", 1), "U.S. Virgin Islands": _c("VIR", "AMR", "Caribbean", 1),
    "British Virgin Islands": _c("VGB", "AMR", "Caribbean", 1), "Cayman Islands": _c("CYM", "AMR", "Caribbean", 1),
    "Turks and Caicos Islands": _c("TCA", "AMR", "Caribbean", 1), "Anguilla": _c("AIA", "AMR", "Caribbean", 1),
    "Montserrat": _c("MSR", "AMR", "Caribbean", 1), "Aruba": _c("ABW", "AMR", "Caribbean", 1),
    "Curaçao": _c("CUW", "AMR", "Caribbean", 1), "Sint Maarten": _c("SXM", "AMR", "Caribbean", 1),
    "Caribbean Netherlands": _c("BES", "AMR", "Caribbean", 1), "Guadeloupe": _c("GLP", "AMR", "Caribbean", 1),
    "Martinique": _c("MTQ", "AMR", "Caribbean", 1), "Saint Barthélemy": _c("BLM", "AMR", "Caribbean", 1),
    # ---------- EUR
    "Russia": _c("RUS", "EUR", "Eastern Europe"), "Ukraine": _c("UKR", "EUR", "Eastern Europe"),
    "Crimea": _c("UKR", "EUR", "Eastern Europe", 1), "Belarus": _c("BLR", "EUR", "Eastern Europe"),
    "Poland": _c("POL", "EUR", "Eastern Europe"), "Czechia": _c("CZE", "EUR", "Eastern Europe"),
    "Slovakia": _c("SVK", "EUR", "Eastern Europe"), "Hungary": _c("HUN", "EUR", "Eastern Europe"),
    "Romania": _c("ROU", "EUR", "Eastern Europe"), "Bulgaria": _c("BGR", "EUR", "Eastern Europe"),
    "Moldova": _c("MDA", "EUR", "Eastern Europe"),
    "United Kingdom": _c("GBR", "EUR", "Northern Europe"), "Ireland": _c("IRL", "EUR", "Northern Europe"),
    "Norway": _c("NOR", "EUR", "Northern Europe"), "Sweden": _c("SWE", "EUR", "Northern Europe"),
    "Denmark": _c("DNK", "EUR", "Northern Europe"), "Finland": _c("FIN", "EUR", "Northern Europe"),
    "Iceland": _c("ISL", "EUR", "Northern Europe"), "Estonia": _c("EST", "EUR", "Northern Europe"),
    "Latvia": _c("LVA", "EUR", "Northern Europe"), "Lithuania": _c("LTU", "EUR", "Northern Europe"),
    "Germany": _c("DEU", "EUR", "Western Europe"), "France": _c("FRA", "EUR", "Western Europe"),
    "Netherlands": _c("NLD", "EUR", "Western Europe"), "Belgium": _c("BEL", "EUR", "Western Europe"),
    "Switzerland": _c("CHE", "EUR", "Western Europe"), "Austria": _c("AUT", "EUR", "Western Europe"),
    "Luxembourg": _c("LUX", "EUR", "Western Europe"), "Monaco": _c("MCO", "EUR", "Western Europe"),
    "Italy": _c("ITA", "EUR", "Southern Europe"), "Spain": _c("ESP", "EUR", "Southern Europe"),
    "Portugal": _c("PRT", "EUR", "Southern Europe"), "Greece": _c("GRC", "EUR", "Southern Europe"),
    "Malta": _c("MLT", "EUR", "Southern Europe"), "Croatia": _c("HRV", "EUR", "Southern Europe"),
    "Serbia": _c("SRB", "EUR", "Southern Europe"), "Slovenia": _c("SVN", "EUR", "Southern Europe"),
    "Bosnia and Herzegovina": _c("BIH", "EUR", "Southern Europe"), "Montenegro": _c("MNE", "EUR", "Southern Europe"),
    "North Macedonia": _c("MKD", "EUR", "Southern Europe"), "Albania": _c("ALB", "EUR", "Southern Europe"),
    "Kosovo": _c("XKX", "EUR", "Southern Europe", 1), "Gibraltar": _c("GIB", "EUR", "Southern Europe", 1),
    "Türkiye": _c("TUR", "EUR", "Western Asia"), "Cyprus": _c("CYP", "EUR", "Western Asia"),
    "Israel": _c("ISR", "EUR", "Western Asia"), "Georgia": _c("GEO", "EUR", "Western Asia"),
    "Armenia": _c("ARM", "EUR", "Western Asia"), "Azerbaijan": _c("AZE", "EUR", "Western Asia"),
    "Kazakhstan": _c("KAZ", "EUR", "Central Asia"), "Uzbekistan": _c("UZB", "EUR", "Central Asia"),
    "Kyrgyzstan": _c("KGZ", "EUR", "Central Asia"), "Tajikistan": _c("TJK", "EUR", "Central Asia"),
    "Turkmenistan": _c("TKM", "EUR", "Central Asia"),
    # ---------- EMR
    "Iran": _c("IRN", "EMR", "Southern Asia"), "Afghanistan": _c("AFG", "EMR", "Southern Asia"),
    "Pakistan": _c("PAK", "EMR", "Southern Asia"),
    "Iraq": _c("IRQ", "EMR", "Western Asia"), "Syria": _c("SYR", "EMR", "Western Asia"),
    "Lebanon": _c("LBN", "EMR", "Western Asia"), "Jordan": _c("JOR", "EMR", "Western Asia"),
    "Saudi Arabia": _c("SAU", "EMR", "Western Asia"), "Yemen": _c("YEM", "EMR", "Western Asia"),
    "Oman": _c("OMN", "EMR", "Western Asia"), "United Arab Emirates": _c("ARE", "EMR", "Western Asia"),
    "Qatar": _c("QAT", "EMR", "Western Asia"), "Bahrain": _c("BHR", "EMR", "Western Asia"),
    "Kuwait": _c("KWT", "EMR", "Western Asia"), "Palestine": _c("PSE", "EMR", "Western Asia", 1),
    "Egypt": _c("EGY", "EMR", "Northern Africa"), "Libya": _c("LBY", "EMR", "Northern Africa"),
    "Tunisia": _c("TUN", "EMR", "Northern Africa"), "Morocco": _c("MAR", "EMR", "Northern Africa"),
    "Sudan": _c("SDN", "EMR", "Northern Africa"), "Western Sahara": _c("ESH", "EMR", "Northern Africa", 1),
    "Somalia": _c("SOM", "EMR", "Eastern Africa"), "Djibouti": _c("DJI", "EMR", "Eastern Africa"),
    # ---------- AFR
    "Algeria": _c("DZA", "AFR", "Northern Africa"),
    "Nigeria": _c("NGA", "AFR", "Western Africa"), "Ghana": _c("GHA", "AFR", "Western Africa"),
    "Senegal": _c("SEN", "AFR", "Western Africa"), "Mali": _c("MLI", "AFR", "Western Africa"),
    "Liberia": _c("LBR", "AFR", "Western Africa"), "Mauritania": _c("MRT", "AFR", "Western Africa"),
    "Niger": _c("NER", "AFR", "Western Africa"), "Cote d'Ivoire": _c("CIV", "AFR", "Western Africa"),
    "Gambia": _c("GMB", "AFR", "Western Africa"), "Guinea": _c("GIN", "AFR", "Western Africa"),
    "Sierra Leone": _c("SLE", "AFR", "Western Africa"), "Benin": _c("BEN", "AFR", "Western Africa"),
    "Burkina Faso": _c("BFA", "AFR", "Western Africa"), "Togo": _c("TGO", "AFR", "Western Africa"),
    "Cape Verde": _c("CPV", "AFR", "Western Africa"), "Guinea-Bissau": _c("GNB", "AFR", "Western Africa"),
    "St. Helena": _c("SHN", "AFR", "Western Africa", 1),
    "Congo (Democratic Republic)": _c("COD", "AFR", "Middle Africa"), "Congo": _c("COG", "AFR", "Middle Africa"),
    "Angola": _c("AGO", "AFR", "Middle Africa"), "Cameroon": _c("CMR", "AFR", "Middle Africa"),
    "Chad": _c("TCD", "AFR", "Middle Africa"), "Gabon": _c("GAB", "AFR", "Middle Africa"),
    "Central African Republic": _c("CAF", "AFR", "Middle Africa"), "Equatorial Guinea": _c("GNQ", "AFR", "Middle Africa"),
    "São Tomé and Príncipe": _c("STP", "AFR", "Middle Africa"),
    "Kenya": _c("KEN", "AFR", "Eastern Africa"), "South Sudan": _c("SSD", "AFR", "Eastern Africa"),
    "Ethiopia": _c("ETH", "AFR", "Eastern Africa"), "Tanzania": _c("TZA", "AFR", "Eastern Africa"),
    "Mozambique": _c("MOZ", "AFR", "Eastern Africa"), "Uganda": _c("UGA", "AFR", "Eastern Africa"),
    "Zambia": _c("ZMB", "AFR", "Eastern Africa"), "Zimbabwe": _c("ZWE", "AFR", "Eastern Africa"),
    "Eritrea": _c("ERI", "AFR", "Eastern Africa"), "Madagascar": _c("MDG", "AFR", "Eastern Africa"),
    "Malawi": _c("MWI", "AFR", "Eastern Africa"), "Rwanda": _c("RWA", "AFR", "Eastern Africa"),
    "Burundi": _c("BDI", "AFR", "Eastern Africa"), "Comoros": _c("COM", "AFR", "Eastern Africa"),
    "Seychelles": _c("SYC", "AFR", "Eastern Africa"), "Mauritius": _c("MUS", "AFR", "Eastern Africa"),
    "Reunion": _c("REU", "AFR", "Eastern Africa", 1),
    "South Africa": _c("ZAF", "AFR", "Southern Africa"), "Namibia": _c("NAM", "AFR", "Southern Africa"),
    "Botswana": _c("BWA", "AFR", "Southern Africa"), "Lesotho": _c("LSO", "AFR", "Southern Africa"),
    "Eswatini": _c("SWZ", "AFR", "Southern Africa"),
    # ---------- SEAR
    "India": _c("IND", "SEAR", "Southern Asia"), "Bangladesh": _c("BGD", "SEAR", "Southern Asia"),
    "Nepal": _c("NPL", "SEAR", "Southern Asia"), "Sri Lanka": _c("LKA", "SEAR", "Southern Asia"),
    "Bhutan": _c("BTN", "SEAR", "Southern Asia"), "Maldives": _c("MDV", "SEAR", "Southern Asia"),
    "Myanmar": _c("MMR", "SEAR", "South-eastern Asia"), "Thailand": _c("THA", "SEAR", "South-eastern Asia"),
    "East Timor": _c("TLS", "SEAR", "South-eastern Asia"), "North Korea": _c("PRK", "SEAR", "Eastern Asia"),
    "Indonesia": _c("IDN", INDONESIA_WHO_REGION, "South-eastern Asia"),
    # ---------- WPR
    "China": _c("CHN", "WPR", "Eastern Asia"), "Japan": _c("JPN", "WPR", "Eastern Asia"),
    "South Korea": _c("KOR", "WPR", "Eastern Asia"), "Mongolia": _c("MNG", "WPR", "Eastern Asia"),
    "Taiwan": _c("TWN", "WPR", "Eastern Asia", 1), "Hong Kong": _c("HKG", "WPR", "Eastern Asia", 1),
    "Macau": _c("MAC", "WPR", "Eastern Asia", 1),
    "Vietnam": _c("VNM", "WPR", "South-eastern Asia"), "Philippines": _c("PHL", "WPR", "South-eastern Asia"),
    "Laos": _c("LAO", "WPR", "South-eastern Asia"), "Cambodia": _c("KHM", "WPR", "South-eastern Asia"),
    "Malaysia": _c("MYS", "WPR", "South-eastern Asia"), "Singapore": _c("SGP", "WPR", "South-eastern Asia"),
    "Brunei": _c("BRN", "WPR", "South-eastern Asia"),
    "Australia": _c("AUS", "WPR", "Australia and New Zealand"), "New Zealand": _c("NZL", "WPR", "Australia and New Zealand"),
    "Norfolk Island": _c("NFK", "WPR", "Australia and New Zealand", 1),
    "Christmas Island": _c("CXR", "WPR", "Australia and New Zealand", 1),
    "Cocos (Keeling) Islands": _c("CCK", "WPR", "Australia and New Zealand", 1),
    "Papua New Guinea": _c("PNG", "WPR", "Melanesia"), "Fiji": _c("FJI", "WPR", "Melanesia"),
    "Solomon Islands": _c("SLB", "WPR", "Melanesia"), "Vanuatu": _c("VUT", "WPR", "Melanesia"),
    "New Caledonia": _c("NCL", "WPR", "Melanesia", 1),
    "Guam": _c("GUM", "WPR", "Micronesia", 1), "Marshall Islands": _c("MHL", "WPR", "Micronesia"),
    "Micronesia": _c("FSM", "WPR", "Micronesia"), "Kiribati": _c("KIR", "WPR", "Micronesia"),
    "Palau": _c("PLW", "WPR", "Micronesia"), "Northern Mariana Islands": _c("MNP", "WPR", "Micronesia", 1),
    "U.S. Minor Outlying Islands": _c("UMI", "WPR", "Micronesia", 1),
    "French Polynesia": _c("PYF", "WPR", "Polynesia", 1), "Samoa": _c("WSM", "WPR", "Polynesia"),
    "American Samoa": _c("ASM", "WPR", "Polynesia", 1), "Tonga": _c("TON", "WPR", "Polynesia"),
    "Tuvalu": _c("TUV", "WPR", "Polynesia"), "Cook Islands": _c("COK", "WPR", "Polynesia"),
    # ---------- special
    "Antarctica": _c("ATA", "Antarctica", "Antarctica", 1),
}
for _o in ["Atlantic Ocean", "Pacific Ocean", "Indian Ocean", "Arctic Ocean", "Mediterranean Sea", "Caribbean Sea"]:
    COUNTRY_MAP[_o] = _c(None, "At sea", "At sea")
for _u in ["Unknown", "Unknown country"]:
    COUNTRY_MAP[_u] = _c(None, "Unknown", "Unknown")

COUNTRY_FIXES = {"T\ufffdrkiye": "Türkiye", "Unknown country": "Unknown"}

LATAM_ISO = {"MEX", "GTM", "BLZ", "HND", "SLV", "NIC", "CRI", "PAN", "COL", "VEN", "ECU", "PER", "BOL", "BRA",
             "CHL", "ARG", "URY", "PRY", "CUB", "DOM", "HTI", "PRI"}

# ----------------------------------------------------------------------------------
# 4. PHASE AND NATURE GROUPING
# ----------------------------------------------------------------------------------
PHASE_GROUP = {
    "Standing": "Ground", "Taxi": "Ground", "Pushback / towing": "Ground",
    "Take off": "Take-off/initial climb", "Initial climb": "Take-off/initial climb",
    "En route": "En route (cruise)",
    "Approach": "Approach/landing", "Landing": "Approach/landing",
    "Manoeuvring": "Manoeuvring/other", "Manoeuvring (airshow, firefighting, ag.ops.)": "Manoeuvring/other",
    "Combat": "Manoeuvring/other",
    "Unknown": "Unknown",
}
PHASE_ORDER = ["Ground", "Take-off/initial climb", "En route (cruise)", "Approach/landing",
               "Manoeuvring/other", "Unknown"]
AGE_BINS = [-0.1, 4, 14, 24, 200]
AGE_LABELS = ["<5", "5-14", "15-24", ">=25"]


# ----------------------------------------------------------------------------------
# 5. LOAD, CORRECT, DERIVE
# ----------------------------------------------------------------------------------
def load_raw(path):
    df = pd.read_excel(path)
    df["Total_airframe_hrs"] = pd.to_numeric(
        df["Total_airframe_hrs"].astype(str).str.extract(r"(\d+)")[0], errors="coerce")
    return df


def apply_corrections(df):
    log = []
    df = df.copy()
    for c in CORRECTIONS:
        m = df["ID"] == c["ID"]
        if not m.any():
            log.append({**c, "old_value": "ID not found", "applied": False}); continue
        if c["action"] == "drop":
            log.append({**c, "old_value": "row", "applied": True})
            df = df[~m]
        else:
            old = df.loc[m, c["column"]].iloc[0]
            df.loc[m, c["column"]] = c["value"]
            log.append({**c, "old_value": old, "applied": True})
    return df.reset_index(drop=True), pd.DataFrame(log)


def dedup_collision_fatalities(df):
    """ASN 'Other fatalities' (here Ground_casualties) mixes (a) people killed on the ground and
    (b) occupants killed in the OTHER aircraft of a collision. When the other aircraft is itself a
    record in the database, (b) is already counted as its on-board fatalities, so adding
    Total_fatalities + Ground_casualties across records double counts (e.g. Tenerife 1977).
    Rule: for each record with Ground_casualties > 0, look for another record with the same Date and
    Country whose on-board fatalities are >0 and <= Ground_casualties, and whose narrative (either
    record) mentions a collision; subtract the partner's on-board deaths. Pairs are exported for review."""
    df = df.copy()
    df["Other_fatalities_raw"] = df["Ground_casualties"]
    df["Collision_partner_ID"] = pd.NA
    df["Collision_partner_fatalities"] = 0
    coll = df["Narrative"].fillna("").str.contains(r"collid|collision|struck by|hit by|mid-?air", case=False, regex=True)
    # 11 SEP 2001: four aircraft, same day/country, large ground tolls, no aircraft-to-aircraft collision
    intent = df["Date"].isin(["11 SEP 2001"])
    cand = df[(df["Ground_casualties"] > 0) & ~intent]
    by_key = df[(df["Total_fatalities"].fillna(0) > 0) & ~intent].groupby(["Date", "Country_Region"])
    pairs = []
    for i, r in cand.iterrows():
        key = (r["Date"], r["Country_Region"])
        if key not in by_key.groups:
            continue
        g = df.loc[by_key.groups[key]]
        g = g[(g["ID"] != r["ID"]) & (g["Total_fatalities"] <= r["Ground_casualties"])]
        g = g[(coll.loc[g.index]) | coll.loc[i]]
        if g.empty:
            continue
        g = g.assign(exact=(g["Total_fatalities"] == r["Ground_casualties"]),
                     same_loc=(g["Location"] == r["Location"]),
                     recip=(g["Ground_casualties"] >= (r["Total_fatalities"] if pd.notna(r["Total_fatalities"]) else 0))
                           & (g["Ground_casualties"] > 0))
        g = g[g["exact"] | g["same_loc"] | g["recip"]]
        if g.empty:
            continue
        p = g.sort_values(["exact", "same_loc", "Total_fatalities"], ascending=False).iloc[0]
        df.at[i, "Collision_partner_ID"] = p["ID"]
        df.at[i, "Collision_partner_fatalities"] = int(p["Total_fatalities"])
        pairs.append(dict(ID=r["ID"], Date=r["Date"], Type=r["Type"], Onboard_fatalities=r["Total_fatalities"],
                          Other_fatalities_ASN=r["Ground_casualties"], Partner_ID=p["ID"], Partner_type=p["Type"],
                          Partner_onboard_fatalities=p["Total_fatalities"],
                          Ground_fatalities_after=int(r["Ground_casualties"] - p["Total_fatalities"]),
                          Match=("exact" if p["exact"] else "same location" if p["same_loc"] else "reciprocal"),
                          Location=r["Location"], Partner_location=p["Location"]))
    df["Ground_fatalities"] = (df["Other_fatalities_raw"] - df["Collision_partner_fatalities"]).clip(lower=0)
    # true ground victims of a collision are reported by ASN on BOTH aircraft: keep them on one record only
    pairs = pd.DataFrame(pairs)
    pairs["Ground_shared_removed"] = 0
    idx = df.set_index("ID").index
    pid = dict(zip(pairs["ID"], pairs["Partner_ID"]))
    for a, b in pid.items():
        if pid.get(b) == a and a < b:
            ga = df.loc[df["ID"] == a, "Ground_fatalities"].iloc[0]; gb = df.loc[df["ID"] == b, "Ground_fatalities"].iloc[0]
            if ga > 0 and gb > 0:
                df.loc[df["ID"] == a, "Ground_fatalities"] = max(ga, gb)
                df.loc[df["ID"] == b, "Ground_fatalities"] = 0
                pairs.loc[pairs["ID"] == b, "Ground_shared_removed"] = int(gb)
    pairs["Ground_fatalities_final"] = pairs["ID"].map(df.set_index("ID")["Ground_fatalities"])
    return df, pairs


def derive(df):
    df = df.copy()
    # --- dates
    df["Year"] = df["Date"].str.extract(r"(\d{4})\s*$")[0].astype(int)
    df["Date_parsed"] = pd.to_datetime(df["Date"], format="%d %b %Y", errors="coerce")
    df["Date_precision"] = np.where(df["Date_parsed"].notna(), "day",
                             np.where(df["Date"].str.match(r"^XX [A-Z]{3} \d{4}$"), "month", "year"))
    df["Decade"] = (df["Year"] // 10) * 10
    df["ASN_URL"] = df["Source"].str.extract(r"(https?://aviation-safety\.net/\S+)\s*$")[0]
    # --- geography
    df["Country"] = df["Country_Region"].replace(COUNTRY_FIXES)
    geo = df["Country"].map(COUNTRY_MAP)
    unmapped = sorted(df.loc[geo.isna(), "Country"].unique())
    if unmapped:
        raise ValueError(f"Countries without WHO mapping: {unmapped}")
    for k in ["ISO3", "WHO_region", "UN_subregion", "Territory"]:
        df[k] = geo.map(lambda d: d[k])
    df["At_sea"] = (df["WHO_region"] == "At sea").astype(int)
    df["LatAm_flag"] = df["ISO3"].isin(LATAM_ISO)
    # --- aircraft
    m = pd.DataFrame(df["Type"].map(map_type).tolist(), index=df.index,
                     columns=["Aircraft_family", "Manufacturer_group", "Propulsion", "Seats_typical", "Role", "Wide_body"])
    df = pd.concat([df, m], axis=1)
    df["Manufacturer_ASN"] = df["Type"].map(asn_manufacturer)
    df["Aircraft_class"] = [aircraft_class(r, s, w) for r, s, w in zip(df["Role"], df["Seats_typical"], df["Wide_body"])]
    df["Propulsion_engine_check"] = df["Engines"].map(engine_propulsion)
    # --- age
    df["Age_years"] = df["Year"] - df["Year_built"]
    df.loc[(df["Age_years"] < 0) | (df["Age_years"] > 90), "Age_years"] = np.nan
    df["Age_cat"] = pd.cut(df["Age_years"], AGE_BINS, labels=AGE_LABELS).astype(object)
    df["Age_cat"] = df["Age_cat"].fillna("Unknown")
    # --- phase
    df["Phase_group"] = df["Phase"].map(PHASE_GROUP).fillna("Unknown")
    # --- outcomes
    df["Fatalities_known"] = df["Total_fatalities"].notna()
    df["Fatal_event"] = np.where(df["Total_fatalities"].isna(), np.nan, (df["Total_fatalities"] > 0).astype(float))
    dmg = df["Airplane_damage"].fillna("")
    df["Hull_loss_3"] = np.select(
        [dmg.str.contains(r"destroyed|written off|missing", case=False),
         dmg.eq("") | dmg.str.match(r"^Unknown", case=False)],
        ["Yes", "Unknown"], default="No")
    ok = df["Total_on_board"].gt(0) & df["Total_fatalities"].notna() & (df["Total_fatalities"] <= df["Total_on_board"])
    df["Onboard_lethality"] = np.where(ok, df["Total_fatalities"] / df["Total_on_board"], np.nan)
    df["Intentional_act"] = df["ASN_Category"].str.startswith("C").astype(int)
    df["Military"] = (df["Nature_group"] == "Military").astype(int)
    df["Nature_unknown"] = (df["Nature_group"] == "Unknown").astype(int)
    # Commercial air transport (CAT): numerator consistent with ICAO/World Bank traffic denominators (approved definition)
    df["CAT"] = (df["Nature"].isin(CAT_NATURES) & (df["Nature_group"] != "Military")).astype(int)
    df["Military_operator_flag"] = df["Operator"].fillna("").str.contains(
        r"Air Force|Navy\b|\bArmy\b|USAAF|USAF|\bRAF\b|Luftwaffe|Força Aérea|Fuerza A[eé]rea|Marine Corps|Aeronautica Militare|Armée",
        regex=True).astype(int)
    return df


# ----------------------------------------------------------------------------------
# 6. STUDY POPULATIONS AND FLOW
# ----------------------------------------------------------------------------------
def populations(df, n_raw, n_dropped):
    hist = df[df["Year"].between(HIST_START, HIST_END)]
    win = df[df["Year"].between(MAIN_START, MAIN_END)]
    main = win[win["Military"] == 0]
    mil = win[win["Military"] == 1]
    flow = [
        ("Records in cleaned ASN matrix", n_raw),
        ("  Removed: duplicate/mis-dated manual record", -n_dropped),
        (f"Historical cohort {HIST_START}-{HIST_END} (all operations)", len(hist)),
        (f"  Excluded: events before {MAIN_START}", -(len(hist) - len(win))),
        (f"Events {MAIN_START}-{MAIN_END}", len(win)),
        ("  Excluded from main analysis: military operations (separate stratum)", -len(mil)),
        (f"MAIN ANALYSIS: civil operations {MAIN_START}-{MAIN_END}", len(main)),
        ("    with known on-board fatalities", int(main["Fatalities_known"].sum())),
        ("    with known occupants >0 and fatalities (lethality analyses)", int(main["Onboard_lethality"].notna().sum())),
        ("    fatal events", int((main["Fatal_event"] == 1).sum())),
        ("    intentional acts (ASN category C; kept, excluded in sensitivity)", int(main["Intentional_act"].sum())),
        (f"MILITARY STRATUM {MAIN_START}-{MAIN_END}", len(mil)),
        ("    with known on-board fatalities", int(mil["Fatalities_known"].sum())),
    ]
    return hist, main, mil, pd.DataFrame(flow, columns=["Step", "n"])


def missingness(df, cols):
    out = []
    for c in cols:
        s = df[c]
        miss = s.isna()
        if s.dtype == object or str(s.dtype).startswith("str"):
            unk = s.astype(str).str.strip().str.lower().isin(["unknown", "-", "unknown country"])
        else:
            unk = pd.Series(False, index=s.index)
        out.append(dict(Variable=c, n=len(s), Missing_n=int(miss.sum()), Missing_pct=round(100 * miss.mean(), 1),
                        Coded_unknown_n=int(unk.sum()),
                        Missing_or_unknown_pct=round(100 * (miss | unk).mean(), 1)))
    return pd.DataFrame(out)


def flow_figure(df, hist, main, mil, n_raw, n_dropped, path_stem):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5})
    fig, ax = plt.subplots(figsize=(8.2, 9.4)); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

    def box(x, y, w, h, text, bold=False, fc="white"):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=0.8", lw=0.8,
                                    ec="#333333", fc=fc))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", weight="bold" if bold else "normal",
                linespacing=1.35)

    def arrow(x1, y1, x2, y2):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", lw=0.8, color="#333333"))

    f = lambda n: f"{n:,}"
    win = len(main) + len(mil)
    pre = len(hist) - win
    box(22, 91, 56, 7.5, f"Records retrieved from the ASN Accident Database\n(1919–2025; scraped 1924–2025 + manual 1919–1923)\nn = {f(n_raw)}")
    arrow(50, 91, 50, 83.5)
    box(66, 85.0, 32, 4.2, f"Removed: mis-dated duplicate\nrecord (n = {f(n_dropped)})", fc="#f4f4f4"); arrow(50, 87.1, 66, 87.1)
    box(22, 76, 56, 7.5, f"Historical cohort, 1919–2025\n(all operations, descriptive/sensitivity)\nn = {f(len(hist))}", bold=True)
    arrow(50, 76, 50, 66.5)
    box(66, 68.2, 32, 5.6, f"Excluded from main analysis:\nevents 1919–1969 (n = {f(pre)})", fc="#f4f4f4"); arrow(50, 71, 66, 71)
    box(22, 60, 56, 6.5, f"Events 1970–2025\nn = {f(win)}")
    arrow(38, 60, 27, 51.5); arrow(62, 60, 73, 51.5)
    box(3, 42, 48, 9.5, f"Main analysis: civil operations 1970–2025\nn = {f(len(main))}\n(includes nature unknown, n = {f(int((main['Nature_group']=='Unknown').sum()))})", bold=True, fc="#eef3f8")
    box(55, 42, 43, 9.5, f"Military stratum 1970–2025\n(analysed separately; sensitivity)\nn = {f(len(mil))}", bold=True, fc="#f4f4f4")
    arrow(27, 42, 27, 35.5)
    mk = int(main["Fatalities_known"].sum()); ml = int(main["Onboard_lethality"].notna().sum())
    box(3, 25, 48, 10.5, f"On-board fatalities known: n = {f(mk)}\n(unknown: n = {f(len(main)-mk)})\nFatal events: n = {f(int((main['Fatal_event']==1).sum()))}")
    arrow(27, 25, 27, 18.5)
    box(3, 8, 48, 10.5, f"Occupants > 0 and fatalities known\n(on-board lethality analyses): n = {f(ml)}\nIntentional acts (ASN category C) retained;\nexcluded in sensitivity: n = {f(int(main['Intentional_act'].sum()))}")
    arrow(76.5, 42, 76.5, 35.5)
    box(55, 25, 43, 10.5, f"On-board fatalities known: n = {f(int(mil['Fatalities_known'].sum()))}\nFatal events: n = {f(int((mil['Fatal_event']==1).sum()))}")
    fig.savefig(f"{path_stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(f"{path_stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ----------------------------------------------------------------------------------
# 7. DENOMINATORS (World Bank bulk CSV layout; ICAO long layout)
# ----------------------------------------------------------------------------------
def read_worldbank(path):
    """World Bank 'API_IS.AIR.xxxx_DS2_en_csv_v2_*.csv' (4 metadata lines, wide by year) -> long."""
    raw = pd.read_csv(path, skiprows=4)
    years = [c for c in raw.columns if re.fullmatch(r"\d{4}", str(c))]
    long = raw.melt(id_vars=["Country Code"], value_vars=years, var_name="Year", value_name="value")
    long["Year"] = long["Year"].astype(int)
    return long.rename(columns={"Country Code": "ISO3"}).dropna(subset=["value"])


def _fill_world(long):
    """The WDI world aggregate (WLD) equals the sum of reporting economies (verified: identical in 1971 and 1973) but
    is blank for 1972 in the downloaded files. Blank WLD years with country data are reconstructed as that sum."""
    iso = {v["ISO3"] for v in COUNTRY_MAP.values() if v["ISO3"]}
    w = long[long["ISO3"] == "WLD"].set_index("Year")["value"]
    csum = long[long["ISO3"].isin(iso)].groupby("Year")["value"].sum()
    miss = [y for y in csum.index if y not in w.index and csum[y] > 0 and y >= MAIN_START]
    add = pd.DataFrame({"ISO3": "WLD", "Year": miss, "value": [csum[y] for y in miss]})
    return pd.concat([long, add], ignore_index=True), miss


def build_denominators(folder="denominators"):
    """Returns (global_by_year, region_by_year) or (None, None) if files are not available yet.
    NOTE: World Bank/ICAO series attribute traffic to the State of REGISTRATION of the carrier, whereas
    ASN Country_Region is the State of OCCURRENCE. Global rates are unaffected; region-specific rates
    must be interpreted as 'deaths occurring in region per traffic of carriers registered in region'."""
    folder = Path(folder); parts = {}
    for key, fn in [("Passengers", "IS.AIR.PSGR.csv"), ("Departures", "IS.AIR.DPRT.csv")]:
        p = folder / fn
        if p.exists():
            parts[key] = _fill_world(read_worldbank(p))[0]
    p = folder / "icao_departures.csv"
    if p.exists():
        ic = pd.read_csv(p); ic.columns = [c.strip().lower() for c in ic.columns]
        parts["Departures"] = ic.rename(columns={"iso3": "ISO3", "year": "Year", "departures": "value"})[["ISO3", "Year", "value"]]
    if not parts:
        return None, None
    iso2who = {v["ISO3"]: v["WHO_region"] for v in COUNTRY_MAP.values() if v["ISO3"]}
    glob, reg = [], []
    for key, long in parts.items():
        g = long[long["ISO3"] == "WLD"][["Year", "value"]].rename(columns={"value": key}); glob.append(g.set_index("Year"))
        c = long[long["ISO3"].isin(iso2who)].copy(); c["WHO_region"] = c["ISO3"].map(iso2who)
        r = c.groupby(["Year", "WHO_region"])["value"].agg(**{key: "sum", f"{key}_n_countries": "count"}); reg.append(r)
    return pd.concat(glob, axis=1).reset_index(), pd.concat(reg, axis=1).reset_index()


def denominators_template(path):
    regs = ["WLD", "AFR", "AMR", "EMR", "EUR", "SEAR", "WPR"]
    t = pd.DataFrame([(y, r) for y in range(MAIN_START, MAIN_END + 1) for r in regs], columns=["Year", "Region"])
    t["Passengers"] = np.nan; t["Departures"] = np.nan; t["Source"] = ""
    t.to_csv(path, index=False)


# ----------------------------------------------------------------------------------
# 8. DATA DICTIONARY
# ----------------------------------------------------------------------------------
DICTIONARY = [
    # name, type, origin, definition
    ("ID", "integer", "ASN matrix", "Row identifier in the cleaned matrix."),
    ("Date / Year / Decade", "text / integer", "ASN / derived", "Event date as published by ASN (DD MON YYYY; XX = unknown). Year and decade extracted from the last four digits."),
    ("Date_parsed, Date_precision", "date, category", "derived", "Parsed calendar date when day known; precision = day / month / year."),
    ("Type", "text", "ASN", "Aircraft type and variant as published."),
    ("Aircraft_family", "category", "derived (mapping table)", "Type family obtained from ordered regular-expression rules (sheet Type_mapping)."),
    ("Manufacturer_ASN", "category", "derived", "Manufacturer as named in ASN type string (harmonised spelling, licence builders merged)."),
    ("Manufacturer_group", "category", "derived (mapping table)", "Corporate lineage group (e.g. Douglas/McDonnell Douglas; de Havilland Canada/Bombardier)."),
    ("Propulsion", "category", "derived (mapping table)", "Jet / Turboprop / Piston / Rotorcraft / Unknown. Validated against the Engines string where available."),
    ("Seats_typical", "integer", "derived (mapping table)", "Typical maximum single-class seating of the family (approximate reference value; passenger-capable types only)."),
    ("Role, Wide_body", "category, 0/1", "derived (mapping table)", "PAX airliner/general transport; BIZ business jet; FRT purpose-built freighter or military airlifter; SPC special mission; HEL helicopter. Wide_body = twin-aisle."),
    ("Aircraft_class", "category", "derived", "Commuter (<=19 seats); Regional (20-100 seats); Narrow-body (>100 seats, single-aisle); Wide-body; Dedicated freighter/airlifter (purpose-built); Business jet; Other (special mission, rotorcraft); Unknown. Airframe-based: converted freighters keep their airframe class; cargo OPERATION is captured by Nature. Seat values are reference values to be verified before submission."),
    ("Year_built, Age_years, Age_cat", "integer, integer, category", "ASN / derived", "Age = event year - year of manufacture (negative or >90 set to missing). Categories <5, 5-14, 15-24, >=25, Unknown."),
    ("Operator, Registration, MSN_Cn, Engines", "text", "ASN", "As published."),
    ("Nature, Nature_group", "category", "ASN / cleaned matrix", "Nature of flight; grouped as Passenger (civil), Cargo, Executive/Private, Other civil, Military, Unknown."),
    ("Military", "0/1", "derived", "Nature_group = Military. Excluded from main analysis; analysed as separate stratum."),
    ("Military_operator_flag", "0/1", "derived", "Operator string suggests armed forces although Nature is not 'Military' (for sensitivity only)."),
    ("Phase, Phase_group", "category", "ASN / derived", "Ground (standing, taxi, pushback/towing); Take-off/initial climb; En route (cruise); Approach/landing; Manoeuvring/other (manoeuvring, combat); Unknown."),
    ("Country_Region, Country", "text", "ASN / derived", "State or area of OCCURRENCE (not of operator). Encoding variants harmonised."),
    ("ISO3, WHO_region, UN_subregion, Territory", "category", "derived", "ISO 3166-1 alpha-3; WHO region (AFR, AMR, EMR, EUR, SEAR, WPR; 'At sea'; 'Antarctica'; 'Unknown'); UN M49 sub-region; Territory=1 for non-Member areas assigned to the region of their geographic location."),
    ("At_sea, LatAm_flag", "0/1", "derived", "Occurrence over ocean/sea; Latin America = 20 Latin American republics + Puerto Rico."),
    ("Total_on_board", "integer", "ASN", "Occupants (crew + passengers). ASN crew/passenger split is not available to non-registered users (columns empty)."),
    ("Total_fatalities", "integer", "ASN (corrected)", "On-board fatalities of THIS aircraft."),
    ("Other_fatalities_raw", "integer", "ASN", "ASN 'Other fatalities': ground victims AND occupants of the other aircraft in collisions."),
    ("Collision_partner_ID, Collision_partner_fatalities", "integer", "derived", "Counterpart record in the database for collisions; its on-board deaths."),
    ("Ground_fatalities", "integer", "derived", "Other_fatalities_raw minus collision-partner on-board deaths already counted in the database (avoids double counting). Includes victims in third-party aircraft NOT in the database."),
    ("Fatalities_known, Fatal_event", "boolean, 0/1/NA", "derived", "Fatal event = at least one on-board fatality; NA when fatalities unknown."),
    ("Onboard_lethality", "proportion", "derived", "Total_fatalities / Total_on_board, when occupants > 0 and both known."),
    ("Airplane_damage, Hull_loss_3", "category", "ASN / derived", "Hull loss Yes (destroyed, written off, missing) / No / Unknown (damage missing or unknown). NOTE: the original Hull_loss column coded unknown damage as 'No'."),
    ("ASN_Category, Intentional_act", "category, 0/1", "cleaned matrix / derived", "A accident, I incident, H hijacking, C criminal occurrence, O other, U unknown; 1 hull loss, 2 repairable. Intentional_act = category C."),
    ("Status, Confidence_Rating", "category", "ASN", "Level of information (final report / official preliminary / media only)."),
    ("Narrative, Probable_cause, Source, ASN_URL", "text", "ASN", "Free text; ASN_URL = record URL (unique key)."),
]


# ----------------------------------------------------------------------------------
# 9. PHASE 1 DRIVER
# ----------------------------------------------------------------------------------
def style_xlsx(path):
    from openpyxl import load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    wb = load_workbook(path)
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                c.font = Font(name="Arial", size=9, bold=(c.row == 1))
                c.alignment = Alignment(vertical="top", wrap_text=(c.row > 1 and isinstance(c.value, str) and len(c.value) > 60))
        for c in ws[1]:
            c.fill = PatternFill("solid", fgColor="D9E2EC")
        ws.freeze_panes = "A2"
        for col in ws.columns:
            w = max((len(str(c.value)) if c.value is not None else 0) for c in col[:200])
            ws.column_dimensions[col[0].column_letter].width = min(max(10, w + 2), 70)
    wb.save(path)


def phase1(data_path):
    OUT.mkdir(exist_ok=True)
    raw = load_raw(data_path); n_raw = len(raw)
    cor, corr_log = apply_corrections(raw); n_dropped = n_raw - len(cor)
    cor, pairs = dedup_collision_fatalities(cor)
    df = derive(cor)
    hist, main, mil, flow = populations(df, n_raw, n_dropped)

    # approved mapping override -------------------------------------------------
    ap = Path("type_mapping_approved.csv")
    if ap.exists():
        amap = pd.read_csv(ap).drop_duplicates("Type").set_index("Type")
        for col in ["Aircraft_family", "Manufacturer_group", "Propulsion", "Seats_typical", "Role", "Wide_body"]:
            if col in amap.columns:
                df[col] = df["Type"].map(amap[col]).combine_first(df[col])
        df["Aircraft_class"] = [aircraft_class(r, s, w) for r, s, w in zip(df["Role"], df["Seats_typical"], df["Wide_body"])]
        hist, main, mil, flow = populations(df, n_raw, n_dropped)

    # ---- tables
    core = ["Date", "Time", "Type", "Operator", "Registration", "MSN_Cn", "Year_built", "Engines", "Total_airframe_hrs",
            "Cycles", "Crew_on_board", "Crew_fatalities", "Passengers_on_board", "Passengers_fatalities",
            "Total_on_board", "Total_fatalities", "Ground_casualties", "Airplane_damage", "Location", "Country_Region",
            "Phase", "Nature", "Departure_airport", "Destination_airport", "Flightnumber", "Probable_cause",
            "Confidence_Rating", "Aircraft_family", "Propulsion", "Aircraft_class", "Age_years", "Phase_group",
            "WHO_region", "Hull_loss_3", "Fatal_event", "Onboard_lethality"]
    miss = missingness(df, core).merge(missingness(main, core)[["Variable", "Missing_or_unknown_pct"]]
                                        .rename(columns={"Missing_or_unknown_pct": "Main_1970_2025_missing_or_unknown_pct"}),
                                        on="Variable")
    miss = miss.rename(columns={"Missing_or_unknown_pct": "All_missing_or_unknown_pct"})

    cover = df.groupby("Decade").agg(Events=("ID", "size"), Military=("Military", "sum"),
                                     Fatalities_unknown=("Fatalities_known", lambda s: int((~s).sum())),
                                     Occupants_unknown=("Total_on_board", lambda s: int(s.isna().sum())),
                                     Onboard_fatalities=("Total_fatalities", "sum"),
                                     Ground_fatalities=("Ground_fatalities", "sum")).reset_index()
    cover["Civil"] = cover["Events"] - cover["Military"]

    def pop_summary(d, name):
        return dict(Population=name, Events=len(d), Years=f"{d['Year'].min()}-{d['Year'].max()}",
                    Fatal_events=int((d["Fatal_event"] == 1).sum()),
                    Fatalities_unknown=int((~d["Fatalities_known"]).sum()),
                    Onboard_fatalities=int(d["Total_fatalities"].sum()),
                    Ground_fatalities_dedup=int(d["Ground_fatalities"].sum()),
                    Other_fatalities_ASN_raw=int(d["Other_fatalities_raw"].sum()),
                    Occupants_known_sum=int(d["Total_on_board"].sum()),
                    Hull_losses=int((d["Hull_loss_3"] == "Yes").sum()),
                    Countries_areas=d.loc[d["ISO3"].notna(), "ISO3"].nunique())
    pops = pd.DataFrame([pop_summary(hist, "Historical 1919-2025 (all)"),
                         pop_summary(hist[hist["Military"] == 0], "Historical 1919-2025 (civil)"),
                         pop_summary(main, "Main: civil 1970-2025"),
                         pop_summary(mil, "Military stratum 1970-2025")])

    # ---- type mapping for approval
    fam = (df.groupby(["Aircraft_family", "Manufacturer_group", "Propulsion", "Seats_typical", "Role", "Wide_body",
                       "Aircraft_class"], dropna=False)
             .agg(n_all=("ID", "size"), n_main=("Year", lambda s: int(((s >= MAIN_START) & (df.loc[s.index, "Military"] == 0)).sum())),
                  example_types=("Type", lambda s: "; ".join(s.value_counts().head(4).index)))
             .reset_index().sort_values("n_main", ascending=False))
    typ = (df.groupby(["Type", "Aircraft_family", "Manufacturer_ASN", "Manufacturer_group", "Propulsion", "Seats_typical",
                       "Role", "Wide_body", "Aircraft_class"], dropna=False)
             .agg(n_all=("ID", "size"), n_main=("Year", lambda s: int(((s >= MAIN_START) & (df.loc[s.index, "Military"] == 0)).sum())))
             .reset_index().sort_values(["Aircraft_family", "n_all"], ascending=[True, False]))
    unm = typ[typ["Aircraft_family"] == "Unmapped"].sort_values("n_all", ascending=False)
    chk = df[df["Propulsion_engine_check"].notna() & ~df["Propulsion"].isin(["Unknown", "Rotorcraft"])]
    agree = pd.crosstab(chk["Propulsion"], chk["Propulsion_engine_check"])
    disc = (chk[chk["Propulsion"] != chk["Propulsion_engine_check"]]
            .groupby(["Type", "Engines", "Propulsion", "Propulsion_engine_check"]).size().reset_index(name="n")
            .sort_values("n", ascending=False))
    cov = pd.DataFrame([
        dict(Population="All records", n=len(df), Mapped_pct=round(100 * (~df["Aircraft_family"].isin(["Unmapped", "Unknown"])).mean(), 2)),
        dict(Population="Main analysis", n=len(main), Mapped_pct=round(100 * (~main["Aircraft_family"].isin(["Unmapped", "Unknown"])).mean(), 2)),
        dict(Population="Engine-string validation (records with engine info)", n=len(chk),
             Mapped_pct=round(100 * (chk["Propulsion"] == chk["Propulsion_engine_check"]).mean(), 2)),
    ])
    class_tab = pd.crosstab(main["Aircraft_class"], main["Propulsion"], margins=True).reset_index()

    with pd.ExcelWriter(OUT / "P1_type_mapping_for_approval.xlsx") as w:
        cov.to_excel(w, sheet_name="Coverage", index=False)
        fam.to_excel(w, sheet_name="Family_mapping", index=False)
        class_tab.to_excel(w, sheet_name="Class_x_propulsion_main", index=False)
        typ.to_excel(w, sheet_name="Type_level", index=False)
        unm.to_excel(w, sheet_name="Unmapped_types", index=False)
        agree.reset_index().to_excel(w, sheet_name="Engine_check_agreement", index=False)
        disc.to_excel(w, sheet_name="Engine_check_discrepancies", index=False)
    style_xlsx(OUT / "P1_type_mapping_for_approval.xlsx")

    geo = (df.groupby(["Country", "ISO3", "WHO_region", "UN_subregion", "Territory", "LatAm_flag"], dropna=False)
             .agg(n_all=("ID", "size")).reset_index().sort_values(["WHO_region", "UN_subregion", "Country"]))
    who_tab = (main.groupby("WHO_region").agg(Events=("ID", "size"), Onboard_fatalities=("Total_fatalities", "sum"))
               .reset_index())

    with pd.ExcelWriter(OUT / "P1_tables.xlsx") as w:
        flow.to_excel(w, sheet_name="Flow_STROBE", index=False)
        pops.to_excel(w, sheet_name="Populations", index=False)
        miss.to_excel(w, sheet_name="Missingness", index=False)
        cover.to_excel(w, sheet_name="Coverage_by_decade", index=False)
        corr_log.to_excel(w, sheet_name="Corrections_log", index=False)
        pairs.to_excel(w, sheet_name="Collision_pairs", index=False)
        geo.to_excel(w, sheet_name="Country_WHO_mapping", index=False)
        who_tab.to_excel(w, sheet_name="Main_by_WHO_region", index=False)
        pd.DataFrame(sorted(PHASE_GROUP.items()), columns=["ASN_phase", "Phase_group"]).to_excel(w, sheet_name="Phase_mapping", index=False)
    style_xlsx(OUT / "P1_tables.xlsx")

    pd.DataFrame(DICTIONARY, columns=["Variable", "Type", "Origin", "Definition"]).to_excel(OUT / "P1_data_dictionary.xlsx", index=False)
    style_xlsx(OUT / "P1_data_dictionary.xlsx")

    flow_figure(df, hist, main, mil, n_raw, n_dropped, str(OUT / "P1_flow_STROBE"))
    denominators_template(OUT / "denominators_template.csv")
    g, r = build_denominators()
    if g is not None:
        g.to_csv(OUT / "denominators_global.csv", index=False); r.to_csv(OUT / "denominators_by_WHO_region.csv", index=False)

    keep = [c for c in df.columns if c not in ("Leased_from", "Crew_on_board", "Crew_fatalities", "Passengers_on_board",
                                               "Passengers_fatalities", "Flightnumber", "Follow_up_safety_actions")]
    df[keep].to_csv(OUT / "asn_analytic.csv", index=False)
    print(flow.to_string(index=False)); print(); print(pops.T.to_string()); print(); print(cov.to_string(index=False))
    return df, hist, main, mil



# ==================================================================================
# 10. PHASE 2 — DESCRIPTIVE ANALYSIS (Tables 1-2, Figures 1-4, supplementary tables)
# ==================================================================================
WHO_ORDER = ["AFR", "AMR", "EMR", "EUR", "SEAR", "WPR", "At sea", "Antarctica", "Unknown"]
WHO_LABEL = {"AFR": "African Region", "AMR": "Region of the Americas", "EMR": "Eastern Mediterranean Region",
             "EUR": "European Region", "SEAR": "South-East Asia Region", "WPR": "Western Pacific Region",
             "At sea": "At sea (international waters)", "Antarctica": "Antarctica", "Unknown": "Unknown location"}
NATURE_ORDER = ["Passenger (civil)", "Cargo", "Executive/Private", "Other civil (ferry, training, test, survey…)", "Unknown"]
PROP_ORDER = ["Jet", "Turboprop", "Piston", "Rotorcraft", "Unknown"]
AGE_ORDER = AGE_LABELS + ["Unknown"]
NE_URL = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_{res}_admin_0_countries.geojson"
PAL = dict(ink="#222222", grey="#8a8f98", light="#d9dde3", blue="#2f5d8a", red="#a63d40", teal="#3b8686",
           ochre="#c08a2b", purple="#6b5b95")


def decade_label(d):
    return "2020–2025" if d == 2020 else f"{d}–{d + 9}"


def summarise(d):
    """Core descriptive metrics for a set of aircraft-level records."""
    k = d[d["Fatalities_known"]]
    L = d[d["Onboard_lethality"].notna()]
    F = L[L["Total_fatalities"] > 0]
    fe = int((k["Fatal_event"] == 1).sum())
    hk = d[d["Hull_loss_3"] != "Unknown"]
    onb = float(k["Total_fatalities"].sum()); gr = float(d["Ground_fatalities"].sum())
    return dict(
        Events=len(d), Fatalities_unknown=int(len(d) - len(k)), Fatal_events=fe,
        Fatal_events_pct=round(100 * fe / len(k), 1) if len(k) else np.nan,
        Onboard_deaths=int(onb), Ground_deaths=int(gr), Total_deaths=int(onb + gr),
        Occupants_known=int(L["Total_on_board"].sum()), Events_with_occupants=len(L),
        Onboard_lethality_pct=round(100 * L["Total_fatalities"].sum() / L["Total_on_board"].sum(), 1) if L["Total_on_board"].sum() else np.nan,
        Lethality_in_fatal_events_pct=round(100 * F["Total_fatalities"].sum() / F["Total_on_board"].sum(), 1) if len(F) else np.nan,
        Deaths_per_fatal_event=round(onb / fe, 1) if fe else np.nan,
        Hull_losses=int((d["Hull_loss_3"] == "Yes").sum()),
        Hull_loss_pct=round(100 * (hk["Hull_loss_3"] == "Yes").mean(), 1) if len(hk) else np.nan)


def group_table(d, by, order=None, label=None, total=True, top=None, other_label="All others"):
    d = d.copy()
    if top:
        keep = d.groupby(by)["ID"].size().sort_values(ascending=False).head(top).index
        d[by] = np.where(d[by].isin(keep), d[by], other_label)
        order = list(keep) + [other_label]
    rows = []
    levels = order if order is not None else sorted(d[by].dropna().unique())
    for lv in levels:
        g = d[d[by] == lv]
        if len(g) == 0:
            continue
        rows.append({"Characteristic": label or by, "Category": lv, **summarise(g)})
    out = pd.DataFrame(rows)
    out.insert(3, "Events_pct", (100 * out["Events"] / len(d)).round(1))
    tot = d.loc[d["Fatalities_known"], "Total_fatalities"].sum()
    out.insert(out.columns.get_loc("Onboard_deaths") + 1, "Onboard_deaths_pct", (100 * out["Onboard_deaths"] / tot).round(1))
    if total:
        t = {"Characteristic": label or by, "Category": "Total", **summarise(d), "Events_pct": 100.0, "Onboard_deaths_pct": 100.0}
        out = pd.concat([out, pd.DataFrame([t])], ignore_index=True)
    return out


def wilson(k, n, z=1.959964):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n; den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (100 * (c - h), 100 * (c + h))


def boot_ratio(num, den, B=2000, seed=20250918):
    """Percentile bootstrap (events resampled) for a pooled ratio sum(num)/sum(den)."""
    num = np.asarray(num, float); den = np.asarray(den, float); n = len(num)
    if n < 5:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(B, n))
    r = num[idx].sum(1) / den[idx].sum(1)
    return tuple(100 * np.percentile(r, [2.5, 97.5]))


def lethality_metrics(d, by, order):
    rows = []
    for lv in order:
        g = d[d[by] == lv]
        k = g[g["Fatalities_known"]]; L = g[g["Onboard_lethality"].notna()]; F = L[L["Total_fatalities"] > 0]
        if len(k) == 0:
            continue
        fe = int((k["Fatal_event"] == 1).sum()); lo, hi = wilson(fe, len(k))
        pl = 100 * L["Total_fatalities"].sum() / L["Total_on_board"].sum() if len(L) else np.nan
        plo, phi = boot_ratio(L["Total_fatalities"], L["Total_on_board"]) if len(L) else (np.nan, np.nan)
        cl = 100 * F["Total_fatalities"].sum() / F["Total_on_board"].sum() if len(F) else np.nan
        clo, chi = boot_ratio(F["Total_fatalities"], F["Total_on_board"]) if len(F) else (np.nan, np.nan)
        rows.append(dict(Group=lv, n_known=len(k), Fatal_events=fe, Fatal_pct=100 * fe / len(k), Fatal_lo=lo, Fatal_hi=hi,
                         n_lethality=len(L), Lethality_pct=pl, Lethality_lo=plo, Lethality_hi=phi,
                         n_fatal_with_occupants=len(F), Cond_lethality_pct=cl, Cond_lo=clo, Cond_hi=chi))
    return pd.DataFrame(rows)


def occurrence_ids(df):
    """Union of collision partners -> one occurrence identifier (used ONLY for the 'deadliest occurrences' table)."""
    parent = {i: i for i in df["ID"]}
    def find(x):
        parent.setdefault(x, x)                      # partner outside the subset (e.g. military counterpart)
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for a, b in df.loc[df["Collision_partner_ID"].notna(), ["ID", "Collision_partner_ID"]].itertuples(index=False):
        ra, rb = find(int(a)), find(int(b))
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)
    return df["ID"].map(find)


def deadliest_occurrences(df, main, n=20):
    w = df[df["Year"].between(MAIN_START, MAIN_END)].copy()
    w["Occurrence_ID"] = occurrence_ids(w)
    w["In_main"] = w["ID"].isin(main["ID"])
    j = lambda s: " / ".join(dict.fromkeys(str(x) for x in s if pd.notna(x)))
    g = w.groupby("Occurrence_ID").agg(
        Date=("Date", "first"), Aircraft=("Type", j), Operator=("Operator", j), Location=("Location", "first"),
        Country=("Country", "first"), Phase=("Phase", j), Nature=("Nature", j), ASN_category=("ASN_Category", j),
        n_aircraft=("ID", "size"), Occupants=("Total_on_board", "sum"), Onboard_deaths=("Total_fatalities", "sum"),
        Ground_deaths=("Ground_fatalities", "sum"), Any_main=("In_main", "any"), Any_military=("Military", "max"),
        ASN_URL=("ASN_URL", j)).reset_index()
    g = g[g["Any_main"]]
    g["Total_deaths"] = g["Onboard_deaths"] + g["Ground_deaths"]
    g = g.sort_values(["Total_deaths", "Onboard_deaths"], ascending=False).head(n).reset_index(drop=True)
    g.insert(0, "Rank", g.index + 1)
    return g.drop(columns=["Any_main", "Occurrence_ID"])


def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    if n == 0 or x.sum() == 0:
        return np.nan
    return float((2 * np.sum(np.arange(1, n + 1) * x) / (n * x.sum())) - (n + 1) / n)


def concentration(main):
    k = main[main["Fatalities_known"]]
    rows = []
    for name, x in [("All events with known on-board fatalities", k["Total_fatalities"].values),
                    ("Fatal events only", k.loc[k["Total_fatalities"] > 0, "Total_fatalities"].values)]:
        xs = np.sort(x)[::-1]; tot = xs.sum(); n = len(xs)
        r = dict(Population=name, Events=n, Onboard_deaths=int(tot), Gini=round(gini(x), 3))
        for p in (0.01, 0.05, 0.10, 0.20):
            m = max(1, int(np.ceil(p * n)))
            r[f"Top_{int(p*100)}pct_events_n"] = m
            r[f"Top_{int(p*100)}pct_share_of_deaths_pct"] = round(100 * xs[:m].sum() / tot, 1)
        rows.append(r)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- figure helpers
def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    have = {f.name for f in font_manager.fontManager.ttflist}
    fam = next((f for f in ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"] if f in have), "sans-serif")
    plt.rcParams.update({"font.family": fam, "font.size": 8, "axes.linewidth": 0.6,
                         "axes.spines.top": False, "axes.spines.right": False, "xtick.major.width": 0.6,
                         "ytick.major.width": 0.6, "xtick.major.size": 3, "ytick.major.size": 3,
                         "axes.labelsize": 8.5, "legend.frameon": False, "legend.fontsize": 7.5,
                         "pdf.fonttype": 42, "svg.fonttype": "none", "figure.facecolor": "white"})
    return plt


def _save(fig, stem):
    fig.savefig(OUT / f"{stem}.png", dpi=400, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    import matplotlib.pyplot as plt
    plt.close(fig)


def fig1_annual(annual, rates):
    plt = _mpl()
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.bar(annual["Year"], annual["Onboard_deaths"], width=0.8, color=PAL["light"], edgecolor=PAL["grey"], lw=0.3,
           label="On-board deaths (left axis)")
    ma = annual["Onboard_deaths"].rolling(5, center=True).mean()
    ax.plot(annual["Year"], ma, color=PAL["ink"], lw=1.0, label="5-year centred moving average (left axis)")
    ax.set_ylabel("On-board deaths per year"); ax.set_xlabel("Year"); ax.set_xlim(MAIN_START - 1, MAIN_END + 1)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{int(v):,}"))
    ax2 = ax.twinx(); ax2.spines["right"].set_visible(True); ax2.spines["right"].set_linewidth(0.6)
    if rates is not None and "Deaths_per_million_passengers" in rates and rates["Deaths_per_million_passengers"].notna().any():
        r = rates.dropna(subset=["Deaths_per_million_passengers"])
        ax2.plot(r["Year"], r["Deaths_per_million_passengers"], color=PAL["red"], lw=1.1, marker="o", ms=2.2,
                 label="Deaths per million passengers carried (right axis)")
        ax2.set_yscale("log"); ax2.set_ylabel("On-board deaths per million passengers carried (log scale)", color=PAL["red"])
        stem = "P2_Fig1_annual_deaths_rate"
    else:
        ax2.plot(annual["Year"], annual["Fatal_events"], color=PAL["red"], lw=1.0, marker="o", ms=2.0,
                 label="Fatal events (right axis)")
        ax2.set_ylabel("Fatal events per year", color=PAL["red"]); ax2.set_ylim(0, None)
        stem = "P2_Fig1_annual_deaths_PROVISIONAL_no_denominator"
    ax2.tick_params(axis="y", colors=PAL["red"])
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper right")
    _save(fig, stem); return stem


def fig2_lethality(by_dec, by_phase):
    plt = _mpl()
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.4), sharey=True, gridspec_kw=dict(width_ratios=[6, 5], wspace=0.06))
    series = [("Fatal_pct", "Fatal_lo", "Fatal_hi", "Events with ≥1 on-board death", PAL["blue"], "o"),
              ("Lethality_pct", "Lethality_lo", "Lethality_hi", "On-board lethality, all events", PAL["red"], "s"),
              ("Cond_lethality_pct", "Cond_lo", "Cond_hi", "On-board lethality, fatal events only", PAL["ochre"], "^")]
    for ax, t, lab in [(axes[0], by_dec, "A"), (axes[1], by_phase, "B")]:
        x = np.arange(len(t))
        for j, (v, lo, hi, name, col, mk) in enumerate(series):
            xx = x + (j - 1) * 0.18
            ax.errorbar(xx, t[v], yerr=[t[v] - t[lo], t[hi] - t[v]], fmt=mk, ms=3.6, color=col, ecolor=col, elinewidth=0.7,
                        capsize=1.8, capthick=0.7, lw=0, label=name)
            if lab == "A":
                ax.plot(xx, t[v], color=col, lw=0.6, alpha=0.6)
        ax.set_xticks(x); ax.set_xticklabels([str(g).replace(" (cruise)", "").replace("/", "/\n") for g in t["Group"]], fontsize=7.2 if lab == "A" else 6.3)
        ax.set_ylim(0, 100); ax.grid(axis="y", lw=0.3, color=PAL["light"]); ax.set_axisbelow(True)
        ax.text(-0.02 if lab == "B" else -0.11, 1.03, lab, transform=ax.transAxes, fontsize=11, weight="bold")
    axes[0].set_ylabel("Per cent (95% CI)"); axes[0].set_xlabel("Decade"); axes[1].set_xlabel("Phase of flight")
    axes[0].legend(loc="upper center", bbox_to_anchor=(0.95, -0.2), ncol=3)
    _save(fig, "P2_Fig2_lethality_decade_phase")


_ROB = np.array([[0, 1.0000, 0.0000], [5, 0.9986, 0.0620], [10, 0.9954, 0.1240], [15, 0.9900, 0.1860], [20, 0.9822, 0.2480],
                 [25, 0.9730, 0.3100], [30, 0.9600, 0.3720], [35, 0.9427, 0.4340], [40, 0.9216, 0.4958], [45, 0.8962, 0.5571],
                 [50, 0.8679, 0.6176], [55, 0.8350, 0.6769], [60, 0.7986, 0.7346], [65, 0.7597, 0.7903], [70, 0.7186, 0.8435],
                 [75, 0.6732, 0.8936], [80, 0.6213, 0.9394], [85, 0.5722, 0.9761], [90, 0.5322, 1.0000]])


def robinson(lon, lat):
    lon = np.asarray(lon, float); lat = np.asarray(lat, float); a = np.abs(lat)
    X = np.interp(a, _ROB[:, 0], _ROB[:, 1]); Y = np.interp(a, _ROB[:, 0], _ROB[:, 2])
    return 0.8487 * X * np.radians(lon), 1.3523 * Y * np.sign(lat)


def load_geo(res):
    import json, urllib.request
    p = Path("geo"); p.mkdir(exist_ok=True); f = p / f"ne_{res}.geojson"
    if not f.exists():
        urllib.request.urlretrieve(NE_URL.format(res=res), f)
    fix = {"KOS": "XKX", "SOL": "SOM", "CYN": "CYP", "SDS": "SSD", "PSX": "PSE", "SAH": "ESH"}
    feats = []
    for ft in json.load(open(f, encoding="utf-8"))["features"]:
        pr = ft["properties"]; iso = pr.get("ISO_A3_EH") or "-99"
        if iso == "-99":
            iso = pr.get("ADM0_A3")
        iso = fix.get(iso, iso)
        gm = ft["geometry"]; polys = gm["coordinates"] if gm["type"] == "MultiPolygon" else [gm["coordinates"]]
        feats.append((iso, [np.asarray(ring[0]) for ring in polys]))
    return feats


def _draw_map(ax, feats, values, bins, colors, proj, extent=None, only=None):
    from matplotlib.collections import PolyCollection
    polys, fcs = [], []
    for iso, rings in feats:
        if iso == "ATA" and extent is None:
            continue
        v = values.get(iso, 0)
        c = "#f3f3f1" if v <= 0 else colors[int(np.digitize(v, bins)) - 1]
        if only is not None and iso not in only:
            c = "#e3e3e3"
        for r in rings:
            x, y = proj(r[:, 0], r[:, 1]); polys.append(np.column_stack([x, y])); fcs.append(c)
    ax.add_collection(PolyCollection(polys, facecolors=fcs, edgecolors="#6f6f6f", linewidths=0.2))
    ax.set_aspect("equal"); ax.axis("off")
    if extent is None:
        t = np.linspace(-90, 90, 181)
        xl, yl = proj(np.full_like(t, -180), t); xr, yr = proj(np.full_like(t, 180), t)
        ax.plot(np.r_[xl, xr[::-1], xl[:1]], np.r_[yl, yr[::-1], yl[:1]], color="#9a9a9a", lw=0.4)
        ax.set_xlim(xl.min() * 1.01, xr.max() * 1.01); ax.set_ylim(yl.min() * 1.02, yl.max() * 1.02)
    else:
        ax.set_xlim(extent[0], extent[1]); ax.set_ylim(extent[2], extent[3])


def fig3_maps(main):
    plt = _mpl()
    from matplotlib.patches import Patch
    d = main[main["ISO3"].notna()].copy()
    d["Deaths"] = d["Total_fatalities"].fillna(0) + d["Ground_fatalities"]
    val = d.groupby("ISO3")["Deaths"].sum().to_dict()
    bins = [1, 50, 200, 500, 1000, 3000, 1e9]
    labels = ["1–49", "50–199", "200–499", "500–999", "1,000–2,999", "≥3,000"]
    colors = ["#fde9d9", "#f9c9a8", "#f09d77", "#dc6a51", "#b83c3a", "#7f1d2d"]
    fig = plt.figure(figsize=(7.2, 7.7))
    axA = fig.add_axes([0.0, 0.50, 1.0, 0.50]); axB = fig.add_axes([0.0, 0.0, 0.50, 0.43])
    _draw_map(axA, load_geo("110m"), val, bins, colors, robinson)
    eq = lambda lon, lat: (np.asarray(lon, float), np.asarray(lat, float))
    _draw_map(axB, load_geo("50m"), val, bins, colors, eq, extent=(-120, -32, -57, 34), only=LATAM_ISO)
    axA.text(0.01, 0.95, "A", transform=axA.transAxes, fontsize=11, weight="bold")
    axB.text(0.0, 1.01, "B", transform=axB.transAxes, fontsize=11, weight="bold")
    lat = d[d["LatAm_flag"]].groupby("Country")["Deaths"].sum().sort_values(ascending=True).tail(15)
    axC = fig.add_axes([0.68, 0.05, 0.30, 0.36])
    axC.barh(lat.index, lat.values, color=PAL["red"], height=0.65, alpha=0.85)
    for y, v in enumerate(lat.values):
        axC.text(v, y, f" {int(v):,}", va="center", fontsize=6.5)
    axC.set_xlabel("Deaths, 1970–2025"); axC.tick_params(axis="y", labelsize=7, length=0); axC.set_xlim(0, lat.max() * 1.18)
    axC.text(-0.62, 1.03, "C", transform=axC.transAxes, fontsize=11, weight="bold")
    hs = [Patch(fc="#f3f3f1", ec="#6f6f6f", lw=0.3, label="0 / no record")] + [Patch(fc=c, ec="#6f6f6f", lw=0.3, label=l) for c, l in zip(colors, labels)]
    fig.legend(handles=hs, title="Deaths (on board + ground), 1970–2025", loc="center", bbox_to_anchor=(0.5, 0.475), ncol=7,
               fontsize=7, title_fontsize=7.5, handlelength=1.2, columnspacing=1.0)
    _save(fig, "P2_Fig3_maps_deaths_by_country")
    return pd.Series(val, name="Deaths").sort_values(ascending=False)


def fig4_heatmap(main):
    plt = _mpl()
    ph = [p for p in PHASE_ORDER]; decs = sorted(main["Decade"].unique())
    A = np.full((len(ph), len(decs)), np.nan); Bm = A.copy(); N = A.copy()
    for i, p in enumerate(ph):
        for j, dc in enumerate(decs):
            g = main[(main["Phase_group"] == p) & (main["Decade"] == dc)]; L = g[g["Onboard_lethality"].notna()]
            N[i, j] = len(g); A[i, j] = g["Total_fatalities"].sum()
            if len(L) >= 10 and L["Total_on_board"].sum() > 0:
                Bm[i, j] = 100 * L["Total_fatalities"].sum() / L["Total_on_board"].sum()
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw=dict(wspace=0.08))
    for ax, M, cmap, lab, fmt, ttl in [(axes[0], A, "Reds", "A", lambda v: f"{int(v):,}", "On-board deaths"),
                                       (axes[1], Bm, "Blues", "B", lambda v: f"{v:.1f}" if v < 10 else f"{v:.0f}", "On-board lethality (%)")]:
        im = ax.imshow(M, cmap=cmap, aspect="auto", vmin=0, vmax=np.nanmax(M) * 1.15)
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                if not np.isnan(M[i, j]):
                    ax.text(j, i, fmt(M[i, j]), ha="center", va="center", fontsize=6.6,
                            color="white" if M[i, j] > np.nanmax(M) * 0.6 else PAL["ink"])
                else:
                    ax.text(j, i, "–", ha="center", va="center", fontsize=6.6, color=PAL["grey"])
        ax.set_xticks(range(len(decs))); ax.set_xticklabels([f"{d}s" if d != 2020 else "2020–25" for d in decs], fontsize=7)
        ax.set_yticks(range(len(ph))); ax.set_yticklabels(ph if lab == "A" else [], fontsize=7.2)
        ax.tick_params(length=0); [sp.set_visible(False) for sp in ax.spines.values()]
        ax.set_title(ttl, fontsize=8.5, loc="left", pad=4); ax.text(-0.02 if lab == "B" else -0.42, 1.13, lab, transform=ax.transAxes, fontsize=11, weight="bold")
        ax.set_xticks(np.arange(-.5, len(decs), 1), minor=True); ax.set_yticks(np.arange(-.5, len(ph), 1), minor=True)
        ax.grid(which="minor", color="white", lw=1.2); ax.tick_params(which="minor", length=0)
    _save(fig, "P2_Fig4_heatmap_phase_decade")
    idx = pd.MultiIndex.from_product([ph, decs], names=["Phase_group", "Decade"])
    return pd.DataFrame({"Events": N.ravel(), "Onboard_deaths": A.ravel(), "Onboard_lethality_pct": np.round(Bm.ravel(), 1)}, index=idx).reset_index()


def figS1_lorenz(main):
    plt = _mpl()
    k = main[main["Fatalities_known"]]
    fig, ax = plt.subplots(figsize=(3.5, 3.4))
    for x, name, col in [(k["Total_fatalities"].values, "All events", PAL["blue"]),
                         (k.loc[k["Total_fatalities"] > 0, "Total_fatalities"].values, "Fatal events only", PAL["red"])]:
        xs = np.sort(x); cy = np.r_[0, np.cumsum(xs) / xs.sum()]; cx = np.linspace(0, 1, len(cy))
        ax.plot(100 * cx, 100 * cy, color=col, lw=1.1, label=f"{name} (Gini = {gini(x):.2f})")
    ax.plot([0, 100], [0, 100], color=PAL["grey"], lw=0.6, ls="--", label="Line of equality")
    ax.set_xlabel("Cumulative % of events (ranked by on-board deaths)"); ax.set_ylabel("Cumulative % of on-board deaths")
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.set_aspect("equal"); ax.legend(loc="upper left")
    _save(fig, "P2_FigS1_lorenz_concentration")


def compute_rates(cat):
    """Annual RATES use commercial air transport (CAT) numerators only, consistent with the traffic denominators.
    Returns (global, regional) or (None, None) when denominators are absent."""
    g, r = build_denominators()
    if g is None:
        return None, None
    G = annual_series(cat).merge(g, on="Year", how="left")
    R = pd.concat([annual_series(cat[cat["WHO_region"] == w]).assign(WHO_region=w) for w in ["AFR", "AMR", "EMR", "EUR", "SEAR", "WPR"]])
    R = R.merge(r, on=["Year", "WHO_region"], how="left")
    for T_ in (G, R):
        T_["Deaths_per_million_passengers"] = T_["Onboard_deaths"] / T_["Passengers"] * 1e6
        T_["Deaths_per_million_departures"] = T_["Onboard_deaths"] / T_["Departures"] * 1e6
        T_["Fatal_events_per_million_passengers"] = T_["Fatal_events"] / T_["Passengers"] * 1e6
        T_["Fatal_events_per_million_departures"] = T_["Fatal_events"] / T_["Departures"] * 1e6
        T_["Hull_losses_per_million_departures"] = T_["Hull_losses"] / T_["Departures"] * 1e6
    return G, R


def write_tables(path, sheets, notes=None):
    with pd.ExcelWriter(path) as w:
        if notes is not None:
            pd.DataFrame(notes, columns=["Sheet", "Title / notes"]).to_excel(w, sheet_name="README", index=False)
        for name, t in sheets.items():
            t.to_excel(w, sheet_name=name[:31], index=False)
    style_xlsx(path)


def phase2(df, hist, main, mil):
    OUT.mkdir(exist_ok=True)
    main = main.copy(); main["Decade_label"] = main["Decade"].map(decade_label)
    dec_order = [decade_label(d) for d in sorted(main["Decade"].unique())]

    # ---------------- Table 1: time and place
    t1 = pd.concat([group_table(main, "Decade_label", dec_order, "Decade"),
                    group_table(main, "WHO_region", WHO_ORDER, "WHO region of occurrence", total=False)], ignore_index=True)
    t1["Category"] = t1["Category"].replace(WHO_LABEL)
    # ---------------- Table 2: operational and aircraft characteristics
    t2 = pd.concat([
        group_table(main, "Nature_group", NATURE_ORDER, "Nature of flight", total=False),
        group_table(main, "Phase_group", PHASE_ORDER, "Phase of flight", total=False),
        group_table(main, "Propulsion", PROP_ORDER, "Propulsion", total=False),
        group_table(main, "Aircraft_class", CLASS_ORDER, "Aircraft class", total=False),
        group_table(main, "Manufacturer_group", label="Manufacturer group (top 10 by events)", total=False, top=10),
        group_table(main, "Age_cat", AGE_ORDER, "Aircraft age at event (years)", total=False),
        group_table(main, "Hull_loss_3", ["Yes", "No", "Unknown"], "Hull loss", total=False),
        group_table(main.assign(_c=np.where(main["Intentional_act"] == 1, "Intentional act (ASN category C)", "Accident/other")),
                    "_c", ["Accident/other", "Intentional act (ASN category C)"], "Occurrence type", total=True)], ignore_index=True)

    # ---------------- supplementary tables
    def per(d, keys):
        return pd.DataFrame([{**(dict(zip(keys, k if isinstance(k, tuple) else (k,)))), **summarise(g)} for k, g in d.groupby(keys)])
    annual = per(main, ["Year"])
    annual = pd.DataFrame({"Year": range(MAIN_START, MAIN_END + 1)}).merge(annual, on="Year", how="left").fillna(0)
    annual_reg = per(main, ["Year", "WHO_region"])
    dec_reg = per(main, ["WHO_region", "Decade_label"])
    cat = main[main["CAT"] == 1]
    annual_cat = per(cat, ["Year"])[["Year", "Events", "Fatal_events", "Onboard_deaths"]].rename(
        columns={"Events": "CAT_events", "Fatal_events": "CAT_fatal_events", "Onboard_deaths": "CAT_onboard_deaths"})

    ctry = per(main[main["ISO3"].notna()], ["Country", "ISO3", "WHO_region"])
    top_ev = ctry.sort_values("Events", ascending=False).head(20).reset_index(drop=True); top_ev.insert(0, "Rank", top_ev.index + 1)
    top_de = ctry.sort_values("Total_deaths", ascending=False).head(20).reset_index(drop=True); top_de.insert(0, "Rank", top_de.index + 1)
    latam = per(main[main["LatAm_flag"]], ["Country", "ISO3", "UN_subregion"]).sort_values("Total_deaths", ascending=False)
    latam = pd.concat([latam, pd.DataFrame([{"Country": "Latin America (total)", **summarise(main[main["LatAm_flag"]])}])], ignore_index=True)
    ecu_cols = ["Date", "Year", "Type", "Aircraft_class", "Propulsion", "Operator", "Registration", "Location", "Phase", "Nature",
                "Nature_group", "Military", "Total_on_board", "Total_fatalities", "Ground_fatalities", "Onboard_lethality",
                "Airplane_damage", "ASN_Category", "Age_years", "ASN_URL"]
    ecu = df[df["ISO3"] == "ECU"].sort_values(["Year", "Date_parsed"])[ecu_cols].copy()
    ecu.insert(0, "In_main_analysis", ecu["Year"].ge(MAIN_START) & ecu["Military"].eq(0))
    ecu_sum = pd.DataFrame([{"Population": n, **summarise(g)} for n, g in [
        ("Ecuador, civil 1970-2025 (main)", main[main["ISO3"] == "ECU"]),
        ("Ecuador, military 1970-2025", mil[mil["ISO3"] == "ECU"]),
        ("Ecuador, all records 1919-2025", df[df["ISO3"] == "ECU"])]])
    top20 = deadliest_occurrences(df, main)
    conc = concentration(main)
    hist_dec = pd.concat([per(hist.assign(Stratum="All operations"), ["Stratum", "Decade"]),
                          per(hist[hist["Military"] == 0].assign(Stratum="Civil"), ["Stratum", "Decade"]),
                          per(hist[hist["Military"] == 1].assign(Stratum="Military"), ["Stratum", "Decade"])], ignore_index=True)
    mil_dec = per(mil.assign(Decade_label=mil["Decade"].map(decade_label)), ["Decade_label"])
    sens = pd.DataFrame([{"Population": n, **summarise(g)} for n, g in [
        ("Main analysis (civil 1970-2025)", main),
        ("Excluding nature unknown", main[main["Nature_unknown"] == 0]),
        ("Excluding civil records with military operator", main[main["Military_operator_flag"] == 0]),
        ("Excluding both", main[(main["Nature_unknown"] == 0) & (main["Military_operator_flag"] == 0)]),
        ("Excluding intentional acts (ASN category C)", main[main["Intentional_act"] == 0]),
        ("Commercial air transport (CAT; numerator of all rates)", cat),
        ("Including military 1970-2025", pd.concat([main, mil]))]])

    by_dec = lethality_metrics(main, "Decade_label", dec_order)
    by_phase = lethality_metrics(main, "Phase_group", [p for p in PHASE_ORDER if p != "Unknown"])
    # ascertainment check: ASN coverage of non-hull-loss occurrences grows over time, so the same metrics are
    # also reported restricted to hull-loss events (stable inclusion criterion across decades)
    by_dec_hl = lethality_metrics(main[main["Hull_loss_3"] == "Yes"], "Decade_label", dec_order)
    by_dec["Group"] = [g.replace("–19", "–").replace("–20", "–") if False else g for g in by_dec["Group"]]

    # ---------------- rates (only if denominators are present)
    rates_g, rates_r = compute_rates(cat)

    # ---------------- figures
    if rates_g is not None:
        a_cat = pd.DataFrame({"Year": range(MAIN_START, MAIN_END + 1)}).merge(per(cat, ["Year"]), on="Year", how="left").fillna(0)
        fig1_final(a_cat.merge(world_denominators(), on="Year", how="left")); f1 = "P2_Fig1 (passengers) + P2_Fig1b (departures)"
    else:
        f1 = fig1_annual(annual, None)
    fd = by_dec.copy(); fd["Group"] = [f"{g[:4]}s" if not g.startswith("2020") else "2020–25" for g in fd["Group"]]
    fig2_lethality(fd, by_phase)
    deaths_iso = fig3_maps(main)
    hm = fig4_heatmap(main)
    figS1_lorenz(main)

    # ---------------- write
    notes_main = [("Table1", "Table 1. Aviation occurrences, fatal events, deaths and on-board lethality by decade and WHO region of occurrence, civil operations, ASN 1970-2025."),
                  ("Table2", "Table 2. Occurrences, deaths and on-board lethality by nature of flight, phase, propulsion, aircraft class, manufacturer group and aircraft age."),
                  ("Definitions", "Unit = aircraft-level record. Fatal_events_pct: denominator = events with known on-board fatalities. Onboard_lethality_pct = sum(on-board deaths)/sum(occupants) among events with occupants >0 and both known. Ground_deaths de-duplicated for collision partners (Supplementary collision-pair table). Aircraft-class seat values are reference values to be verified before submission. Decade 2020-2025 covers 6 years.")]
    write_tables(OUT / "P2_Tables_1_2.xlsx", {"Table1": t1, "Table2": t2}, notes_main)
    supp = {"S1_annual_global": annual, "S2_annual_by_WHO_region": annual_reg, "S3_decade_by_WHO_region": dec_reg,
            "S4_top20_countries_events": top_ev, "S5_top20_countries_deaths": top_de, "S6_all_countries": ctry.sort_values("Total_deaths", ascending=False),
            "S7_Latin_America": latam, "S8_Ecuador_summary": ecu_sum, "S9_Ecuador_events": ecu,
            "S10_top20_deadliest": top20, "S11_concentration": conc, "S12_lethality_decade_CI": by_dec, "S13_lethality_phase_CI": by_phase, "S13b_lethality_decade_hullloss": by_dec_hl,
            "S14_phase_x_decade": hm, "S15_historical_by_decade": hist_dec, "S16_military_by_decade": mil_dec,
            "S17_sensitivity_populations": sens, "S18_annual_CAT_numerators": annual_cat}
    if rates_g is not None:
        supp["S19_rates_global"] = rates_g; supp["S20_rates_by_WHO_region"] = rates_r
    write_tables(OUT / "P2_Supplementary_tables.xlsx", supp)
    print("\nPHASE 2 ------------------------------------------------------------")
    print(t1[["Category", "Events", "Fatal_events", "Fatal_events_pct", "Onboard_deaths", "Ground_deaths", "Onboard_lethality_pct"]].to_string(index=False))
    print(conc.T.to_string()); print("Figure 1 file:", f1, "| denominators found:", rates_g is not None)
    return dict(t1=t1, t2=t2, annual=annual, rates=rates_g)



# ==================================================================================
# 11. PHASE 3 — ANALYTICAL (trends with denominators, joinpoint, determinants, sensitivity)
# ==================================================================================
FUSSR = {"RUS", "UKR", "BLR", "KAZ", "UZB", "KGZ", "TJK", "TKM", "GEO", "ARM", "AZE", "MDA", "EST", "LVA", "LTU"}
REF = dict(Phase_m="Approach/landing", Prop_m="Jet", Class_m="Narrow-body (>100 seats)", Age_m="5-14",
           Nature_m="Passenger (civil)", Decade_m="1970s", Region_m="AMR")
VAR_LABEL = dict(Phase_m="Phase of flight", Prop_m="Propulsion", Class_m="Aircraft class", Age_m="Aircraft age (years)",
                 Nature_m="Nature of flight", Decade_m="Decade", Region_m="WHO region of occurrence")
COVARS = ["Phase_m", "Prop_m", "Class_m", "Age_m", "Nature_m", "Decade_m", "Region_m"]


def fmt_p(p):
    return float(p) if pd.notna(p) else np.nan


# ---------------------------------------------------------------- 11.1 trends
def annual_series(d, y0=MAIN_START, y1=MAIN_END, worst_case=False):
    k = d.copy()
    fatal = (k["Fatal_event"] == 1) | (worst_case & k["Fatal_event"].isna())
    out = pd.DataFrame({"Year": range(y0, y1 + 1)}).set_index("Year")
    out["Events"] = k.groupby("Year").size()
    out["Onboard_deaths"] = k.groupby("Year")["Total_fatalities"].sum()
    out["Total_deaths"] = out["Onboard_deaths"].add(k.groupby("Year")["Ground_fatalities"].sum(), fill_value=0)
    out["Fatal_events"] = fatal.groupby(k["Year"]).sum()
    out["Hull_losses"] = (k["Hull_loss_3"] == "Yes").groupby(k["Year"]).sum()
    return out.fillna(0).reset_index()


def world_denominators(exclude_iso=None):
    out = {}
    for key, fn in [("Passengers", "IS.AIR.PSGR.csv"), ("Departures", "IS.AIR.DPRT.csv")]:
        long, _ = _fill_world(read_worldbank(Path("denominators") / fn))
        w = long[long["ISO3"] == "WLD"].set_index("Year")["value"].sort_index()
        if exclude_iso:
            w = w.sub(long[long["ISO3"].isin(exclude_iso)].groupby("Year")["value"].sum(), fill_value=0)
        out[key] = w
    return pd.DataFrame(out).reset_index()


def fit_count_trend(y, exposure_millions, year):
    """Poisson (robust SE) and negative binomial log-linear trend with offset; returns APCs."""
    import statsmodels.api as sm
    t = np.asarray(year, float) - np.mean(year); X = sm.add_constant(t); off = np.log(np.asarray(exposure_millions, float))
    y = np.asarray(y, float); res = {}
    po = sm.GLM(y, X, family=sm.families.Poisson(), offset=off).fit(cov_type="HC1")
    res["Poisson_dispersion"] = float(po.pearson_chi2 / po.df_resid)
    res.update(_apc("Poisson_robust", po.params[1], po.bse[1], po.pvalues[1], bool(po.converged)))
    try:
        nb = None
        for method in ("bfgs", "newton", "nm"):
            cand = sm.NegativeBinomial(y, X, offset=off).fit(disp=0, method=method, maxiter=5000, start_params=np.r_[po.params, 0.1])
            if bool(cand.mle_retvals.get("converged", False)) and np.all(np.isfinite(cand.bse)):
                nb = cand; res["NB_optimizer"] = method; break
        if nb is None:
            raise RuntimeError("NB did not converge with bfgs/newton/nm")
        conv = True
        res.update(_apc("NB", nb.params[1], nb.bse[1], nb.pvalues[1], conv)); res["NB_alpha"] = float(nb.params[-1])
        res["NB_AIC"] = float(nb.aic); res["Poisson_AIC"] = float(sm.GLM(y, X, family=sm.families.Poisson(), offset=off).fit().aic)
    except Exception as e:                                             # reported, never hidden
        res.update({"NB_APC": np.nan, "NB_converged": False, "NB_error": str(e)[:80]})
    return res


def _apc(tag, b, se, p, conv):
    z = 1.959964
    return {f"{tag}_APC": 100 * (np.exp(b) - 1), f"{tag}_APC_lo": 100 * (np.exp(b - z * se) - 1),
            f"{tag}_APC_hi": 100 * (np.exp(b + z * se) - 1), f"{tag}_p": fmt_p(p), f"{tag}_converged": conv}


def joinpoint(year, rate, max_k=3, min_seg=5, n_perm=4499, alpha=0.05, seed=20250918):
    """Joinpoint (segmented log-linear) regression on ln(rate): continuous linear spline, grid search over
    integer-year joinpoints (>= min_seg years between joinpoints and from either end). The NUMBER of joinpoints is
    selected with the sequential Monte-Carlo permutation test of Kim et al. (Stat Med 2000) (n_perm permutations of
    the null-model residuals, overall alpha 0.05, Bonferroni alpha/max_k per test); BIC is reported for comparison.
    Segment APCs and the AAPC (length-weighted mean slope) carry 95% CIs conditional on joinpoint locations."""
    import itertools
    import statsmodels.api as sm
    from scipy import stats
    yr = np.asarray(year, float); ly = np.log(np.asarray(rate, float)); n = len(yr); rng = np.random.default_rng(seed)
    cand = yr[min_seg: n - min_seg]
    def design(taus):
        return np.column_stack([np.ones(n), yr - yr[0]] + [np.clip(yr - t, 0, None) for t in taus])
    combos, Qs = {}, {}
    for k in range(max_k + 1):
        cs = [t for t in itertools.combinations(cand, k) if all(b_ - a_ >= min_seg for a_, b_ in zip(t, t[1:]))]
        combos[k] = cs; Qs[k] = np.linalg.qr(np.stack([design(t) for t in cs]))[0]          # (C, n, k+2)
    def best_sse(Y, k):                                                                     # Y: (n, P)
        tot = (Y ** 2).sum(0); best = np.full(Y.shape[1], -np.inf); arg = np.zeros(Y.shape[1], int)
        for i in range(0, len(combos[k]), 1500):
            proj = np.einsum("cnk,np->ckp", Qs[k][i:i + 1500], Y); ss = (proj ** 2).sum(1)  # (c, P)
            j = ss.argmax(0); v = ss[j, np.arange(Y.shape[1])]; upd = v > best; best[upd] = v[upd]; arg[upd] = j[upd] + i
        return tot - best, arg
    obs = {k: best_sse(ly[:, None], k) for k in range(max_k + 1)}
    best = {k: dict(SSE=float(obs[k][0][0]), taus=combos[k][int(obs[k][1][0])],
                    BIC=np.log(obs[k][0][0] / n) + (2 * k + 2) * np.log(n) / n) for k in range(max_k + 1)}
    ka, kb, tests = 0, max_k, []
    while ka < kb:
        X0 = design(best[ka]["taus"]); f0 = X0 @ np.linalg.lstsq(X0, ly, rcond=None)[0]; e0 = ly - f0
        Y = f0[:, None] + np.stack([rng.permutation(e0) for _ in range(n_perm)], axis=1)
        T_obs = best[ka]["SSE"] / best[kb]["SSE"]; T_perm = best_sse(Y, ka)[0] / best_sse(Y, kb)[0]
        p = (1 + int((T_perm >= T_obs).sum())) / (n_perm + 1)
        tests.append(dict(H0_joinpoints=ka, H1_joinpoints=kb, p_permutation=p, alpha_per_test=alpha / max_k, reject_H0=p < alpha / max_k))
        if p < alpha / max_k:
            ka += 1
        else:
            kb -= 1
    ksel = ka; taus = best[ksel]["taus"]
    fit = sm.OLS(ly, design(taus)).fit(); V = fit.cov_params(); b = fit.params
    bounds = [yr[0]] + list(taus) + [yr[-1]]; tcrit = stats.t.ppf(0.975, fit.df_resid); segs = []
    for i in range(ksel + 1):
        c = np.zeros(len(b)); c[1:2 + i] = 1
        sl = float(c @ b); se = float(np.sqrt(c @ V @ c)); tval = sl / se
        segs.append(dict(Segment=i + 1, Start=int(bounds[i]), End=int(bounds[i + 1]), APC=100 * (np.exp(sl) - 1),
                         APC_lo=100 * (np.exp(sl - tcrit * se) - 1), APC_hi=100 * (np.exp(sl + tcrit * se) - 1),
                         p=fmt_p(2 * stats.t.sf(abs(tval), fit.df_resid))))
    w = np.diff(bounds) / (bounds[-1] - bounds[0]); c = np.zeros(len(b))
    for i in range(ksel + 1):
        c[1:2 + i] += w[i]
    sl = float(c @ b); se = float(np.sqrt(c @ V @ c))
    aapc = dict(AAPC=100 * (np.exp(sl) - 1), AAPC_lo=100 * (np.exp(sl - tcrit * se) - 1), AAPC_hi=100 * (np.exp(sl + tcrit * se) - 1),
                p=fmt_p(2 * stats.t.sf(abs(sl / se), fit.df_resid)))
    bic = pd.DataFrame([dict(k=k, joinpoints=", ".join(str(int(t)) for t in v["taus"]), SSE=v["SSE"], BIC=v["BIC"],
                             selected_by_permutation=(k == ksel), selected_by_BIC=(k == min(best, key=lambda q: best[q]["BIC"]))) for k, v in best.items()])
    return dict(k=ksel, taus=[int(t) for t in taus], segments=pd.DataFrame(segs), aapc=aapc, bic=bic, tests=pd.DataFrame(tests),
                fitted=np.exp(fit.fittedvalues), years=yr)


OUTCOMES = [("Onboard_deaths", "Passengers", "On-board deaths per million passengers carried"),
            ("Onboard_deaths", "Departures", "On-board deaths per million departures"),
            ("Fatal_events", "Passengers", "Fatal events per million passengers carried"),
            ("Fatal_events", "Departures", "Fatal events per million departures"),
            ("Hull_losses", "Departures", "Hull-loss events per million departures")]


def trend_block(d, label, den, worst_case=False, with_joinpoint=True, last_year=None):
    a = annual_series(d, worst_case=worst_case).merge(den, on="Year", how="left")
    a = a[a["Passengers"].notna() & a["Departures"].notna()]
    if last_year:
        a = a[a["Year"] <= last_year]
    rows, jrows, jp_store = [], [], {}
    for num, dn, name in OUTCOMES:
        r = fit_count_trend(a[num], a[dn] / 1e6, a["Year"])
        row = dict(Population=label, Outcome=name, Years=f"{int(a.Year.min())}-{int(a.Year.max())}", n_years=len(a),
                   Numerator_total=int(a[num].sum()), Rate_first=a[num].iloc[0] / a[dn].iloc[0] * 1e6,
                   Rate_last=a[num].iloc[-1] / a[dn].iloc[-1] * 1e6, **r)
        if with_joinpoint:
            rate = a[num] / a[dn] * 1e6
            if (rate > 0).all():
                jp = joinpoint(a["Year"], rate); jp_store[name] = dict(jp=jp, rate=rate.values)
                row.update(Joinpoints=", ".join(map(str, jp["taus"])) or "none", **{f"JP_{k}": v for k, v in jp["aapc"].items()})
                for _, sgm in jp["segments"].iterrows():
                    jrows.append(dict(Population=label, Outcome=name, **sgm.to_dict()))
            else:
                row.update(Joinpoints="not estimable (zero counts)")
        rows.append(row)
    return pd.DataFrame(rows), pd.DataFrame(jrows), jp_store, a


def regional_trends(main):
    import statsmodels.api as sm
    _, reg = build_denominators()
    rows = []
    for region in ["AFR", "AMR", "EMR", "EUR", "SEAR", "WPR"]:
        d = main[main["WHO_region"] == region]; a = annual_series(d).merge(reg[reg["WHO_region"] == region], on="Year", how="left")
        for y0 in (1970, 1992):
            b = a[(a["Year"] >= y0) & a["Passengers"].gt(0) & a["Departures"].gt(0)]
            for num, dn, name in [OUTCOMES[0], OUTCOMES[3]]:
                r = fit_count_trend(b[num], b[dn] / 1e6, b["Year"])
                rows.append(dict(WHO_region=region, Outcome=name, Years=f"{int(b.Year.min())}-{int(b.Year.max())}",
                                 Numerator_total=int(b[num].sum()), **r))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- 11.2 determinants
def model_frame(d, regional_max=None, decades_from=1970):
    m = d[d["Fatalities_known"]].copy()
    m["y"] = (m["Total_fatalities"] > 0).astype(int)
    m["Phase_m"] = m["Phase_group"]
    m["Prop_m"] = np.where(m["Propulsion"].isin(["Jet", "Turboprop", "Piston"]), m["Propulsion"], "Other/unknown")
    cls = pd.Series([aircraft_class(r, s_, w, regional_max) for r, s_, w in zip(m["Role"], m["Seats_typical"], m["Wide_body"])], index=m.index)
    m["Class_m"] = cls.replace({"Unknown": "Other"})
    m["Age_m"] = m["Age_cat"]
    m["Nature_m"] = m["Nature_group"].replace({"Other civil (ferry, training, test, survey…)": "Other civil"})
    m["Decade_m"] = m["Decade"].astype(int).astype(str) + "s"
    m["Region_m"] = m["WHO_region"].replace({"At sea": "At sea/Antarctica", "Antarctica": "At sea/Antarctica"})
    return m


def _formula(y="y", covars=COVARS, extra=""):
    return f"{y} ~ " + " + ".join(f"C({v}, Treatment(reference='{REF[v]}'))" for v in covars) + extra


def tidy(res, scale="OR", pop="", model=""):
    import re as _re
    rows = []
    for name in res.params.index:
        mt = _re.match(r"C\((\w+), Treatment\(reference='(.*?)'\)\)\[T\.(.*)\]", name)
        if not mt:
            continue
        v, ref, lv = mt.groups(); b = res.params[name]; se = res.bse[name]
        rows.append(dict(Population=pop, Model=model, Variable=VAR_LABEL.get(v, v), Level=lv, Reference=ref,
                         Estimate=np.exp(b), CI_lo=np.exp(b - 1.959964 * se), CI_hi=np.exp(b + 1.959964 * se),
                         p=fmt_p(res.pvalues[name]), Scale=scale,
                         Flag="quasi-complete separation: not estimable" if abs(b) > 10 else ""))
    return pd.DataFrame(rows)


def fit_glm(formula, data, family, groups, var_weights=None):
    import statsmodels.api as sm
    from patsy import dmatrices
    y, X = dmatrices(formula, data, return_type="dataframe")
    kw = dict(var_weights=np.asarray(var_weights, float)) if var_weights is not None else {}
    mod = sm.GLM(y, X, family=family, **kw)
    res = mod.fit(maxiter=200, cov_type="cluster", cov_kwds=dict(groups=np.asarray(groups)))
    return X.design_info, res


def level_counts(m, covars=COVARS):
    rows = []
    for v in covars:
        g = m.groupby(v)["y"].agg(["size", "sum"])
        for lv, r in g.iterrows():
            rows.append(dict(Variable=VAR_LABEL[v], Level=lv, n=int(r["size"]), Fatal=int(r["sum"]), Fatal_pct=round(100 * r["sum"] / r["size"], 1)))
    return pd.DataFrame(rows)


def wald_joint(res, var):
    idx = [i for i, n in enumerate(res.params.index) if n.startswith(f"C({var},")]
    R = np.zeros((len(idx), len(res.params))); R[range(len(idx)), idx] = 1
    w = res.wald_test(R, scalar=True)
    return dict(Variable=VAR_LABEL[var], chi2=float(w.statistic), df=len(idx), p=fmt_p(w.pvalue))


def phase_comparison(mod, res, m, pop):
    """Adjusted marginal probability (marginal standardisation, delta method) and pairwise ORs for the three
    flight phases of interest."""
    from patsy import build_design_matrices
    from scipy.special import expit
    from scipy import stats
    di = mod; b = res.params.values; V = res.cov_params().values
    ph = ["Take-off/initial climb", "En route (cruise)", "Approach/landing"]; rows = []
    for p_ in ph:
        mm = m.copy(); mm["Phase_m"] = p_
        X = np.asarray(build_design_matrices([di], mm)[0]); pr = expit(X @ b)
        g = (pr * (1 - pr))[:, None] * X; g = g.mean(0); se = float(np.sqrt(g @ V @ g)); est = float(pr.mean())
        sub = m[m["Phase_m"] == p_]
        rows.append(dict(Population=pop, Phase=p_, n=len(sub), Fatal_events=int(sub["y"].sum()), Crude_fatal_pct=100 * sub["y"].mean(),
                         Adjusted_fatal_pct=100 * est, Adj_lo=100 * (est - 1.959964 * se), Adj_hi=100 * (est + 1.959964 * se)))
    names = list(res.params.index)
    def coef(p_):
        c = np.zeros(len(b))
        if p_ != REF["Phase_m"]:
            c[names.index(f"C(Phase_m, Treatment(reference='{REF['Phase_m']}'))[T.{p_}]")] = 1
        return c
    cons = []
    for a_, b_ in [(ph[0], ph[2]), (ph[1], ph[2]), (ph[0], ph[1])]:
        c = coef(a_) - coef(b_); est = float(c @ b); se = float(np.sqrt(c @ V @ c)); z = est / se
        cons.append(dict(Population=pop, Contrast=f"{a_} vs {b_}", aOR=np.exp(est), CI_lo=np.exp(est - 1.959964 * se),
                         CI_hi=np.exp(est + 1.959964 * se), p=fmt_p(2 * stats.norm.sf(abs(z)))))
    return pd.DataFrame(rows), pd.DataFrame(cons)


# ---------------------------------------------------------------- 11.3 multiple imputation of aircraft age
def impute_age(m, M=20, k=5, seed=20250918):
    """Multiple imputation of aircraft age by predictive mean matching (type-1 matching, k=5 donors,
    bootstrap draw of the imputation-model parameters). Age is the only incomplete covariate (all others carry an
    explicit 'Unknown' level), so the chained-equations cycle reduces to one conditional model. Predictors:
    aircraft family (type), decade, event year, WHO region, operator (leave-one-out mean fleet age + indicator),
    nature, phase, class, propulsion, hull loss and the outcome (fatal event)."""
    from patsy import dmatrix
    rng = np.random.default_rng(seed); z = m.copy()
    fam_n = z["Aircraft_family"].map(z["Aircraft_family"].value_counts())
    z["fam_i"] = np.where(fam_n >= 30, z["Aircraft_family"], "Other (" + z["Manufacturer_group"].astype(str) + ")")
    fam_n2 = z["fam_i"].map(z["fam_i"].value_counts()); z.loc[fam_n2 < 30, "fam_i"] = "Other"
    obs = z["Age_years"].notna()
    op = z["Operator"].fillna("unknown"); s_ = z.loc[obs].groupby(op[obs])["Age_years"].agg(["sum", "count"])
    osum = op.map(s_["sum"]).fillna(0); ocnt = op.map(s_["count"]).fillna(0)
    own = z["Age_years"].fillna(0) * obs
    loo = (osum - own) / (ocnt - obs.astype(int)).replace(0, np.nan)
    z["op_missing"] = loo.isna().astype(int); z["op_age"] = loo.fillna(z.loc[obs, "Age_years"].mean())
    Z = np.asarray(dmatrix("C(fam_i) + C(Decade_m) + C(Region_m) + C(Nature_m) + C(Phase_m) + C(Class_m) + C(Prop_m) + "
                           "C(Hull_loss_3) + y + op_age + op_missing + I(Year - 1997)", z, return_type="dataframe"))
    yo = z.loc[obs, "Age_years"].values; Zo = Z[obs.values]; Zm = Z[~obs.values]
    bhat, *_ = np.linalg.lstsq(Zo, yo, rcond=None); pred_o = Zo @ bhat
    order = np.argsort(pred_o); ps = pred_o[order]; ys = yo[order]
    r2 = 1 - ((yo - pred_o) ** 2).sum() / ((yo - yo.mean()) ** 2).sum()
    imps = []
    for _ in range(M):
        bi = rng.integers(0, len(yo), len(yo)); bstar, *_ = np.linalg.lstsq(Zo[bi], yo[bi], rcond=None)
        pm = Zm @ bstar; pos = np.searchsorted(ps, pm)
        lo = np.clip(pos - k, 0, len(ps) - 1); hi = np.clip(pos + k, 1, len(ps))
        draw = np.empty(len(pm))
        for j in range(len(pm)):
            c = np.arange(lo[j], hi[j]); nn = c[np.argsort(np.abs(ps[c] - pm[j]))[:k]]; draw[j] = ys[rng.choice(nn)]
        a = z["Age_years"].copy(); a.loc[~obs] = draw; imps.append(a)
    return imps, dict(n_observed=int(obs.sum()), n_imputed=int((~obs).sum()), imputation_model_R2=round(float(r2), 3), M=M, donors=k)


def rubin(results):
    from scipy import stats
    Q = np.array([r.params.values for r in results]); U = np.array([np.diag(r.cov_params().values) for r in results]); M = len(results)
    qb = Q.mean(0); ub = U.mean(0); B = Q.var(0, ddof=1); T = ub + (1 + 1 / M) * B
    with np.errstate(divide="ignore", invalid="ignore"):
        nu = (M - 1) * (1 + ub / ((1 + 1 / M) * B)) ** 2
    nu = np.where(np.isfinite(nu), nu, 1e6); se = np.sqrt(T); tc = stats.t.ppf(0.975, nu)
    out = pd.DataFrame(dict(b=qb, se=se, lo=qb - tc * se, hi=qb + tc * se, p=2 * stats.t.sf(np.abs(qb / se), nu),
                            FMI=((1 + 1 / M) * B) / T), index=results[0].params.index)
    return out


def tidy_rubin(tab, pop, model):
    import re as _re
    rows = []
    for name, r in tab.iterrows():
        mt = _re.match(r"C\((\w+), Treatment\(reference='(.*?)'\)\)\[T\.(.*)\]", name)
        if mt:
            v, ref, lv = mt.groups()
            rows.append(dict(Population=pop, Model=model, Variable=VAR_LABEL.get(v, v), Level=lv, Reference=ref, Estimate=np.exp(r.b),
                             CI_lo=np.exp(r.lo), CI_hi=np.exp(r.hi), p=fmt_p(r.p), Scale="OR", FMI=round(float(r.FMI), 3)))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- 11.4 restricted cubic splines for age
def rcs_basis(x, knots):
    x = np.asarray(x, float); k = np.asarray(knots, float); K = len(k); cols = [x]
    norm = (k[-1] - k[0]) ** 2
    for j in range(K - 2):
        t = (np.clip(x - k[j], 0, None) ** 3 - np.clip(x - k[K - 2], 0, None) ** 3 * (k[-1] - k[j]) / (k[-1] - k[K - 2])
             + np.clip(x - k[-1], 0, None) ** 3 * (k[K - 2] - k[j]) / (k[-1] - k[K - 2])) / norm
        cols.append(t)
    return np.column_stack(cols)


def age_spline(m, pop, adjust, ref_age=10):
    import statsmodels.api as sm
    from patsy import dmatrix
    from scipy import stats
    d = m[m["Age_years"].notna()].copy(); knots = np.percentile(d["Age_years"], [5, 35, 65, 95])
    Bx = rcs_basis(d["Age_years"], knots); A = np.asarray(dmatrix(" + ".join(f"C({v}, Treatment(reference='{REF[v]}'))" for v in adjust), d))
    X = np.column_stack([A, Bx]); nb_ = Bx.shape[1]
    res = sm.GLM(d["y"].values, X, family=sm.families.Binomial()).fit(maxiter=200, cov_type="cluster", cov_kwds=dict(groups=d["Occurrence_ID"].values))
    b = res.params[-nb_:]; V = res.cov_params()[-nb_:, -nb_:]
    grid = np.arange(0, 51); C = rcs_basis(grid, knots) - rcs_basis([ref_age], knots)
    est = C @ b; se = np.sqrt(np.einsum("ij,jk,ik->i", C, V, C))
    curve = pd.DataFrame(dict(Population=pop, Adjustment=" + ".join(VAR_LABEL[v] for v in adjust), Age=grid, OR=np.exp(est),
                              CI_lo=np.exp(est - 1.959964 * se), CI_hi=np.exp(est + 1.959964 * se)))
    w_all = float(b @ np.linalg.solve(V, b)); w_nl = float(b[1:] @ np.linalg.solve(V[1:, 1:], b[1:]))
    tests = dict(Population=pop, Adjustment=curve["Adjustment"].iloc[0], n=len(d), knots=", ".join(f"{k_:.0f}" for k_ in knots),
                 Wald_overall_chi2=w_all, df_overall=nb_, p_overall=fmt_p(stats.chi2.sf(w_all, nb_)),
                 Wald_nonlinear_chi2=w_nl, df_nonlinear=nb_ - 1, p_nonlinear=fmt_p(stats.chi2.sf(w_nl, nb_ - 1)), converged=bool(res.converged))
    return curve, tests, d["Age_years"].values


# ---------------------------------------------------------------- 11.5 figures
def fig1_final(a):
    plt = _mpl()
    a = a.copy()
    for stem, dn, lab in [("P2_Fig1_annual_deaths_rate_passengers", "Passengers", "per million passengers carried"),
                          ("P2_Fig1b_annual_deaths_rate_departures", "Departures", "per million departures")]:
        fig, ax = plt.subplots(figsize=(7.2, 3.6))
        ax.bar(a["Year"], a["Onboard_deaths"], width=0.8, color=PAL["light"], edgecolor=PAL["grey"], lw=0.3, label="On-board deaths (left axis)")
        ax.set_ylabel("On-board deaths per year, commercial air transport"); ax.set_xlabel("Year"); ax.set_xlim(MAIN_START - 1, MAIN_END + 1)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{int(v):,}"))
        ax2 = ax.twinx(); ax2.spines["right"].set_visible(True); ax2.spines["right"].set_linewidth(0.6)
        r = a[a[dn].notna()]
        ax2.plot(r["Year"], r["Onboard_deaths"] / r[dn] * 1e6, color=PAL["red"], lw=1.1, marker="o", ms=2.2, label=f"On-board deaths {lab} (right axis)")
        if dn == "Departures":
            ax2.plot(r["Year"], r["Fatal_events"] / r[dn] * 1e6, color=PAL["blue"], lw=1.1, marker="s", ms=2.0, label=f"Fatal events {lab} (right axis)")
        ax2.set_yscale("log"); ax2.set_ylabel(f"Rate {lab} (log scale)")
        ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}"))
        nod = a[a[dn].isna()]["Year"]
        if len(nod):
            ax.axvspan(nod.min() - 0.5, nod.max() + 0.5, color="#f2f2f2", zorder=0, lw=0)
            ax.text(nod.mean(), ax.get_ylim()[1] * 0.97, "no\ndenom.", ha="center", va="top", fontsize=5.5, color=PAL["grey"])
        h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, loc="upper right", bbox_to_anchor=(0.94, 1.0))
        _save(fig, stem)


def fig5_joinpoint(jp_store):
    plt = _mpl()
    names = [n for n in jp_store]; fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.6), gridspec_kw=dict(hspace=0.38, wspace=0.28))
    for ax, name, lab in zip(axes.ravel(), [OUTCOMES[0][2], OUTCOMES[1][2], OUTCOMES[3][2], OUTCOMES[4][2]], "ABCD"):
        jp = jp_store[name]["jp"]; yr = jp["years"]
        ax.plot(yr, jp_store[name]["rate"], "o", ms=2.6, color=PAL["grey"], mfc="white", mew=0.7)
        ax.plot(yr, jp["fitted"], color=PAL["red"], lw=1.2)
        for t in jp["taus"]:
            ax.axvline(t, color=PAL["ink"], lw=0.5, ls=":")
        ax.set_yscale("log"); ax.set_title(name, fontsize=7.8, loc="left"); ax.set_xlabel("Year")
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}"))
        txt = "\n".join(f"{int(s.Start)}–{int(s.End)}: APC {s.APC:+.1f}% ({s.APC_lo:+.1f} to {s.APC_hi:+.1f})" for s in jp["segments"].itertuples())
        ax.text(0.97, 0.96, txt, transform=ax.transAxes, fontsize=6.3, va="top", ha="right")
        ax.text(-0.16, 1.06, lab, transform=ax.transAxes, fontsize=11, weight="bold")
    _save(fig, "P3_Fig5_joinpoint_trends")


def fig6_forest(tab_all, tab_hl):
    plt = _mpl()
    t = tab_all.merge(tab_hl, on=["Variable", "Level", "Reference"], suffixes=("_all", "_hl"))
    t = t[~t["Variable"].isin(["Decade", "WHO region of occurrence"]) | True]
    rows = []; y = 0; yt = []; yl = []
    fig, ax = plt.subplots(figsize=(7.0, 0.19 * (len(t) + t["Variable"].nunique() * 1.4) + 0.8))
    for var, g in t.groupby("Variable", sort=False):
        ax.text(0.012, y, f"{var} (ref: {g['Reference'].iloc[0]})", fontsize=7.2, weight="bold", va="center", transform=ax.get_yaxis_transform()); y += 1
        for r in g.itertuples():
            for off, sfx, col, mk in [(-0.16, "_all", PAL["blue"], "o"), (0.16, "_hl", PAL["red"], "s")]:
                e, lo, hi = getattr(r, "Estimate" + sfx), getattr(r, "CI_lo" + sfx), getattr(r, "CI_hi" + sfx)
                ax.plot([max(lo, 0.02), min(hi, 60)], [y + off] * 2, color=col, lw=0.8); ax.plot(e, y + off, mk, ms=3.2, color=col)
            yt.append(y); yl.append(r.Level); y += 1
        y += 0.4
    ax.axvline(1, color=PAL["ink"], lw=0.6); ax.set_xscale("log"); ax.set_xlim(0.02, 60); ax.set_ylim(y, -1)
    ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=6.6); ax.tick_params(axis="y", length=0)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}")); ax.set_xticks([0.05, 0.1, 0.25, 0.5, 1, 2, 4, 10, 25])
    ax.set_xlabel("Adjusted odds ratio for a fatal event (95% CI, log scale)")
    from matplotlib.lines import Line2D
    ax.legend(handles=[Line2D([], [], color=PAL["blue"], marker="o", ms=3.5, lw=0.8, label="All events"),
                       Line2D([], [], color=PAL["red"], marker="s", ms=3.5, lw=0.8, label="Hull-loss events only")], loc="lower right")
    _save(fig, "P3_Fig6_forest_fatal_event")


def fig7_age(curves, ages):
    plt = _mpl()
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.1), sharey=True, gridspec_kw=dict(wspace=0.06))
    for ax, (pop, c), lab in zip(axes, curves.items(), "AB"):
        ax.fill_between(c["Age"], c["CI_lo"], c["CI_hi"], color=PAL["blue"], alpha=0.18, lw=0)
        ax.plot(c["Age"], c["OR"], color=PAL["blue"], lw=1.2); ax.axhline(1, color=PAL["ink"], lw=0.5, ls=":")
        ax.set_yscale("log"); ax.set_xlabel("Aircraft age at event (years)"); ax.set_title(pop, fontsize=8, loc="left")
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}")); ax.set_yticks([0.5, 0.75, 1, 1.5, 2, 3])
        from matplotlib.ticker import NullFormatter
        ax.yaxis.set_minor_formatter(NullFormatter()); ax.set_ylim(0.5, 3)
        h, e = np.histogram(ages[pop], bins=np.arange(0, 52, 2)); ax2 = ax.twinx(); ax2.bar(e[:-1] + 1, h, width=1.8, color=PAL["light"], zorder=0)
        ax2.set_ylim(0, h.max() * 5); ax2.axis("off"); ax.set_zorder(ax2.get_zorder() + 1); ax.patch.set_visible(False)
        ax.text(-0.02 if lab == "B" else -0.13, 1.12, lab, transform=ax.transAxes, fontsize=11, weight="bold"); ax.set_xlim(0, 50)
    axes[0].set_ylabel("Adjusted OR for a fatal event\n(reference: 10 years; 95% CI)")
    _save(fig, "P3_Fig7_age_spline")


# ---------------------------------------------------------------- 11.6 driver
def phase3(df, hist, main, mil):
    import statsmodels.api as sm
    import warnings
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    occ = occurrence_ids(df); df = df.assign(Occurrence_ID=occ)
    main = main.assign(Occurrence_ID=main["ID"].map(dict(zip(df["ID"], occ)))); mil = mil.assign(Occurrence_ID=mil["ID"].map(dict(zip(df["ID"], occ))))
    hist = hist.assign(Occurrence_ID=hist["ID"].map(dict(zip(df["ID"], occ))))
    den = world_denominators(); notes = []

    # ===== A. TRENDS (primary outcome): commercial air transport (CAT) numerators =====
    cat = main[main["CAT"] == 1]
    t_main, jp_main, jp_store, a_main = trend_block(cat, "Commercial air transport (CAT), 1970-2023", den)
    fig5_joinpoint(jp_store)
    t_pre, jp_pre, jp_store_pre, _ = trend_block(cat, "CAT, pre-pandemic window 1970-2019", den, last_year=2019)
    den_x = world_denominators(exclude_iso=FUSSR)
    cat_wide = main[(main["Nature_group"].isin(["Passenger (civil)", "Cargo"]))]
    scen = [("CAT excluding intentional acts (ASN category C)", cat[cat["Intentional_act"] == 0], den, False),
            ("CAT, unknown fatalities counted as fatal events (worst case)", cat, den, True),
            ("CAT excluding former-USSR territory (numerator and denominator, all years)", cat[~cat["ISO3"].isin(FUSSR)], den_x, False),
            ("CAT plus records with nature 'Passenger' not further specified", cat_wide, den, False),
            ("CAT, scheduled passenger flights only", cat[cat["Nature"] == "Passenger - Scheduled"], den, False),
            ("CAT, jet aircraft only", cat[cat["Propulsion"] == "Jet"], den, False)]
    t_sens = pd.concat([trend_block(d_, lab, dn, wc, with_joinpoint=False)[0] for lab, d_, dn, wc in scen], ignore_index=True)
    # secondary: ALL civil aviation -> trend in annual COUNTS only (no rates: denominators do not cover non-commercial flying)
    ac = annual_series(main); rows_c = []
    for num in ["Onboard_deaths", "Fatal_events", "Hull_losses"]:
        r_ = fit_count_trend(ac[num], np.ones(len(ac)), ac["Year"])
        rows_c.append(dict(Population="All civil aviation 1970-2025 (annual COUNTS, no denominator)", Outcome=num, Numerator_total=int(ac[num].sum()), **r_))
    t_counts = pd.DataFrame(rows_c)
    bic = pd.concat([v["jp"]["bic"].assign(Outcome=k, Window="1970-2023") for k, v in jp_store.items()] +
                    [v["jp"]["bic"].assign(Outcome=k, Window="1970-2019") for k, v in jp_store_pre.items()], ignore_index=True)
    perm = pd.concat([v["jp"]["tests"].assign(Outcome=k, Window="1970-2023") for k, v in jp_store.items()] +
                     [v["jp"]["tests"].assign(Outcome=k, Window="1970-2019") for k, v in jp_store_pre.items()], ignore_index=True)
    t_reg = regional_trends(cat)
    # historical series without denominators, civil 1945-2025
    h = hist[(hist["Military"] == 0) & (hist["Year"] >= 1945)]; ah = annual_series(h, 1945, HIST_END); rows = []
    for num in ["Onboard_deaths", "Fatal_events", "Hull_losses"]:
        r = fit_count_trend(ah[num], np.ones(len(ah)), ah["Year"])
        rows.append(dict(Population="Civil operations 1945-2025 (no denominator: trend in annual COUNTS)", Outcome=num, Numerator_total=int(ah[num].sum()), **r))
    t_hist = pd.DataFrame(rows)
    # denominator coverage (first year with data) for countries with >=100 events
    lp = read_worldbank(Path("denominators") / "IS.AIR.PSGR.csv"); first = lp.groupby("ISO3")["Year"].min()
    cov = (main[main["ISO3"].notna()].groupby(["Country", "ISO3"]).size().reset_index(name="Events").query("Events >= 100")
           .assign(First_year_with_passenger_data=lambda x: x["ISO3"].map(first)).sort_values("Events", ascending=False))

    # ===== B. DETERMINANTS =====
    m_all = model_frame(main); m_hl = m_all[m_all["Hull_loss_3"] == "Yes"].copy()
    pops = {"All events": m_all, "Hull-loss events only": m_hl}
    fam = sm.families; T = {}; joint = []; conv = []; ph_marg = []; ph_con = []; counts = []
    for pop, m in pops.items():
        f = _formula(); mod, res = fit_glm(f, m, fam.Binomial(), m["Occurrence_ID"])
        T[(pop, "logit")] = tidy(res, "OR", pop, "Logistic: fatal event (aOR)")
        conv.append(dict(Population=pop, Model="Logistic fatal event", n=int(res.nobs), events=int(m["y"].sum()), converged=bool(res.converged),
                         AIC=float(res.aic), max_abs_coef=float(np.abs(res.params).max())))
        joint += [dict(Population=pop, Model="Logistic", **wald_joint(res, v)) for v in COVARS]
        a_, b_ = phase_comparison(mod, res, m, pop); ph_marg.append(a_); ph_con.append(b_)
        counts.append(level_counts(m).assign(Population=pop))
        modp, resp = fit_glm(f, m, fam.Poisson(), m["Occurrence_ID"])
        T[(pop, "rr")] = tidy(resp, "RR", pop, "Modified Poisson: fatal event (aRR)")
        conv.append(dict(Population=pop, Model="Modified Poisson fatal event", n=int(resp.nobs), events=int(m["y"].sum()), converged=bool(resp.converged), AIC=np.nan, max_abs_coef=float(np.abs(resp.params).max())))
        # proportion of occupants killed
        L = m[m["Onboard_lethality"].notna()].copy(); L["prop"] = L["Onboard_lethality"]
        for tag, dd, vw, name in [("frac", L, None, "Fractional logit: proportion of occupants killed, event-weighted (aOR)"),
                                  ("binom", L, L["Total_on_board"].values, "Binomial logit: occupants killed/occupants, occupant-weighted (aOR)"),
                                  ("cond", L[L["y"] == 1], None, "Fractional logit among FATAL events: conditional lethality (aOR)")]:
            try:
                vw_ = None if vw is None else dd["Total_on_board"].values
                _, rr = fit_glm(_formula("prop"), dd, fam.Binomial(), dd["Occurrence_ID"], vw_)
                T[(pop, tag)] = tidy(rr, "OR", pop, name)
                conv.append(dict(Population=pop, Model=name, n=int(rr.nobs), events=np.nan, converged=bool(rr.converged), AIC=np.nan, max_abs_coef=float(np.abs(rr.params).max())))
            except Exception as e:
                conv.append(dict(Population=pop, Model=name, n=len(dd), events=np.nan, converged=False, AIC=np.nan, max_abs_coef=np.nan, error=str(e)[:100]))
    # crude conditional lethality by phase
    cl = []
    for pop, m in pops.items():
        L = m[m["Onboard_lethality"].notna() & (m["y"] == 1)]
        for p_ in ["Take-off/initial climb", "En route (cruise)", "Approach/landing"]:
            g = L[L["Phase_m"] == p_]; lo, hi = boot_ratio(g["Total_fatalities"], g["Total_on_board"])
            cl.append(dict(Population=pop, Phase=p_, Fatal_events_with_occupants=len(g), Conditional_lethality_pct=100 * g["Total_fatalities"].sum() / g["Total_on_board"].sum(),
                           CI_lo=lo, CI_hi=hi, Mean_event_lethality_pct=100 * g["Onboard_lethality"].mean()))
    cond_leth = pd.DataFrame(cl)

    # ===== C. AIRCRAFT AGE: three approaches + splines =====
    age_tabs = []; mi_info = []
    for pop, m in pops.items():
        age_tabs.append(T[(pop, "logit")].query("Variable == 'Aircraft age (years)'").assign(Approach="(b) 'Unknown' as explicit level"))
        cc = m[m["Age_m"] != "Unknown"]; _, rc = fit_glm(_formula(), cc, fam.Binomial(), cc["Occurrence_ID"])
        age_tabs.append(tidy(rc, "OR", pop, "Logistic").query("Variable == 'Aircraft age (years)'").assign(Approach=f"(a) Complete cases (n = {len(cc):,})"))
        imps, info = impute_age(m); mi_info.append(dict(Population=pop, **info)); fits = []
        for a in imps:
            mi = m.copy(); mi["Age_m"] = pd.cut(a, AGE_BINS, labels=AGE_LABELS).astype(str)
            fits.append(fit_glm(_formula(), mi, fam.Binomial(), mi["Occurrence_ID"])[1])
        rb = tidy_rubin(rubin(fits), pop, "Logistic (MI, m = 20, Rubin's rules)")
        T[(pop, "mi")] = rb
        age_tabs.append(rb.query("Variable == 'Aircraft age (years)'").assign(Approach="(c) Multiple imputation (PMM, m = 20)"))
    age_tab = pd.concat(age_tabs, ignore_index=True)
    curves, tests, ages, all_curves = {}, [], {}, []
    for pop, m in pops.items():
        c1, t1_, ag = age_spline(m, pop, ["Decade_m", "Class_m"]); curves[pop] = c1; ages[pop] = ag; tests.append(t1_); all_curves.append(c1)
        c2, t2_, _ = age_spline(m, pop, [v for v in COVARS if v != "Age_m"]); tests.append(t2_); all_curves.append(c2)
    fig7_age(curves, ages)
    spl = pd.concat(all_curves); spl = spl[spl["Age"].isin([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50])]

    # ===== D. SENSITIVITY OF THE DETERMINANTS MODEL =====
    def key_or(d_, label, regional_max=None, decades=False):
        mm = model_frame(d_, regional_max); out = []
        for pop, mx in [("All events", mm), ("Hull-loss events only", mm[mm["Hull_loss_3"] == "Yes"])]:
            try:
                _, r_ = fit_glm(_formula(), mx, fam.Binomial(), mx["Occurrence_ID"]); tt = tidy(r_, "OR", pop, "Logistic")
                keep = tt[(tt["Variable"].isin(["Phase of flight"]) & tt["Level"].isin(["Take-off/initial climb", "En route (cruise)"])) |
                          (tt["Variable"].eq("Aircraft age (years)") & tt["Level"].eq(">=25")) |
                          (tt["Variable"].eq("Propulsion") & tt["Level"].isin(["Turboprop", "Piston"])) |
                          (tt["Variable"].eq("Aircraft class")) | (tt["Variable"].eq("Decade") & tt["Level"].isin(["2010s", "2020s"]))]
                out.append(keep.assign(Scenario=label, n=int(r_.nobs), converged=bool(r_.converged)))
            except Exception as e:
                out.append(pd.DataFrame([dict(Scenario=label, Population=pop, Variable="MODEL FAILED", Level=str(e)[:80])]))
        return pd.concat(out)
    wc = main.copy(); wc.loc[wc["Total_fatalities"].isna(), ["Total_fatalities"]] = 1; wc["Fatalities_known"] = True
    s_list = [("Main model", main, None), ("Including military operations", pd.concat([main, mil]), None),
              ("Excluding intentional acts (ASN category C)", main[main["Intentional_act"] == 0], None),
              ("Excluding nature unknown", main[main["Nature_unknown"] == 0], None),
              ("Excluding civil records with military operator", main[main["Military_operator_flag"] == 0], None),
              ("Unknown fatalities counted as fatal (worst case)", wc, None),
              ("Commercial air transport (CAT) only", cat, None),
              ("Seat cut-off regional/narrow-body = 90", main, 90), ("Seat cut-off regional/narrow-body = 110", main, 110)]
    sens_or = pd.concat([key_or(d_, lab, rm) for lab, d_, rm in s_list], ignore_index=True)
    # historical determinants 1945-2025 (civil), decade reference 1970s
    hm_ = model_frame(h); hm_ = hm_[hm_["Decade"] >= 1940]
    rows = []
    for pop, mx in [("All events", hm_), ("Hull-loss events only", hm_[hm_["Hull_loss_3"] == "Yes"])]:
        _, r_ = fit_glm(_formula(), mx, fam.Binomial(), mx["Occurrence_ID"]); rows.append(tidy(r_, "OR", pop, "Logistic, civil 1945-2025").assign(n=int(r_.nobs), converged=bool(r_.converged)))
    hist_or = pd.concat(rows, ignore_index=True)
    seat_desc = []
    for cut in (90, 100, 110):
        mm = model_frame(main, cut)
        for lv, g in mm.groupby("Class_m"):
            if lv.startswith(("Regional", "Narrow")):
                seat_desc.append(dict(Seat_cut=cut, Class=lv.split(" (")[0], **{k: v for k, v in summarise(g).items() if k in ("Events", "Fatal_events", "Fatal_events_pct", "Onboard_deaths", "Onboard_lethality_pct")}))
    seat_desc = pd.DataFrame(seat_desc)

    fig6_forest(T[("All events", "logit")], T[("Hull-loss events only", "logit")])

    # ===== WRITE =====
    keepc = ["Population", "Outcome", "Years", "Numerator_total", "Rate_first", "Rate_last", "NB_APC", "NB_APC_lo", "NB_APC_hi", "NB_p", "NB_alpha", "NB_converged",
             "Poisson_robust_APC", "Poisson_robust_APC_lo", "Poisson_robust_APC_hi", "Poisson_robust_p", "Poisson_dispersion", "NB_AIC", "Poisson_AIC",
             "Joinpoints", "JP_AAPC", "JP_AAPC_lo", "JP_AAPC_hi", "JP_p"]
    t3 = t_main[[c for c in keepc if c in t_main]]
    wide = T[("All events", "logit")].merge(T[("Hull-loss events only", "logit")], on=["Variable", "Level", "Reference"], suffixes=("_all", "_hullloss"))
    wide = wide.merge(T[("All events", "rr")][["Variable", "Level", "Estimate", "CI_lo", "CI_hi", "p"]].rename(columns=lambda c: c if c in ("Variable", "Level") else f"aRR_{c}_all"), on=["Variable", "Level"])
    wide = wide.merge(T[("Hull-loss events only", "rr")][["Variable", "Level", "Estimate", "CI_lo", "CI_hi", "p"]].rename(columns=lambda c: c if c in ("Variable", "Level") else f"aRR_{c}_hullloss"), on=["Variable", "Level"])
    t4 = wide.drop(columns=[c for c in wide if c.startswith(("Population", "Model", "Scale"))]).rename(columns=lambda c: c.replace("Estimate_", "aOR_").replace("CI_lo_", "aOR_lo_").replace("CI_hi_", "aOR_hi_").replace("p_", "aOR_p_") if not c.startswith("aRR") else c)
    t5 = pd.concat(ph_marg).merge(cond_leth, on=["Population", "Phase"])
    readme = [("Table3", "Table 3. Temporal trends in mortality and fatal-event rates in COMMERCIAL AIR TRANSPORT (scheduled and non-scheduled passenger, cargo), 1970-2023: annual percent change (negative binomial with log offset; Poisson with robust SE) and joinpoint analysis. PRIMARY OUTCOME."),
              ("Table4", "Table 4. Determinants of a fatal event: adjusted OR (logistic) and adjusted RR (modified Poisson), all events and hull-loss events only (co-primary). Cluster-robust SE by occurrence."),
              ("Table5", "Table 5. Take-off/initial climb vs en route vs approach/landing: crude and adjusted probability of a fatal event and conditional on-board lethality."),
              ("Notes", "Denominators: World Bank WDI IS.AIR.PSGR and IS.AIR.DPRT (ICAO), world aggregate, available 1970-2023; 2024-2025 not modelled. The world aggregate excludes the USSR before 1991 (Russian Federation series starts 1991) -> see sensitivity 'Excluding former-USSR territory'. p values are exact (unrounded).")]
    write_tables(OUT / "P3_Tables_3_4_5.xlsx", {"Table3": t3, "Table3_segments": jp_main, "Table4": t4, "Table5": t5, "Table5_contrasts": pd.concat(ph_con)}, readme)
    supp = {"S21_trend_sensitivity": t_sens[[c for c in keepc if c in t_sens]], "S22_joinpoint_BIC": bic, "S22b_joinpoint_permutation": perm,
            "S22c_trend_prepandemic_APC": t_pre[[c for c in keepc if c in t_pre]], "S22d_prepandemic_segments": jp_pre, "S23_trend_by_WHO_region": t_reg,
            "S24_trend_1945_2025_counts": t_hist, "S24b_all_civil_counts_1970_2025": t_counts, "S25_denominator_coverage": cov,
            "S26_lethality_models": pd.concat([T[(p, k)] for p in pops for k in ("frac", "binom", "cond") if (p, k) in T], ignore_index=True),
            "S27_joint_Wald_tests": pd.DataFrame(joint), "S28_model_convergence": pd.DataFrame(conv), "S29_covariate_level_counts": pd.concat(counts),
            "S30_age_three_approaches": age_tab, "S31_MI_full_model": pd.concat([T[(p, "mi")] for p in pops]), "S32_MI_diagnostics": pd.DataFrame(mi_info),
            "S33_age_spline_OR": spl, "S34_age_spline_tests": pd.DataFrame(tests), "S35_determinants_sensitivity": sens_or,
            "S36_seat_cut_descriptive": seat_desc, "S37_determinants_1945_2025": hist_or}
    write_tables(OUT / "P3_Supplementary_tables.xlsx", supp)
    print("\nPHASE 3 ------------------------------------------------------------")
    pd.set_option("display.width", 250)
    print(t3[["Outcome", "NB_APC", "NB_APC_lo", "NB_APC_hi", "NB_p", "NB_converged", "Poisson_dispersion", "Joinpoints", "JP_AAPC"]].round(3).to_string(index=False))
    print(jp_main.round(2).to_string(index=False)); print(pd.DataFrame(conv).to_string(index=False))
    return dict(t3=t3, t4=t4, t5=t5)



# ==================================================================================
# 12. ADDITIONAL SUPPLEMENTS: (A) manufacturers, exploratory; (B) historical record 1919-2025
# ==================================================================================
def occurrences_table(w, n=None, by=None):
    """Occurrence-level ranking (collision counterparts merged) for any set of records."""
    w = w.copy(); w["Occurrence_ID"] = occurrence_ids(w)
    j = lambda s: " / ".join(dict.fromkeys(str(x) for x in s if pd.notna(x)))
    agg = dict(Date=("Date", "first"), Year=("Year", "first"), Decade=("Decade", "first"), Aircraft=("Type", j), Operator=("Operator", j),
               Location=("Location", "first"), Country=("Country", "first"), Nature=("Nature", j), Phase=("Phase", j),
               ASN_category=("ASN_Category", j), n_aircraft=("ID", "size"), Any_military=("Military", "max"),
               Occupants=("Total_on_board", "sum"), Onboard_deaths=("Total_fatalities", "sum"), Ground_deaths=("Ground_fatalities", "sum"),
               ASN_URL=("ASN_URL", j))
    g = w.groupby("Occurrence_ID").agg(**agg).reset_index(drop=True)
    g["Total_deaths"] = g["Onboard_deaths"] + g["Ground_deaths"]
    g = g.sort_values(["Total_deaths", "Onboard_deaths"], ascending=False)
    if by:
        g = g.groupby(by, group_keys=False).head(n).sort_values([by, "Total_deaths"], ascending=[True, False])
        g.insert(0, "Rank_in_" + by.lower(), g.groupby(by).cumcount() + 1)
    elif n:
        g = g.head(n); g.insert(0, "Rank", range(1, len(g) + 1))
    return g


def supplements(df, hist, main, mil):
    import statsmodels.api as sm
    import warnings
    warnings.filterwarnings("ignore")
    plt = _mpl()
    occ = occurrence_ids(df); df = df.assign(Occurrence_ID=occ); main = main.assign(Occurrence_ID=main["ID"].map(dict(zip(df["ID"], occ))))

    # ---------------- A. MANUFACTURERS (exploratory) ----------------
    def per(d, key, minn):
        r = [{key: k, **summarise(g), "Median_event_year": int(g["Year"].median()),
              "Events_1970_1989": int((g["Year"] < 1990).sum()), "Events_1990_2025": int((g["Year"] >= 1990).sum())}
             for k, g in d.groupby(key) if len(g) >= minn]
        return pd.DataFrame(r).sort_values("Events", ascending=False)
    airliner = ["Regional (20-100 seats)", "Narrow-body (>100 seats)", "Wide-body"]
    cj = main[(main["CAT"] == 1) & (main["Propulsion"] == "Jet") & main["Aircraft_class"].isin(airliner)]
    m_all = per(main, "Manufacturer_group", 50); m_cj = per(cj, "Manufacturer_group", 30); f_cj = per(cj, "Aircraft_family", 30)
    # model: CAT jet airliners, 1990-2025, manufacturer as covariate
    mm = model_frame(cj[cj["Year"] >= 1990]); vc = mm["Manufacturer_group"].value_counts()
    mm["Mfr_m"] = np.where(mm["Manufacturer_group"].map(vc) >= 100, mm["Manufacturer_group"], "Other manufacturers")
    REF["Mfr_m"] = "Boeing"; VAR_LABEL["Mfr_m"] = "Manufacturer group"
    REF2 = dict(REF); cov = ["Mfr_m", "Phase_m", "Class_m", "Age_m", "Nature_m", "Decade_m", "Region_m"]
    old = REF["Decade_m"]; REF["Decade_m"] = "1990s"; rows, conv, cnt = [], [], []
    for pop, mx in [("All events", mm), ("Hull-loss events only", mm[mm["Hull_loss_3"] == "Yes"])]:
        for label, covs in [("Crude (manufacturer only)", ["Mfr_m"]), ("Adjusted", cov)]:
            try:
                _, r_ = fit_glm(_formula(covars=covs), mx, sm.families.Binomial(), mx["Occurrence_ID"])
                t_ = tidy(r_, "OR", pop, label); rows.append(t_[t_["Variable"] == "Manufacturer group"])
                conv.append(dict(Population=pop, Model=label, n=int(r_.nobs), fatal=int(mx["y"].sum()), converged=bool(r_.converged)))
            except Exception as e:
                conv.append(dict(Population=pop, Model=label, n=len(mx), fatal=int(mx["y"].sum()), converged=False, error=str(e)[:90]))
        g = mx.groupby("Mfr_m")["y"].agg(["size", "sum"]).reset_index().rename(columns={"size": "Events", "sum": "Fatal_events"}); g.insert(0, "Population", pop); cnt.append(g)
    REF["Decade_m"] = old
    m_or = pd.concat(rows, ignore_index=True)
    # forest
    a = m_or[m_or["Model"] == "Adjusted"]; lv = [l for l in a[a["Population"] == "All events"].sort_values("Estimate")["Level"]]
    fig, ax = plt.subplots(figsize=(5.6, 0.42 * len(lv) + 1.2))
    for off, pop, col, mk in [(-0.15, "All events", PAL["blue"], "o"), (0.15, "Hull-loss events only", PAL["red"], "s")]:
        t_ = a[a["Population"] == pop].set_index("Level")
        for i, l in enumerate(lv):
            if l in t_.index and not t_.loc[l, "Flag"]:
                r_ = t_.loc[l]; ax.plot([max(r_.CI_lo, 0.03), min(r_.CI_hi, 40)], [i + off] * 2, color=col, lw=0.9); ax.plot(r_.Estimate, i + off, mk, ms=4, color=col, label=pop if i == 0 else None)
    ax.axvline(1, color=PAL["ink"], lw=0.6); ax.set_xscale("log"); ax.set_xlim(0.03, 40); ax.set_yticks(range(len(lv))); ax.set_yticklabels(lv, fontsize=7.5)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}")); ax.set_xticks([0.05, 0.1, 0.25, 0.5, 1, 2, 4, 10, 25])
    ax.set_xlabel("Adjusted OR for a fatal event vs. Boeing (95% CI, log scale)"); ax.legend(loc="lower right"); ax.tick_params(axis="y", length=0)
    _save(fig, "P5_FigS3_manufacturer_forest")
    notes = [("S38", "Occurrences, deaths and lethality by manufacturer group, all civil aviation 1970-2025 (groups with >=50 records)."),
             ("S39", "Same, restricted to jet airliners in commercial air transport (CAT)."), ("S40", "Same, by aircraft family (CAT jet airliners, >=30 records)."),
             ("S41", "EXPLORATORY logistic models of a fatal event with manufacturer group as covariate (reference Boeing): CAT jet airliners, 1990-2025; crude and adjusted for phase, class, age, nature, decade and WHO region; all events and hull-loss events. Cluster-robust SE."),
             ("CAUTION", "No fleet exposure (departures/hours) by manufacturer is available: these are NOT accident rates. Estimates describe the severity of RECORDED occurrences and are confounded by era, operator, region and differential recording of minor occurrences. Groups with few fatal events (e.g. Embraer) yield unstable estimates.")]
    write_tables(OUT / "P5_Supplementary_manufacturers.xlsx", {"S38_manufacturer_all_civil": m_all, "S39_manufacturer_CAT_jets": m_cj, "S40_family_CAT_jets": f_cj,
                 "S41_manufacturer_models": m_or, "S42_model_counts": pd.concat(cnt), "S43_model_convergence": pd.DataFrame(conv)}, notes)

    # ---------------- B. HISTORICAL RECORD 1919-2025 ----------------
    strata = [("All operations", hist), ("Civil", hist[hist["Military"] == 0]), ("Military", hist[hist["Military"] == 1])]
    ann = []
    for name, d_ in strata:
        a_ = annual_series(d_, HIST_START, HIST_END); a_.insert(0, "Stratum", name)
        a_["Ground_deaths"] = a_["Total_deaths"] - a_["Onboard_deaths"]
        a_["Fatalities_unknown"] = a_["Year"].map((~d_["Fatalities_known"]).groupby(d_["Year"]).sum()).fillna(0).astype(int); ann.append(a_)
    ann = pd.concat(ann, ignore_index=True)
    dec = pd.concat([pd.DataFrame([{"Stratum": n_, "Decade": f"{int(k)}s", **summarise(g)} for k, g in d_.groupby("Decade")]) for n_, d_ in strata], ignore_index=True)
    civ = hist[hist["Military"] == 0]
    dec_reg = pd.DataFrame([{"Decade": f"{int(k[0])}s", "WHO_region": k[1], **summarise(g)} for k, g in civ.groupby(["Decade", "WHO_region"])])
    dec_prop = pd.DataFrame([{"Decade": f"{int(k[0])}s", "Propulsion": k[1], **summarise(g)} for k, g in civ.groupby(["Decade", "Propulsion"])])
    dec_phase = pd.DataFrame([{"Decade": f"{int(k[0])}s", "Phase_group": k[1], **summarise(g)} for k, g in civ.groupby(["Decade", "Phase_group"])])
    top_dec = occurrences_table(hist, 10, "Decade"); top_all = occurrences_table(hist, 50)
    top_civ = occurrences_table(civ, 50)
    cols = ["ID", "Date", "Year", "Decade", "Type", "Aircraft_family", "Propulsion", "Aircraft_class", "Operator", "Registration", "Year_built", "Age_years",
            "Location", "Country", "ISO3", "WHO_region", "Nature", "Nature_group", "Military", "CAT", "Phase", "Phase_group", "Total_on_board",
            "Total_fatalities", "Ground_fatalities", "Onboard_lethality", "Airplane_damage", "Hull_loss_3", "ASN_Category", "Intentional_act",
            "Collision_partner_ID", "Confidence_Rating", "ASN_URL"]
    listing = hist.sort_values(["Year", "Date_parsed", "ID"])[cols]
    first, last = hist.sort_values("Date_parsed")["Date"].iloc[0], hist.sort_values("Date_parsed")["Date"].dropna().iloc[-1]
    notes = [("Coverage", f"Aviation Safety Network Accident Database, all records retrieved: {len(hist):,} aircraft-level records, first record {hist['Year'].min()} , last record 28 DEC 2025. The database holds NO records before 1919 and records for 2026 had not been retrieved when the analysis was closed."),
             ("H1", "Annual series 1919-2025 by stratum (all operations, civil, military): records, fatal events, on-board deaths, ground deaths (collision-de-duplicated), hull losses."),
             ("H2", "By decade and stratum."), ("H3-H5", "Civil operations by decade and WHO region, propulsion and phase of flight."),
             ("H6", "Ten deadliest occurrences of each decade (collision counterparts merged; civil and military)."), ("H7-H8", "Fifty deadliest occurrences 1919-2025: all operations, and civil only."),
             ("H9", "Complete event listing (one row per aircraft), with derived variables and ASN record URL."),
             ("CAUTION", "Completeness before 1970 is limited and heterogeneous; 1939-1945 is dominated by military transport losses; no traffic denominators exist before 1970, so only counts are shown. 'Total_fatalities' are on-board deaths of each aircraft; 'Ground_fatalities' exclude collision counterparts already in the database.")]
    write_tables(OUT / "P5_Supplementary_historical_1919_2025.xlsx", {"H1_annual": ann, "H2_decade": dec, "H3_civil_decade_region": dec_reg, "H4_civil_decade_propulsion": dec_prop,
                 "H5_civil_decade_phase": dec_phase, "H6_top10_per_decade": top_dec, "H7_top50_all": top_all, "H8_top50_civil": top_civ, "H9_event_listing": listing}, notes)
    # figure: century of records
    a_c = ann[ann["Stratum"] == "Civil"].set_index("Year"); a_m = ann[ann["Stratum"] == "Military"].set_index("Year")
    fig, axes = plt.subplots(2, 1, figsize=(7.2, 5.4), sharex=True, gridspec_kw=dict(hspace=0.12))
    for ax, col, lab, yl in [(axes[0], "Onboard_deaths", "A", "On-board deaths per year"), (axes[1], "Events", "B", "Records per year")]:
        ax.bar(a_c.index, a_c[col], width=0.85, color=PAL["blue"], alpha=0.85, label="Civil operations")
        ax.bar(a_m.index, a_m[col], width=0.85, bottom=a_c[col], color=PAL["ochre"], alpha=0.85, label="Military operations")
        ax.set_ylabel(yl); ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{int(v):,}")); ax.text(-0.09, 1.0, lab, transform=ax.transAxes, fontsize=11, weight="bold")
        ax.axvspan(1939, 1945.9, color="#eeeeee", zorder=0, lw=0); ax.axvline(1970, color=PAL["ink"], lw=0.5, ls=":")
    axes[0].legend(loc="upper right"); axes[0].text(1942.5, axes[0].get_ylim()[1] * 0.93, "1939–45", ha="center", fontsize=6.5, color=PAL["grey"])
    axes[0].text(1971, axes[0].get_ylim()[1] * 0.93, "main analysis →", fontsize=6.5, color=PAL["ink"]); axes[1].set_xlabel("Year"); axes[1].set_xlim(1918, 2026)
    _save(fig, "P5_FigS4_historical_1919_2025")
    # ---------------- C. WHY 1970? data completeness by era + historical figures without denominators ----------------
    era = pd.cut(hist["Year"], [1918, 1944, 1969, 2025], labels=["1919-1944", "1945-1969", "1970-2025"]); rows = []
    for e, g in hist.groupby(era, observed=True):
        c = g[g["Military"] == 0]; hk = c[c["Hull_loss_3"] != "Unknown"]
        rows.append(dict(Period=e, Records_all=len(g), Military_pct=round(100 * g["Military"].mean(), 1), Civil_records=len(c),
                         Civil_onboard_deaths=int(c["Total_fatalities"].sum()), Fatalities_unknown_pct=round(100 * c["Total_fatalities"].isna().mean(), 1),
                         Occupants_unknown_pct=round(100 * c["Total_on_board"].isna().mean(), 1), Phase_unknown_pct=round(100 * (c["Phase_group"] == "Unknown").mean(), 1),
                         Year_built_unknown_pct=round(100 * c["Year_built"].isna().mean(), 1), No_ASN_confidence_rating_pct=round(100 * c["Confidence_Rating"].isna().mean(), 1),
                         Hull_loss_pct_of_known_damage=round(100 * (hk["Hull_loss_3"] == "Yes").mean(), 1), Traffic_denominators="available 1970-2023" if e == "1970-2025" else "not available"))
    s44 = pd.DataFrame(rows)
    write_tables(OUT / "P5_Supplementary_S44_completeness_by_era.xlsx", {"S44_completeness_by_era": s44},
                 [("S44", "Completeness of the ASN record by period, civil operations (justification of the 1970-2025 main analysis window).")])
    # Fig S5: reported deaths by decade 1919-2025
    dd = hist.assign(D=hist["Decade"].where(hist["Decade"] > 1910, 1920))          # 1919 joined to the 1920s bar
    g_ = dd.groupby("D"); civ_d = dd[dd["Military"] == 0].groupby("D")["Total_fatalities"].sum(); mil_d = dd[dd["Military"] == 1].groupby("D")["Total_fatalities"].sum()
    gr_d = g_["Ground_fatalities"].sum(); idx = sorted(g_.groups); lab = ["1919–29"] + [f"{d}s" for d in idx[1:-1]] + ["2020–25"]
    fig, ax = plt.subplots(figsize=(7.2, 3.6)); x = np.arange(len(idx)); c_ = civ_d.reindex(idx).fillna(0); m_ = mil_d.reindex(idx).fillna(0); r_ = gr_d.reindex(idx).fillna(0)
    ax.bar(x, c_, 0.75, color=PAL["blue"], label="On board, civil operations"); ax.bar(x, m_, 0.75, bottom=c_, color=PAL["ochre"], label="On board, military operations")
    ax.bar(x, r_, 0.75, bottom=c_ + m_, color=PAL["red"], label="On the ground (collision-de-duplicated)")
    for i in x:
        ax.text(i, (c_ + m_ + r_).iloc[i] + 300, f"{int((c_ + m_ + r_).iloc[i]):,}", ha="center", fontsize=6.8)
    ax.set_xticks(x); ax.set_xticklabels(lab, fontsize=7.5); ax.set_ylabel("Reported deaths per decade"); ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{int(v):,}"))
    ax.legend(loc="upper right"); ax.set_ylim(0, (c_ + m_ + r_).max() * 1.12); _save(fig, "P5_FigS5_deaths_by_decade_1919_2025")
    # Fig S6: civil hull-loss events 1945-2025: fatal proportion / lethality by decade, and deaths by phase x decade
    c45 = hist[(hist["Military"] == 0) & (hist["Year"] >= 1945)].copy(); c45 = c45[c45["Decade"] >= 1940]
    c45["DL"] = np.where(c45["Decade"] == 1940, "1945–49", np.where(c45["Decade"] == 2020, "2020–25", c45["Decade"].astype(int).astype(str) + "s"))
    order = ["1945–49"] + [f"{d}s" for d in range(1950, 2020, 10)] + ["2020–25"]
    lm = lethality_metrics(c45[c45["Hull_loss_3"] == "Yes"], "DL", order)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw=dict(width_ratios=[5, 6], wspace=0.35))
    ax = axes[0]; xx = np.arange(len(lm))
    for j, (v, lo, hi, name, col, mk) in enumerate([("Fatal_pct", "Fatal_lo", "Fatal_hi", "Fatal events", PAL["blue"], "o"), ("Lethality_pct", "Lethality_lo", "Lethality_hi", "On-board lethality", PAL["red"], "s"),
                                                    ("Cond_lethality_pct", "Cond_lo", "Cond_hi", "Lethality, fatal events only", PAL["ochre"], "^")]):
        ax.errorbar(xx + (j - 1) * 0.15, lm[v], yerr=[lm[v] - lm[lo], lm[hi] - lm[v]], fmt=mk, ms=3.2, color=col, elinewidth=0.7, capsize=1.6, lw=0, label=name); ax.plot(xx + (j - 1) * 0.15, lm[v], color=col, lw=0.6, alpha=0.6)
    ax.set_xticks(xx); ax.set_xticklabels(lm["Group"], fontsize=6.2, rotation=45, ha="right"); ax.set_ylim(0, 100); ax.set_ylabel("Per cent (95% CI), hull-loss events"); ax.grid(axis="y", lw=0.3, color=PAL["light"])
    ax.legend(loc="lower left", fontsize=6.5); ax.text(-0.2, 1.04, "A", transform=ax.transAxes, fontsize=11, weight="bold")
    ax = axes[1]; ph = [p for p in PHASE_ORDER]; M = np.array([[c45[(c45["Phase_group"] == p) & (c45["DL"] == d_)]["Total_fatalities"].sum() for d_ in order] for p in ph])
    ax.imshow(M, cmap="Reds", aspect="auto", vmin=0, vmax=M.max() * 1.15)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f"{int(M[i, j]):,}", ha="center", va="center", fontsize=5.8, color="white" if M[i, j] > M.max() * 0.6 else PAL["ink"])
    ax.set_xticks(range(len(order))); ax.set_xticklabels(order, fontsize=6.2, rotation=45, ha="right"); ax.set_yticks(range(len(ph))); ax.set_yticklabels(ph, fontsize=6.8); ax.tick_params(length=0)
    [sp.set_visible(False) for sp in ax.spines.values()]; ax.set_title("On-board deaths, civil operations", fontsize=8, loc="left"); ax.text(-0.5, 1.04, "B", transform=ax.transAxes, fontsize=11, weight="bold")
    _save(fig, "P5_FigS6_civil_1945_2025_lethality_phase")
    # Fig S7: world map, deaths in civil operations 1919-2025
    from matplotlib.patches import Patch
    cv = hist[(hist["Military"] == 0) & hist["ISO3"].notna()]; val = (cv["Total_fatalities"].fillna(0) + cv["Ground_fatalities"]).groupby(cv["ISO3"]).sum().to_dict()
    bins = [1, 50, 200, 500, 1000, 3000, 1e9]; labels = ["1–49", "50–199", "200–499", "500–999", "1,000–2,999", "≥3,000"]; colors = ["#fde9d9", "#f9c9a8", "#f09d77", "#dc6a51", "#b83c3a", "#7f1d2d"]
    fig = plt.figure(figsize=(7.2, 4.0)); ax = fig.add_axes([0, 0.08, 1, 0.92]); _draw_map(ax, load_geo("110m"), val, bins, colors, robinson)
    fig.legend(handles=[Patch(fc="#f3f3f1", ec="#6f6f6f", lw=0.3, label="0 / no record")] + [Patch(fc=c, ec="#6f6f6f", lw=0.3, label=l) for c, l in zip(colors, labels)],
               title="Deaths (on board + ground), civil operations, 1919–2025", loc="lower center", ncol=7, fontsize=7, title_fontsize=7.5, handlelength=1.2, columnspacing=1.0)
    _save(fig, "P5_FigS7_map_deaths_civil_1919_2025")
    print(s44.T.to_string()); print(lm[["Group", "n_known", "Fatal_pct", "Lethality_pct", "Cond_lethality_pct"]].round(1).to_string(index=False))
    print("\nSUPPLEMENTS --------------------------------------------------------")
    print(m_or[["Population", "Model", "Level", "Estimate", "CI_lo", "CI_hi", "p", "Flag"]].round(3).to_string(index=False)); print(pd.DataFrame(conv).to_string(index=False))
    print(dec[dec["Stratum"] == "All operations"][["Decade", "Events", "Fatal_events", "Onboard_deaths", "Ground_deaths"]].to_string(index=False))
    return dict(m_or=m_or, dec=dec, top=top_all)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", type=int, default=1)
    ap.add_argument("--data", default="ASN_base_limpia_1919-2025.xlsx")
    a = ap.parse_args()
    df, hist, main, mil = phase1(a.data)
    if a.phase >= 2 and a.phase != 5:
        res2 = phase2(df, hist, main, mil)
    if a.phase == 5:
        supplements(df, hist, main, mil); sys.exit(0)
    if a.phase >= 3:
        res3 = phase3(df, hist, main, mil)
