# Global mortality and fatal-event rates in civil aviation, 1970–2025

Data, extraction script and analysis code for the manuscript:

> Ortiz-Prado E, Serrano-Núñez MR, Cuenca-Calvopiña KA, Salazar-Calvopiña AN, Gualotuña-Tituaña ME, Villarreal-Burbano KB, Larenas N. *Global mortality and fatal-event rates in civil aviation, 1970–2025: trends, determinants of lethality and geographic distribution in 14,295 occurrences from the Aviation Safety Network database.* (under review)

One Health Research Group, Universidad de Las Américas, Quito, Ecuador.
Corresponding author: Esteban Ortiz-Prado (esteban.ortiz.prado@udla.edu.ec; ORCID 0000-0002-1895-7498).

## Contents

```
code/
  asn_scraper.py                 Retrieves every record of the ASN Accident Database (aviation-safety.net) for a range of years
  asn_analysis.py                Complete, reproducible analysis (phases 1–3 plus supplements); regenerates every table and figure
data/
  ASN_base_limpia_1919-2025.xlsx Cleaned occurrence matrix, 27,846 aircraft-level records, 46 columns (one record per aircraft)
  denominators/                  World Bank WDI bulk files IS.AIR.PSGR (passengers carried) and IS.AIR.DPRT (departures), ICAO source
  dictionary/
    data_dictionary.xlsx         Definition of every raw and derived variable
    aircraft_type_mapping.xlsx   Rules mapping 4,194 ASN type strings to 225 families, propulsion, class and reference seating
    corrections_log_and_collision_pairs.xlsx
                                 STROBE flow, missingness, the 6 documented corrections, and the 178 collision counterparts
                                 whose deaths were de-duplicated
results/
  tables/                        Tables 1–5 of the manuscript
  figures/                       Figures 1–7 and the STROBE flow diagram (PNG 400 dpi and PDF)
  supplementary/                 Supplementary Tables S1–S44, the historical record 1919–2025 (Tables H1–H9) and Figures S1–S7
```

## Reproducing the analysis

Requirements: Python ≥ 3.10 with the packages in `requirements.txt`.

```bash
pip install -r requirements.txt
cd code
python asn_analysis.py --phase 3 --data ../data/ASN_base_limpia_1919-2025.xlsx   # tables and figures, phases 1–3
python asn_analysis.py --phase 5 --data ../data/ASN_base_limpia_1919-2025.xlsx   # manufacturer and historical supplements
```

The script looks for the denominators in a folder named `denominators/` next to it (copy or symlink `data/denominators/`). Outputs are written to `code/outputs/`. Natural Earth boundaries for the maps are downloaded on first run (`geo/`).

To re-extract the source database: `python asn_scraper.py --years 1919-2025` (several hours; the script is rate-limited and resumable). The matrix in `data/` was extracted in September 2026; the ASN database is continuously updated, so a new extraction will not reproduce the counts exactly.

## Sources

- Aviation Safety Network (Flight Safety Foundation), https://aviation-safety.net — occurrence records. ASN data are used here for non-commercial research with attribution; redistribution of the extracted matrix follows the terms of use of the source.
- World Bank, World Development Indicators, indicators IS.AIR.PSGR and IS.AIR.DPRT (International Civil Aviation Organization statistics), https://data.worldbank.org — CC BY-4.0.
- Natural Earth, https://www.naturalearthdata.com — public domain boundaries.

## Licence

Code: MIT (see `LICENSE`). Derived tables, figures and the data dictionary: CC BY 4.0. The occurrence matrix is a derivative of the Aviation Safety Network database and remains subject to its terms of use.

## Citation

See `CITATION.cff`. Please cite the manuscript and, for the data, the Aviation Safety Network.
